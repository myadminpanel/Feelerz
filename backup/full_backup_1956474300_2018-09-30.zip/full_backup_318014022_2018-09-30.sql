#
# TABLE STRUCTURE FOR: administrators
#

DROP TABLE IF EXISTS `administrators`;

CREATE TABLE `administrators` (
  `ADMINID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_role` int(11) NOT NULL DEFAULT '2',
  `profile_picture` varchar(500) NOT NULL,
  `profile_thumb` varchar(500) NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ADMINID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `administrators` (`ADMINID`, `name`, `user_role`, `profile_picture`, `profile_thumb`, `email`, `username`, `password`) VALUES ('1', '', '1', '', '', 'sandeep.sikarwar@digimonk.in', 'digimonk', '7a8522303c1f6c5890e574b5171a288f');


#
# TABLE STRUCTURE FOR: bank_account
#

DROP TABLE IF EXISTS `bank_account`;

CREATE TABLE `bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `acc_no` varchar(50) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_addr` varchar(500) DEFAULT NULL,
  `ifsc_code` varchar(25) DEFAULT NULL,
  `pancard_no` varchar(20) DEFAULT NULL,
  `paypal_account` varchar(50) DEFAULT NULL,
  `paypal_email_id` varchar(100) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: buyer_rejected_list
#

DROP TABLE IF EXISTS `buyer_rejected_list`;

CREATE TABLE `buyer_rejected_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `gig_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0.pending,1.accept,2.cancel',
  `rejected_request` int(11) NOT NULL DEFAULT '0' COMMENT '0.send,1.complete',
  `notification_seen` int(11) NOT NULL DEFAULT '0' COMMENT '0.not seen,1.seen',
  `created_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `CATID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `seo` varchar(200) NOT NULL,
  `parent` bigint(20) NOT NULL DEFAULT '0',
  `details` text NOT NULL,
  `mtitle` text NOT NULL,
  `mdesc` text NOT NULL,
  `mtags` text NOT NULL,
  `category_image` varchar(500) NOT NULL,
  `category_thumb_image` varchar(500) NOT NULL,
  `category_medium_image` varchar(500) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL COMMENT '( 0 - Active , 1 - Inactive)',
  `delete_sts` int(11) NOT NULL DEFAULT '0' COMMENT '0-active,1 -inactive',
  PRIMARY KEY (`CATID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('5', 'Logo Design', '', '2', '', '', '', '', '', '', '', '2018-09-29 04:19:33', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('2', 'Graphics Design', '', '0', '', '', '', '', '', '', '', '2018-09-28 14:10:15', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('8', 'Digital Marketing', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:27:41', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('9', 'Social Media Marketing', '', '8', '', '', '', '', '', '', '', '2018-09-29 04:29:01', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('10', 'Writing and Translation', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:29:34', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('11', 'Video & Animation', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:30:42', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('12', 'Music Audio', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:31:24', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('13', 'Programming & Tech', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:31:59', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('14', 'Business', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:32:15', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('15', 'Fun and Lifestyle', '', '0', '', '', '', '', '', '', '', '2018-09-29 04:32:40', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('16', 'Banner Ads', '', '2', '', '', '', '', '', '', '', '2018-09-29 04:33:26', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('17', 'Photoshop Editing', '', '2', '', '', '', '', '', '', '', '2018-09-29 04:33:54', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('18', 'Business Cards & Stationery', '', '2', '', '', '', '', '', '', '', '2018-09-29 04:34:16', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('19', 'Illustration', '', '2', '', '', '', '', '', '', '', '2018-09-29 04:35:50', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('20', 'SEO', '', '8', '', '', '', '', '', '', '', '2018-09-29 04:36:07', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('21', 'Content Marketing', '', '8', '', '', '', '', '', '', '', '2018-09-29 04:36:52', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('22', 'Video Marketing', '', '8', '', '', '', '', '', '', '', '2018-09-29 04:37:33', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('23', 'Email Marketing', '', '8', '', '', '', '', '', '', '', '2018-09-29 05:02:24', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('24', 'Resumes & Cover Letters', '', '10', '', '', '', '', '', '', '', '2018-09-29 05:03:25', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('25', 'Articles & Blog Posts', '', '10', '', '', '', '', '', '', '', '2018-09-29 05:04:20', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('26', 'Website Content', '', '10', '', '', '', '', '', '', '', '2018-09-29 05:05:01', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('27', 'Technical Writing ', '', '10', '', '', '', '', '', '', '', '2018-09-29 05:05:57', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('28', 'Product Descriptions', '', '10', '', '', '', '', '', '', '', '2018-09-29 05:07:06', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('29', 'Whiteboard & Animated Explainers', '', '11', '', '', '', '', '', '', '', '2018-09-29 05:07:54', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('30', 'Intros & Outros', '', '11', '', '', '', '', '', '', '', '2018-09-29 05:08:39', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('31', ' Logo Animation', '', '11', '', '', '', '', '', '', '', '2018-09-29 05:09:37', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('32', ' Slideshows & Promo Videos', '', '11', '', '', '', '', '', '', '', '2018-09-29 05:10:13', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('33', 'Editing & Post Production', '', '11', '', '', '', '', '', '', '', '2018-09-29 05:10:43', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('34', 'Voice Over', '', '12', '', '', '', '', '', '', '', '2018-09-29 05:11:52', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('35', 'Mixing & Mastering', '', '12', '', '', '', '', '', '', '', '2018-09-29 05:12:16', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('36', 'Producers & Composers', '', '12', '', '', '', '', '', '', '', '2018-09-29 05:13:00', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('37', 'Singer-Songwriters', '', '12', '', '', '', '', '', '', '', '2018-09-29 05:13:22', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('38', 'Session Musicians & Singers', '', '12', '', '', '', '', '', '', '', '2018-09-29 05:13:49', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('39', 'WordPress', '', '13', '', '', '', '', '', '', '', '2018-09-29 05:14:28', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('40', 'Website Builders & CMS', '', '13', '', '', '', '', '', '', '', '2018-09-29 05:14:55', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('41', 'Web Programming', '', '13', '', '', '', '', '', '', '', '2018-09-29 05:15:13', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('43', 'Ecommerce', '', '13', '', '', '', '', '', '', '', '2018-09-29 05:16:43', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('44', 'Mobile Apps & Web', '', '13', '', '', '', '', '', '', '', '2018-09-29 05:34:20', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('45', 'Virtual Assistant', '', '14', '', '', '', '', '', '', '', '2018-09-29 05:34:53', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('46', 'Data Entry', '', '14', '', '', '', '', '', '', '', '2018-09-29 05:35:09', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('47', 'Market Research', '', '14', '', '', '', '', '', '', '', '2018-09-29 05:35:30', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('48', 'Business Plans', '', '14', '', '', '', '', '', '', '', '2018-09-29 05:35:45', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('49', 'Branding Services', '', '14', '', '', '', '', '', '', '', '2018-09-29 05:36:38', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('50', 'Online Lessons', '', '15', '', '', '', '', '', '', '', '2018-09-29 05:37:23', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('51', 'Arts & Crafts', '', '15', '', '', '', '', '', '', '', '2018-09-29 05:37:45', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('52', 'Relationship Advice', '', '15', '', '', '', '', '', '', '', '2018-09-29 05:38:01', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('53', 'Health, Nutrition & Fitness', '', '15', '', '', '', '', '', '', '', '2018-09-29 05:38:15', '0', '0');
INSERT INTO `categories` (`CATID`, `name`, `seo`, `parent`, `details`, `mtitle`, `mdesc`, `mtags`, `category_image`, `category_thumb_image`, `category_medium_image`, `created_date`, `status`, `delete_sts`) VALUES ('54', 'Astrology & Readings', '', '15', '', '', '', '', '', '', '', '2018-09-29 05:38:41', '0', '0');


#
# TABLE STRUCTURE FOR: chats
#

DROP TABLE IF EXISTS `chats`;

CREATE TABLE `chats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chat_from` int(11) NOT NULL,
  `chat_to` int(11) NOT NULL,
  `content` mediumtext CHARACTER SET utf8 NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `chat_type` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1- user to user',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `chat_from_time` datetime NOT NULL,
  `chat_to_time` datetime NOT NULL,
  `chat_utc_time` datetime NOT NULL,
  `timezone` varchar(20) NOT NULL,
  `from_delete_sts` tinyint(4) NOT NULL DEFAULT '0',
  `to_delete_sts` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL COMMENT '0-Unread,1-Read',
  PRIMARY KEY (`id`),
  KEY `chat_from` (`chat_from`),
  KEY `chat_to` (`chat_to`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `chats` (`id`, `chat_from`, `chat_to`, `content`, `file_path`, `chat_type`, `date_time`, `chat_from_time`, `chat_to_time`, `chat_utc_time`, `timezone`, `from_delete_sts`, `to_delete_sts`, `status`) VALUES ('1', '2', '1', 'Hello, Sandeep I want to buy your services.', '', '1', '2018-09-29 16:57:52', '2018-09-29 16:57:52', '2018-09-29 16:57:52', '2018-09-29 11:27:52', 'Asia/Kolkata', '0', '0', '1');
INSERT INTO `chats` (`id`, `chat_from`, `chat_to`, `content`, `file_path`, `chat_type`, `date_time`, `chat_from_time`, `chat_to_time`, `chat_utc_time`, `timezone`, `from_delete_sts`, `to_delete_sts`, `status`) VALUES ('2', '1', '2', 'Hello, Deepak I want to buy your Services. ', '', '1', '2018-09-29 17:06:45', '2018-09-29 17:06:45', '2018-09-29 17:06:45', '2018-09-29 11:36:45', 'Asia/Kolkata', '0', '0', '0');
INSERT INTO `chats` (`id`, `chat_from`, `chat_to`, `content`, `file_path`, `chat_type`, `date_time`, `chat_from_time`, `chat_to_time`, `chat_utc_time`, `timezone`, `from_delete_sts`, `to_delete_sts`, `status`) VALUES ('3', '1', '2', 'Yes Sure.', '', '1', '2018-09-29 17:16:06', '2018-09-29 17:16:06', '2018-09-29 17:16:06', '2018-09-29 11:46:06', 'Asia/Kolkata', '0', '0', '0');


#
# TABLE STRUCTURE FOR: client
#

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(50) NOT NULL,
  `client_raw_image` varchar(500) NOT NULL,
  `client_cropped_image` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `setting` varchar(60) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: country
#

DROP TABLE IF EXISTS `country`;

CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortname` varchar(3) NOT NULL,
  `country` varchar(150) NOT NULL,
  `country_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8;

INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('1', 'AF', 'Afghanistan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('2', 'AL', 'Albania', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('3', 'DZ', 'Algeria', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('4', 'AS', 'American Samoa', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('5', 'AD', 'Andorra', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('6', 'AO', 'Angola', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('7', 'AI', 'Anguilla', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('8', 'AQ', 'Antarctica', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('9', 'AG', 'Antigua And Barbuda', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('10', 'AR', 'Argentina', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('11', 'AM', 'Armenia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('12', 'AW', 'Aruba', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('13', 'AU', 'Australia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('14', 'AT', 'Austria', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('15', 'AZ', 'Azerbaijan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('16', 'BS', 'Bahamas The', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('17', 'BH', 'Bahrain', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('18', 'BD', 'Bangladesh', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('19', 'BB', 'Barbados', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('20', 'BY', 'Belarus', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('21', 'BE', 'Belgium', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('22', 'BZ', 'Belize', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('23', 'BJ', 'Benin', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('24', 'BM', 'Bermuda', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('25', 'BT', 'Bhutan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('26', 'BO', 'Bolivia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('27', 'BA', 'Bosnia and Herzegovina', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('28', 'BW', 'Botswana', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('29', 'BV', 'Bouvet Island', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('30', 'BR', 'Brazil', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('31', 'IO', 'British Indian Ocean Territory', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('32', 'BN', 'Brunei', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('33', 'BG', 'Bulgaria', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('34', 'BF', 'Burkina Faso', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('35', 'BI', 'Burundi', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('36', 'KH', 'Cambodia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('37', 'CM', 'Cameroon', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('38', 'CA', 'Canada', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('39', 'CV', 'Cape Verde', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('40', 'KY', 'Cayman Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('41', 'CF', 'Central African Republic', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('42', 'TD', 'Chad', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('43', 'CL', 'Chile', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('44', 'CN', 'China', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('45', 'CX', 'Christmas Island', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('46', 'CC', 'Cocos (Keeling) Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('47', 'CO', 'Colombia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('48', 'KM', 'Comoros', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('49', 'CG', 'Congo', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('50', 'CD', 'Congo The Democratic Republic Of The', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('51', 'CK', 'Cook Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('52', 'CR', 'Costa Rica', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('53', 'CI', 'Cote D\'Ivoire (Ivory Coast)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('54', 'HR', 'Croatia (Hrvatska)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('55', 'CU', 'Cuba', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('56', 'CY', 'Cyprus', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('57', 'CZ', 'Czech Republic', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('58', 'DK', 'Denmark', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('59', 'DJ', 'Djibouti', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('60', 'DM', 'Dominica', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('61', 'DO', 'Dominican Republic', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('62', 'TP', 'East Timor', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('63', 'EC', 'Ecuador', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('64', 'EG', 'Egypt', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('65', 'SV', 'El Salvador', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('66', 'GQ', 'Equatorial Guinea', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('67', 'ER', 'Eritrea', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('68', 'EE', 'Estonia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('69', 'ET', 'Ethiopia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('70', 'XA', 'External Territories of Australia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('71', 'FK', 'Falkland Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('72', 'FO', 'Faroe Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('73', 'FJ', 'Fiji Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('74', 'FI', 'Finland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('75', 'FR', 'France', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('76', 'GF', 'French Guiana', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('77', 'PF', 'French Polynesia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('78', 'TF', 'French Southern Territories', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('79', 'GA', 'Gabon', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('80', 'GM', 'Gambia The', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('81', 'GE', 'Georgia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('82', 'DE', 'Germany', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('83', 'GH', 'Ghana', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('84', 'GI', 'Gibraltar', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('85', 'GR', 'Greece', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('86', 'GL', 'Greenland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('87', 'GD', 'Grenada', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('88', 'GP', 'Guadeloupe', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('89', 'GU', 'Guam', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('90', 'GT', 'Guatemala', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('91', 'XU', 'Guernsey and Alderney', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('92', 'GN', 'Guinea', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('93', 'GW', 'Guinea-Bissau', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('94', 'GY', 'Guyana', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('95', 'HT', 'Haiti', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('96', 'HM', 'Heard and McDonald Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('97', 'HN', 'Honduras', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('98', 'HK', 'Hong Kong S.A.R.', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('99', 'HU', 'Hungary', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('100', 'IS', 'Iceland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('101', 'IN', 'India', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('102', 'ID', 'Indonesia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('103', 'IR', 'Iran', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('104', 'IQ', 'Iraq', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('105', 'IE', 'Ireland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('106', 'IL', 'Israel', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('107', 'IT', 'Italy', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('108', 'JM', 'Jamaica', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('109', 'JP', 'Japan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('110', 'XJ', 'Jersey', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('111', 'JO', 'Jordan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('112', 'KZ', 'Kazakhstan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('113', 'KE', 'Kenya', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('114', 'KI', 'Kiribati', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('115', 'KP', 'Korea North', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('116', 'KR', 'Korea South', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('117', 'KW', 'Kuwait', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('118', 'KG', 'Kyrgyzstan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('119', 'LA', 'Laos', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('120', 'LV', 'Latvia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('121', 'LB', 'Lebanon', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('122', 'LS', 'Lesotho', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('123', 'LR', 'Liberia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('124', 'LY', 'Libya', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('125', 'LI', 'Liechtenstein', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('126', 'LT', 'Lithuania', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('127', 'LU', 'Luxembourg', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('128', 'MO', 'Macau S.A.R.', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('129', 'MK', 'Macedonia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('130', 'MG', 'Madagascar', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('131', 'MW', 'Malawi', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('132', 'MY', 'Malaysia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('133', 'MV', 'Maldives', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('134', 'ML', 'Mali', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('135', 'MT', 'Malta', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('136', 'XM', 'Man (Isle of)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('137', 'MH', 'Marshall Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('138', 'MQ', 'Martinique', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('139', 'MR', 'Mauritania', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('140', 'MU', 'Mauritius', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('141', 'YT', 'Mayotte', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('142', 'MX', 'Mexico', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('143', 'FM', 'Micronesia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('144', 'MD', 'Moldova', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('145', 'MC', 'Monaco', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('146', 'MN', 'Mongolia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('147', 'MS', 'Montserrat', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('148', 'MA', 'Morocco', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('149', 'MZ', 'Mozambique', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('150', 'MM', 'Myanmar', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('151', 'NA', 'Namibia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('152', 'NR', 'Nauru', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('153', 'NP', 'Nepal', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('154', 'AN', 'Netherlands Antilles', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('155', 'NL', 'Netherlands The', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('156', 'NC', 'New Caledonia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('157', 'NZ', 'New Zealand', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('158', 'NI', 'Nicaragua', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('159', 'NE', 'Niger', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('160', 'NG', 'Nigeria', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('161', 'NU', 'Niue', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('162', 'NF', 'Norfolk Island', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('163', 'MP', 'Northern Mariana Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('164', 'NO', 'Norway', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('165', 'OM', 'Oman', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('166', 'PK', 'Pakistan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('167', 'PW', 'Palau', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('168', 'PS', 'Palestinian Territory Occupied', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('169', 'PA', 'Panama', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('170', 'PG', 'Papua new Guinea', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('171', 'PY', 'Paraguay', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('172', 'PE', 'Peru', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('173', 'PH', 'Philippines', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('174', 'PN', 'Pitcairn Island', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('175', 'PL', 'Poland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('176', 'PT', 'Portugal', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('177', 'PR', 'Puerto Rico', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('178', 'QA', 'Qatar', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('179', 'RE', 'Reunion', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('180', 'RO', 'Romania', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('181', 'RU', 'Russia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('182', 'RW', 'Rwanda', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('183', 'SH', 'Saint Helena', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('184', 'KN', 'Saint Kitts And Nevis', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('185', 'LC', 'Saint Lucia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('186', 'PM', 'Saint Pierre and Miquelon', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('187', 'VC', 'Saint Vincent And The Grenadines', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('188', 'WS', 'Samoa', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('189', 'SM', 'San Marino', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('190', 'ST', 'Sao Tome and Principe', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('191', 'SA', 'Saudi Arabia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('192', 'SN', 'Senegal', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('193', 'RS', 'Serbia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('194', 'SC', 'Seychelles', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('195', 'SL', 'Sierra Leone', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('196', 'SG', 'Singapore', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('197', 'SK', 'Slovakia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('198', 'SI', 'Slovenia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('199', 'XG', 'Smaller Territories of the UK', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('200', 'SB', 'Solomon Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('201', 'SO', 'Somalia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('202', 'ZA', 'South Africa', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('203', 'GS', 'South Georgia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('204', 'SS', 'South Sudan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('205', 'ES', 'Spain', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('206', 'LK', 'Sri Lanka', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('207', 'SD', 'Sudan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('208', 'SR', 'Suriname', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('209', 'SJ', 'Svalbard And Jan Mayen Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('210', 'SZ', 'Swaziland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('211', 'SE', 'Sweden', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('212', 'CH', 'Switzerland', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('213', 'SY', 'Syria', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('214', 'TW', 'Taiwan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('215', 'TJ', 'Tajikistan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('216', 'TZ', 'Tanzania', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('217', 'TH', 'Thailand', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('218', 'TG', 'Togo', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('219', 'TK', 'Tokelau', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('220', 'TO', 'Tonga', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('221', 'TT', 'Trinidad And Tobago', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('222', 'TN', 'Tunisia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('223', 'TR', 'Turkey', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('224', 'TM', 'Turkmenistan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('225', 'TC', 'Turks And Caicos Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('226', 'TV', 'Tuvalu', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('227', 'UG', 'Uganda', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('228', 'UA', 'Ukraine', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('229', 'AE', 'United Arab Emirates', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('230', 'GB', 'United Kingdom', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('231', 'US', 'United States', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('232', 'UM', 'United States Minor Outlying Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('233', 'UY', 'Uruguay', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('234', 'UZ', 'Uzbekistan', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('235', 'VU', 'Vanuatu', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('236', 'VA', 'Vatican City State (Holy See)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('237', 'VE', 'Venezuela', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('238', 'VN', 'Vietnam', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('239', 'VG', 'Virgin Islands (British)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('240', 'VI', 'Virgin Islands (US)', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('241', 'WF', 'Wallis And Futuna Islands', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('242', 'EH', 'Western Sahara', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('243', 'YE', 'Yemen', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('244', 'YU', 'Yugoslavia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('245', 'ZM', 'Zambia', '1');
INSERT INTO `country` (`id`, `sortname`, `country`, `country_status`) VALUES ('246', 'ZW', 'Zimbabwe', '1');


#
# TABLE STRUCTURE FOR: currencies
#

DROP TABLE IF EXISTS `currencies`;

CREATE TABLE `currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency` char(5) NOT NULL,
  `currency_sign` char(5) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `currencies` (`id`, `currency`, `currency_sign`, `status`) VALUES ('1', 'USD', '$', '1');
INSERT INTO `currencies` (`id`, `currency`, `currency_sign`, `status`) VALUES ('2', 'GBP', 'Â£', '1');
INSERT INTO `currencies` (`id`, `currency`, `currency_sign`, `status`) VALUES ('3', 'EUR', 'â‚¬', '1');


#
# TABLE STRUCTURE FOR: currency
#

DROP TABLE IF EXISTS `currency`;

CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dollar_rate` float NOT NULL,
  `indian_rate` float NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: db_backup_details
#

DROP TABLE IF EXISTS `db_backup_details`;

CREATE TABLE `db_backup_details` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_file_name` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Database Backup Details';

#
# TABLE STRUCTURE FOR: default_extra_gigs
#

DROP TABLE IF EXISTS `default_extra_gigs`;

CREATE TABLE `default_extra_gigs` (
  `default_gig_id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_description` text NOT NULL,
  `category_belongs` varchar(500) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0 - Active , 1 - Inactive',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`default_gig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: digital_download
#

DROP TABLE IF EXISTS `digital_download`;

CREATE TABLE `digital_download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `filename` varchar(256) NOT NULL,
  `buyer_show` tinyint(4) NOT NULL COMMENT '0-show,-hide',
  `seller_show` tinyint(4) NOT NULL COMMENT '0-show,1-hide',
  `upload_user_id` int(11) NOT NULL,
  `file_size` varchar(50) NOT NULL,
  `added_on` datetime NOT NULL,
  `time_zone` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_title` tinytext NOT NULL,
  `template_content` longblob NOT NULL,
  `template_type` tinyint(3) NOT NULL,
  `template_created` datetime NOT NULL,
  `template_status` tinyint(3) NOT NULL COMMENT '0 - Inactive ,1 - Active',
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('8', 'E-Mail Purchase Completed', '<h2>Hi {sell_name},</h2>\r\n\r\n<p>Your Purchase from {gig_owner} <strong> {title} </strong>has been completed&nbsp;</p>\r\n\r\n<p>Click the button below to to view Gig:</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Gig View link</a></p>\r\n\r\n<p>Click the button below to to view User Profile:</p>\r\n\r\n<p><a href=\"{user_profile_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View Users Profile link</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Cheers,</p>\r\n\r\n<p>{sitetitle} Team</p>\r\n</div>\r\n', '8', '2016-09-24 18:03:51', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('9', 'Email user purchase seller gig', '<h2>Hi {buyer_name},</h2>\r\n\r\n<p>&nbsp;<strong>{buyer_name} </strong>has purchased your gig <strong>{title}</strong>.</p>\r\n\r\n<p>Click the button below to to view Gig:</p>\r\n<a href=\"{gig_preview_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Click Here </a>\r\n\r\n<p>Click the button below to to view User Profile:</p>\r\n<a href=\"{user_profile_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View Users Profile link</a>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Cheers,</p>\r\n\r\n<p>{sitetitle} Team</p>\r\n</div>', '9', '2016-09-26 09:44:14', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('10', 'Email User Buying', '<h2>Hi {buyer_name},</h2>\r\n\r\n<p>You have made purchase from {seller_name} <strong>{title}</strong>.</p>\r\n\r\n<p>Click the button below to to view Gig:</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Gig View link</a></p>\r\n\r\n<p>Click the button below to to view User Profile:</p>\r\n\r\n<p><a href=\"{user_profile_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View Users Profile link</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Cheers,</p>\r\n<p>{sitetitle} Team</p>\r\n</div>\r\n', '10', '2016-09-26 11:11:05', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('13', 'Email Registration success', '<h2>Hi {USER_NAME},</h2>\r\n\r\n<p>Thank you for joining {sitetitle}. To finish signing up, you just need to confirm that we got your email right.</p>\r\n\r\n<p>Click the button below to confirm your email address.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{SUBMIT_LINK}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Confirm email address</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Once you have visited the verification URL, your account will be activated.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Thanks,<br />\r\n{sitetitle} Team</p>\r\n', '13', '2016-10-04 12:38:25', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('14', 'Email Forgot Password', '<h2>Hi {USER_NAME} ,</h2>\r\n\r\n<p>We&#39;ve received a request to reset the password for this email address.</p>\r\n\r\n<p>Click the button below to reset it.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{SUBMIT_LINK}\" target=\"_blank\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\">Reset My Password</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>If you didn&#39;t request this, you can ignore this email. Your password won&#39;t change until you create a new password.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Thanks,<br />\r\n{sitetitle} Team</p>\r\n', '14', '2016-10-04 12:55:37', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('16', 'Email Feedback Received', '<h2>Hi {seller_name} ,</h2>\r\n\r\n<p><strong>You have received the feedback from</strong> <a href=\"{user_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{buyer_name}</a> for below this product</p>\r\n\r\n<p><a href=\"{user_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>If you want to reply for this feedback, can you go to your sales page or click the button to reply feedback</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Reply to {buyer_name}</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '16', '2016-10-13 09:40:22', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('17', 'Email Feedback Reply', '<h2>Hi {buyer_name},</h2>\r\n\r\n<p><strong>You have received the reply feedback from</strong> <a href=\"{user_profile_link}\" target=\"_blank\" style=\"color: #bbadfc;\">{seller_name} </a> for below this product</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color: #bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>Thank you for your time and consideration.</p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '17', '2016-10-13 09:51:09', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('18', 'Email Order Complete', '<h2>Hi {buyer_name} ,</h2>\r\n\r\n<p>Your order is completed by <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{gig_owner}</a> for the below product</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>Please check the order. If your order is completed, you can give feedback for this product.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Click the button below to give feedback.</p>\r\n\r\n<p><a href=\"{gig_purchase}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Give Feedback</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '18', '2016-10-13 09:56:34', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('19', 'Email Purchase Completed for admin', '<table cellpadding=\"0\" cellspacing=\"0\" style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2 style=\"margin-left:15px; margin-right:15px; text-align:center\">Create New Order</h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4 style=\"margin-left:5px; margin-right:5px; text-align:center\">we&#39;ll let you know when your items are complete</h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\">\r\n			<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:20px auto 0; text-align:left; width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">{PAYPAL_ID}<br />\r\n						{CREATED_ON}<br />\r\n						Seller: <a href=\"javascript:;\" style=\"color:#bbadfc;\" target=\"_blank\">{seller_name}</a><br />\r\n						Buyer: <a href=\"javascript:;\" style=\"color:#bbadfc;\" target=\"_blank\">{buyer_name}</a></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">\r\n						<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:left; width:100%\">\r\n							<thead>\r\n								<tr>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Item</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Product Name</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Quantity</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Total</th>\r\n								</tr>\r\n							</thead>\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\"><img src=\"{IMG_SRC}\" style=\"height:34px; width:50px\" /></td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\"><a href=\"#\" style=\"color:#bbadfc;\" target=\"_blank\">{ITEM_NAME}</a></td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\">1</td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\">{PRICE}</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"4\">{TEABLE_ROW}</td>\r\n								</tr>\r\n							</tbody>\r\n							<tfoot>\r\n							</tfoot>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\">\r\n			<p>If you want check your manage payment list, click on below link</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><a href=\"#\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">View your orders</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '19', '2016-10-14 10:22:37', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('20', 'Payment request', '<table style=\"font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:center; vertical-align:topbox-sizing:border-box; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2 style=\"margin-left:15px; margin-right:15px; text-align:center\">Payment Request from {seller_name}</h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4 style=\"margin-left:5px; margin-right:5px; text-align:center\">we&#39;ll let you know when your items are complete</h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\">\r\n			<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:20px auto 0; text-align:left; width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">Transaction ID: {PAYPAL_ID}<br />\r\n						Buyer: <a href=\"javascript:;\" style=\"color:#bbadfc;\" target=\"_blank\">{buyer_name}</a></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">\r\n						<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:left; width:100%\">\r\n							<thead>\r\n								<tr>\r\n									<th style=\"border:1px solid #e7e7e7; padding: 8px;\">Item</th>\r\n									<th style=\"border:1px solid #e7e7e7; padding: 8px;\">Product Name</th>\r\n									<th style=\"border:1px solid #e7e7e7; padding: 8px;\">Quantity</th>\r\n									<th style=\"border:1px solid #e7e7e7; padding: 8px;\">Total</th>\r\n								</tr>\r\n							</thead>\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"border:1px solid #e7e7e7; padding: 8px;\"><img src=\"{IMG_SRC}\" style=\"height:34px; width:50px\" /></td>\r\n									<td style=\"border:1px solid #e7e7e7; padding: 8px;\"><a href=\"#\" style=\"color:#bbadfc;\" target=\"_blank\">{ITEM_NAME}</a></td>\r\n									<td style=\"border:1px solid #e7e7e7; padding: 8px;\">1</td>\r\n									<td style=\"border:1px solid #e7e7e7; padding: 8px;\">{PRICE}</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"4\">{TEABLE_ROW}</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			If you want check your manage payment list, click on below link</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			<a href=\"#\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">View your orders</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '20', '2016-10-15 15:23:31', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('21', 'multiple payment request', '<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:center; vertical-align:top; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2 style=\"margin-left:15px; margin-right:15px; text-align:center\">Payment Request from {seller_name}</h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4 style=\"margin-left:5px; margin-right:5px; text-align:center\">we&#39;ll let you know when your items are complete</h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:left; width:100%\">\r\n				<thead>\r\n					<tr>\r\n						<th style=\"vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Order Id</th>\r\n						<th style=\"vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Product Name</th>\r\n						<th style=\"vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Buyer</th>\r\n						<th style=\"vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Total</th>\r\n					</tr>\r\n				</thead>\r\n				<tbody>\r\n					<tr>\r\n						<td colspan=\"4\">{TEABLE_ROW}</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			If you want check your manage payment list, click on below link</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			<a href=\"#\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">View your orders</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '21', '2016-10-15 16:13:19', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('22', 'Email seller accepts buyer request', '<table cellpadding=\"0\" cellspacing=\"0\" style=\"vertical-align:top; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2>Hi {gig_owner}</h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4>Your gig with title <strong>{title}</strong> has a new request from <a href=\"{BUYER_LINK}\" style=\"color:#bbadfc\">{buyer_name}</a> with the following requirements</h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<table style=\"width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">Transaction ID: {PAYPAL_ID}<br />\r\n						Buyer: <a href=\"javascript:;\" style=\"color:#bbadfc\" target=\"_blank\">{buyer_name}</a></td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">\r\n						<table style=\"width:100%\">\r\n							<thead>\r\n								<tr>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Item</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Product Name</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Quantity</th>\r\n									<th style=\"border:1px solid #e7e7e7;padding: 8px;\">Total</th>\r\n								</tr>\r\n							</thead>\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\"><img src=\"{IMG_SRC}\" style=\"height:34px; width:50px\" /></td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\"><a href=\"{gig_preview_link}\" style=\"color:#bbadfc\" target=\"_blank\">{ITEM_NAME}</a></td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\">1</td>\r\n									<td style=\"border:1px solid #e7e7e7;padding: 8px;\">{PRICE}</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"4\">{TEABLE_ROW}</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			For more requirements from the client , click on below link</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			<a href=\"{request_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View sales</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '22', '2016-10-25 10:33:53', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('23', 'contact email', '<h2>Hi {to_username},</h2>\r\n\r\n<p>You have received the message from <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{from_username} </a></p>\r\n\r\n<p><a href=\"{message_link}\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">View</a></p>\r\n\r\n<p>Thank you for your time and consideration.</p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '23', '2016-10-26 09:55:08', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('24', 'Buyer cancelled order', '<table cellpadding=\"0\" cellspacing=\"0\" style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:center; vertical-align:top; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2 style=\"margin-left:15px; margin-right:15px; text-align:center\">Hi {gig_owner}</h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4 style=\"margin-left:5px; margin-right:5px; text-align:center\">Your gig <a href=\"{gig_link}\" style=\"color:#bbadfc;\">{title}</a> has been Cancelled from <a href=\"{BUYER_LINK}\" style=\"color:#bbadfc;\">{buyer_name}</a> with the following requirements</h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\">\r\n			<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:20px auto 0; text-align:left; width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">{PAYPAL_ID}</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">\r\n						<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:left; width:100%\">\r\n							<thead>\r\n								<tr>\r\n									<th style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Item</th>\r\n									<th style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Product Name</th>\r\n									<th style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Quantity</th>\r\n									<th style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">Total</th>\r\n								</tr>\r\n							</thead>\r\n							<tfoot>\r\n							</tfoot>\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\"><img src=\"{IMG_SRC}\" style=\"height:34px; width:50px\" /></td>\r\n									<td style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\"><a href=\"{gig_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{ITEM_NAME}</a></td>\r\n									<td style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">1</td>\r\n									<td style=\"font-family: Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; border:1px solid #e7e7e7; margin: 0; padding: 8px;\">{PRICE}</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"4\">{TEABLE_ROW}</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			you have accept our request , click on below link</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			<a href=\"{accept_link}\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">Accept</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '24', '2016-10-26 12:40:29', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('25', 'seller declined order', '<h2>Hi {buyer_name} ,</h2>\r\n\r\n<p>Your order is Declined from <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{gig_owner}</a> for below this product</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Please accept the decline request.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{purchase_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Give Accept</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '25', '2016-10-31 10:49:23', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('26', 'Decline request accept', '<h2>Hi {buyer_name} ,</h2>\r\n\r\n<p>Your Decline request accepted from <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{gig_owner}</a> for below this product</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>Please check the order. If order is Declined, you can give accept for Declined order.</p>\r\n\r\n<p><a href=\"{sales_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '26', '2016-11-01 15:54:49', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('27', 'Cancel request accept', '<h2>Hi {buyer_name},</h2>\r\n\r\n<p>Your Cancel request accepted from <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{gig_owner}</a>&nbsp; for below this product</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>Please check the order.</p>\r\n\r\n<p><a href=\"{purchase_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">View</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '27', '2016-11-01 16:05:04', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('28', 'Admin Completed Payment', '<h2>Hi {seller_name} ,</h2>\r\n\r\n<p>Your payment request successfully sent to your account for below this product</p>\r\n\r\n<p>Please check the payment.</p>\r\n\r\n<p><a href=\"{gig_link}\" style=\"color:#bbadfc;\">{TITLE}</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '28', '0000-00-00 00:00:00', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('29', 'Order Complete Request ', '<h2>Hi {buyer_name} ,</h2>\r\n\r\n<p>You have received order completed request</p>\r\n\r\n<p>Please accept the completed request.</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\">{title}</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '29', '0000-00-00 00:00:00', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('30', 'Complete Request Accepted', '<h2>Hi {gig_owner} ,</h2>\r\n\r\n<p>&nbsp;Order completed request &nbsp;accepted by buyer.</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\">{title}</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '30', '0000-00-00 00:00:00', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('31', 'Cancel Request', '<h2>Hi {seller_name} ,</h2>\r\n\r\n<p>Your completed request has been Rejected by <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{buyer_name}</a> for below this product</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{gig_preview_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{title}</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{gig_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Check Now</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{site_name} Team</p>\r\n</div>\r\n', '31', '0000-00-00 00:00:00', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('32', 'Buyer reject completed request', '<h2>Hi {admin_name} ,</h2>\r\n\r\n<p>You have a New Rejected Order Request <a href=\"{user_profile_link}\" style=\"color:#bbadfc;\" target=\"_blank\"></a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><a href=\"{gig_link}\" style=\"font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #bbadfc; margin: 0; padding:5px 10px;\" target=\"_blank\">Rejected Orders</a></p>\r\n\r\n<div style=\"float:left; margin-top:20px; width:100%\">\r\n<p>Thanks,</p>\r\n\r\n<p>{buyer_name}.</p>\r\n</div>\r\n', '32', '0000-00-00 00:00:00', '1');
INSERT INTO `email_templates` (`template_id`, `template_title`, `template_content`, `template_type`, `template_created`, `template_status`) VALUES ('34', 'Buyer Refund Amount', '<table cellpadding=\"0\" cellspacing=\"0\" style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:center; vertical-align:top; width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h2 style=\"margin-left:15px; margin-right:15px; text-align:center\">Hi <a href=\"{BUYER_LINK}\">{buyer_name}</a></h2>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">\r\n			<h4 style=\"margin-left:5px; margin-right:5px; text-align:center\">Cancellation amount has been refunded for the gig <a href=\"{gig_link}\" style=\"color:#bbadfc;\">{title}</a></h4>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\">\r\n			<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:20px auto 0; text-align:left; width:100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">Buyer Refund Amount</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"vertical-align:top\">\r\n						<table style=\"box-sizing:border-box; font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif; font-size:14px; margin:0; text-align:left; width:100%\">\r\n							<thead>\r\n								<tr>\r\n									<th style=\"vertical-align:top\">Item</th>\r\n									<th style=\"vertical-align:top\">Product Name</th>\r\n									<th style=\"vertical-align:top\">Quantity</th>\r\n									<th style=\"vertical-align:top\">Total</th>\r\n								</tr>\r\n							</thead>\r\n							<tfoot>\r\n							</tfoot>\r\n							<tbody>\r\n								<tr>\r\n									<td style=\"vertical-align:top\"><img src=\"{IMG_SRC}\" style=\"height:34px; width:50px\" /></td>\r\n									<td style=\"vertical-align:top\"><a href=\"{gig_link}\" style=\"color:#bbadfc;\" target=\"_blank\">{ITEM_NAME}</a></td>\r\n									<td style=\"vertical-align:top\">1</td>\r\n									<td style=\"vertical-align:top\">{PRICE}</td>\r\n								</tr>\r\n								<tr>\r\n									<td colspan=\"4\">{TEABLE_ROW}</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			you have accept our request , click on below link</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align:center; vertical-align:top\"><br />\r\n			<a href=\"{accept_link}\" style=\"display:inline-block; background-color:#bbadfc; border-radius:3px; font-family: \'Helvetica Neue\',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #fff; text-decoration: inherit; margin: 0;padding:5px 10px;\" target=\"_blank\">Accept</a></td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '34', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: extra_gigs
#

DROP TABLE IF EXISTS `extra_gigs`;

CREATE TABLE `extra_gigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gigs_id` int(11) NOT NULL,
  `currency_type` char(5) NOT NULL,
  `currency_sign` char(5) NOT NULL,
  `extra_gigs` varchar(500) NOT NULL,
  `extra_gigs_amount` float NOT NULL,
  `extra_gigs_delivery` varchar(500) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('19', '10', 'USD', '', 'i give template', '10', '1', '2018-09-29 13:58:42');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('21', '9', 'USD', '', 'I can make it animated', '20', '1', '2018-09-29 14:00:58');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('22', '7', 'USD', '', 'I can give more creative it ', '10', '1', '2018-09-29 14:02:45');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('23', '6', 'USD', '', 'Make it HD', '5', '1', '2018-09-29 14:06:36');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('24', '2', 'USD', '', 'I can add auto email', '10', '2', '2018-09-29 14:07:07');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('25', '1', 'USD', '', '1 time revision', '10', '1', '2018-09-29 14:07:35');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('26', '13', 'USD', '', 'I can handle also content regular', '50', '1', '2018-09-29 14:09:23');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('27', '11', 'USD', '', 'i can give you  resume cover', '5', '1', '2018-09-29 14:10:45');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('28', '5', 'USD', '', 'I make it animate', '10', '1', '2018-09-29 14:11:23');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('29', '4', 'USD', '', 'I can also get more share ', '50', '10', '2018-09-29 14:13:04');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('30', '3', 'USD', '', 'i can make it gif ', '50', '1', '2018-09-29 14:13:28');
INSERT INTO `extra_gigs` (`id`, `gigs_id`, `currency_type`, `currency_sign`, `extra_gigs`, `extra_gigs_amount`, `extra_gigs_delivery`, `created_date`) VALUES ('31', '15', 'USD', '', 'content beautiful ', '10', '1', '2018-09-29 14:15:09');


#
# TABLE STRUCTURE FOR: favourites
#

DROP TABLE IF EXISTS `favourites`;

CREATE TABLE `favourites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gig_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `favourites` (`id`, `user_id`, `gig_id`) VALUES ('1', '1', '5');


#
# TABLE STRUCTURE FOR: feedback
#

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `gig_id` int(11) NOT NULL,
  `order_id` mediumint(9) NOT NULL DEFAULT '0',
  `comment` varchar(500) NOT NULL,
  `rating` tinyint(4) NOT NULL DEFAULT '0',
  `time_zone` varchar(75) NOT NULL,
  `country_name` varchar(75) NOT NULL,
  `sent_recieved` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 - sent , 1 - replay',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `mail_sent` int(11) NOT NULL DEFAULT '1',
  `notification_status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: footer_menu
#

DROP TABLE IF EXISTS `footer_menu`;

CREATE TABLE `footer_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `footer_menu` (`id`, `title`, `status`, `created_date`) VALUES ('3', 'Learn', '1', '2018-09-29 10:26:43');
INSERT INTO `footer_menu` (`id`, `title`, `status`, `created_date`) VALUES ('4', 'Find', '1', '2018-09-29 10:27:00');
INSERT INTO `footer_menu` (`id`, `title`, `status`, `created_date`) VALUES ('5', 'Industry_Data', '1', '2018-09-29 10:27:14');
INSERT INTO `footer_menu` (`id`, `title`, `status`, `created_date`) VALUES ('6', 'Feedback', '1', '2018-09-29 10:38:27');


#
# TABLE STRUCTURE FOR: footer_submenu
#

DROP TABLE IF EXISTS `footer_submenu`;

CREATE TABLE `footer_submenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `footer_menu` int(11) NOT NULL,
  `footer_submenu` varchar(50) NOT NULL,
  `page_title` varchar(50) NOT NULL,
  `page_desc` varchar(500) NOT NULL,
  `seo_title` varchar(50) NOT NULL,
  `seo_desc` varchar(500) NOT NULL,
  `seo_keyword` varchar(500) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('1', '1', 'About_us', '', '<p>We are very high&nbsp;leading company in&nbsp; web development . Our vision is only care of our customer and their satisfaction.</p>\r\n', '', '', '', '1', '2018-09-29 10:03:55');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('2', '3', 'For_Influencers', '', '', '', '', '', '1', '2018-09-29 10:28:33');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('3', '3', 'For_Businesses', '', '', '', '', '', '1', '2018-09-29 10:29:25');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('4', '3', 'For_Agencies', '', '', '', '', '', '1', '2018-09-29 10:29:54');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('5', '3', 'Blog', '', '', '', '', '', '1', '2018-09-29 10:30:25');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('6', '4', 'Classes', '', '', '', '', '', '1', '2018-09-29 10:31:37');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('7', '3', 'Infographics', '', '', '', '', '', '1', '2018-09-29 10:32:10');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('8', '4', 'About', '', '', '', '', '', '1', '2018-09-29 10:32:37');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('9', '4', 'FAQ', '', '', '', '', '', '1', '2018-09-29 10:33:09');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('10', '4', 'Contact', '', '', '', '', '', '1', '2018-09-29 10:33:48');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('11', '4', 'Privacy', '', '', '', '', '', '1', '2018-09-29 10:34:22');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('12', '5', 'Collections', '', '', '', '', '', '1', '2018-09-29 10:35:08');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('13', '5', 'Influencer_Rates', '', '', '', '', '', '1', '2018-09-29 10:36:32');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('14', '3', 'Engagement_Rates', '', '', '', '', '', '1', '2018-09-29 10:37:03');
INSERT INTO `footer_submenu` (`id`, `footer_menu`, `footer_submenu`, `page_title`, `page_desc`, `seo_title`, `seo_desc`, `seo_keyword`, `status`, `created_date`) VALUES ('15', '6', 'Click_to_Feedback', '', '', '', '', '', '1', '2018-09-29 10:39:24');


#
# TABLE STRUCTURE FOR: gigs_image
#

DROP TABLE IF EXISTS `gigs_image`;

CREATE TABLE `gigs_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `image_path` varchar(500) NOT NULL,
  `gig_image_thumb` varchar(500) NOT NULL,
  `gig_image_tile` varchar(500) NOT NULL,
  `gig_image_medium` varchar(500) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('3', '2', 'uploads/gig_images/680_460_gig_1538200361.png', 'uploads/gig_images/50_34_gig_1538200361.png', 'uploads/gig_images/100_68_gig_1538200361.png', 'uploads/gig_images/240_162_gig_1538200361.png', '2018-09-29 06:00:39');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('4', '2', 'uploads/gig_images/680_460_gig_1538200684.png', 'uploads/gig_images/50_34_gig_1538200684.png', 'uploads/gig_images/100_68_gig_1538200684.png', 'uploads/gig_images/240_162_gig_1538200684.png', '2018-09-29 06:00:39');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('5', '2', 'uploads/gig_images/680_460_gig_1538200695.png', 'uploads/gig_images/50_34_gig_1538200695.png', 'uploads/gig_images/100_68_gig_1538200695.png', 'uploads/gig_images/240_162_gig_1538200695.png', '2018-09-29 06:00:39');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('6', '1', 'uploads/gig_images/680_460_gig_1538210567.png', 'uploads/gig_images/50_34_gig_1538210567.png', 'uploads/gig_images/100_68_gig_1538210567.png', 'uploads/gig_images/240_162_gig_1538210567.png', '2018-09-29 08:47:39');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('7', '3', 'uploads/gig_images/680_460_gig_1538213134.png', 'uploads/gig_images/50_34_gig_1538213134.png', 'uploads/gig_images/100_68_gig_1538213134.png', 'uploads/gig_images/240_162_gig_1538213134.png', '2018-09-29 09:28:20');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('8', '4', 'uploads/gig_images/680_460_gig_1538213996.png', 'uploads/gig_images/50_34_gig_1538213996.png', 'uploads/gig_images/100_68_gig_1538213996.png', 'uploads/gig_images/240_162_gig_1538213996.png', '2018-09-29 09:41:49');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('9', '5', 'uploads/gig_images/680_460_gig_1538218623.png', 'uploads/gig_images/50_34_gig_1538218623.png', 'uploads/gig_images/100_68_gig_1538218623.png', 'uploads/gig_images/240_162_gig_1538218623.png', '2018-09-29 10:59:58');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('10', '6', 'uploads/gig_images/680_460_gig_1538221366.png', 'uploads/gig_images/50_34_gig_1538221366.png', 'uploads/gig_images/100_68_gig_1538221366.png', 'uploads/gig_images/240_162_gig_1538221366.png', '2018-09-29 11:44:40');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('11', '7', 'uploads/gig_images/680_460_gig_1538221797.png', 'uploads/gig_images/50_34_gig_1538221797.png', 'uploads/gig_images/100_68_gig_1538221797.png', 'uploads/gig_images/240_162_gig_1538221797.png', '2018-09-29 11:55:13');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('12', '8', 'uploads/gig_images/680_460_gig_1538222591.png', 'uploads/gig_images/50_34_gig_1538222591.png', 'uploads/gig_images/100_68_gig_1538222591.png', 'uploads/gig_images/240_162_gig_1538222591.png', '2018-09-29 12:05:45');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('13', '9', 'uploads/gig_images/680_460_gig_1538222996.png', 'uploads/gig_images/50_34_gig_1538222996.png', 'uploads/gig_images/100_68_gig_1538222996.png', 'uploads/gig_images/240_162_gig_1538222996.png', '2018-09-29 12:11:52');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('14', '10', 'uploads/gig_images/680_460_gig_1538223424.png', 'uploads/gig_images/50_34_gig_1538223424.png', 'uploads/gig_images/100_68_gig_1538223424.png', 'uploads/gig_images/240_162_gig_1538223424.png', '2018-09-29 12:19:40');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('15', '11', 'uploads/gig_images/680_460_gig_1538224579.png', 'uploads/gig_images/50_34_gig_1538224579.png', 'uploads/gig_images/100_68_gig_1538224579.png', 'uploads/gig_images/240_162_gig_1538224579.png', '2018-09-29 12:40:25');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('16', '12', 'uploads/gig_images/680_460_gig_1538225139.png', 'uploads/gig_images/50_34_gig_1538225139.png', 'uploads/gig_images/100_68_gig_1538225139.png', 'uploads/gig_images/240_162_gig_1538225139.png', '2018-09-29 12:48:58');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('17', '13', 'uploads/gig_images/680_460_gig_1538225754.png', 'uploads/gig_images/50_34_gig_1538225754.png', 'uploads/gig_images/100_68_gig_1538225754.png', 'uploads/gig_images/240_162_gig_1538225754.png', '2018-09-29 12:58:39');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('18', '14', 'uploads/gig_images/680_460_gig_1538226167.png', 'uploads/gig_images/50_34_gig_1538226167.png', 'uploads/gig_images/100_68_gig_1538226167.png', 'uploads/gig_images/240_162_gig_1538226167.png', '2018-09-29 13:04:50');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('19', '15', 'uploads/gig_images/680_460_gig_1538226585.png', 'uploads/gig_images/50_34_gig_1538226585.png', 'uploads/gig_images/100_68_gig_1538226585.png', 'uploads/gig_images/240_162_gig_1538226585.png', '2018-09-29 13:11:55');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('20', '16', 'uploads/gig_images/680_460_gig_1538226950.png', 'uploads/gig_images/50_34_gig_1538226950.png', 'uploads/gig_images/100_68_gig_1538226950.png', 'uploads/gig_images/240_162_gig_1538226950.png', '2018-09-29 13:17:37');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('21', '17', 'uploads/gig_images/680_460_gig_1538227222.png', 'uploads/gig_images/50_34_gig_1538227222.png', 'uploads/gig_images/100_68_gig_1538227222.png', 'uploads/gig_images/240_162_gig_1538227222.png', '2018-09-29 13:23:41');
INSERT INTO `gigs_image` (`id`, `gig_id`, `image_path`, `gig_image_thumb`, `gig_image_tile`, `gig_image_medium`, `created_date`) VALUES ('22', '18', 'uploads/gig_images/680_460_gig_1538230831.png', 'uploads/gig_images/50_34_gig_1538230831.png', 'uploads/gig_images/100_68_gig_1538230831.png', 'uploads/gig_images/240_162_gig_1538230831.png', '2018-09-29 14:22:13');


#
# TABLE STRUCTURE FOR: gigs_video
#

DROP TABLE IF EXISTS `gigs_video`;

CREATE TABLE `gigs_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `video_path` varchar(500) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: language
#

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(150) NOT NULL,
  `language_value` char(5) NOT NULL,
  `status` varchar(20) NOT NULL COMMENT '1.active 2.inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: language_management
#

DROP TABLE IF EXISTS `language_management`;

CREATE TABLE `language_management` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `lang_key` varchar(100) CHARACTER SET utf8 NOT NULL,
  `lang_value` varchar(100) CHARACTER SET utf8 NOT NULL,
  `language` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: last_visited
#

DROP TABLE IF EXISTS `last_visited`;

CREATE TABLE `last_visited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('1', '1', '1', '2018-09-29 14:07:35');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('2', '2', '1', '2018-09-29 14:07:07');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('3', '2', '2', '2018-09-29 14:07:07');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('4', '3', '2', '2018-09-29 14:13:28');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('5', '1', '2', '2018-09-29 14:07:35');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('6', '5', '1', '2018-09-29 14:16:39');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('7', '17', '1', '2018-09-29 13:55:51');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('8', '16', '1', '2018-09-29 13:56:22');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('9', '10', '1', '2018-09-29 13:58:42');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('10', '15', '1', '2018-09-29 14:15:09');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('11', '9', '1', '2018-09-29 14:00:58');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('12', '8', '1', '2018-09-29 14:01:36');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('13', '7', '1', '2018-09-29 14:05:45');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('14', '6', '1', '2018-09-29 14:06:36');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('15', '8', '2', '2018-09-29 14:08:26');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('16', '14', '2', '2018-09-29 14:08:54');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('17', '13', '2', '2018-09-29 14:09:23');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('18', '12', '2', '2018-09-29 14:10:04');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('19', '11', '2', '2018-09-29 14:10:46');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('20', '5', '2', '2018-09-29 14:16:39');
INSERT INTO `last_visited` (`id`, `gig_id`, `user_id`, `created_date`) VALUES ('21', '4', '2', '2018-09-29 14:13:04');


#
# TABLE STRUCTURE FOR: members
#

DROP TABLE IF EXISTS `members`;

CREATE TABLE `members` (
  `USERID` bigint(20) NOT NULL AUTO_INCREMENT,
  `facebook_id` varchar(250) NOT NULL,
  `google_id` varchar(250) NOT NULL,
  `unique_code` varchar(50) NOT NULL,
  `forget` text NOT NULL,
  `email` varchar(80) NOT NULL DEFAULT '',
  `pemail` varchar(100) NOT NULL,
  `username` varchar(80) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL DEFAULT '',
  `contact` varchar(50) NOT NULL,
  `profession` int(11) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `funds` decimal(9,2) NOT NULL,
  `afunds` decimal(9,2) NOT NULL,
  `withdrawn` decimal(9,2) NOT NULL,
  `used` decimal(9,2) NOT NULL,
  `user_thumb_image` varchar(500) NOT NULL,
  `user_profile_image` varchar(500) NOT NULL,
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `rating` float NOT NULL DEFAULT '0',
  `ratingcount` bigint(10) NOT NULL DEFAULT '0',
  `profileviews` int(20) NOT NULL DEFAULT '0',
  `addtime` varchar(20) NOT NULL DEFAULT '',
  `lastlogin` varchar(20) NOT NULL DEFAULT '',
  `verified` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1',
  `profilepicture` varchar(100) NOT NULL DEFAULT '',
  `remember_me_key` varchar(32) DEFAULT NULL,
  `remember_me_time` datetime DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `lip` varchar(20) NOT NULL,
  `aemail` varchar(100) NOT NULL,
  `country` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `zipcode` bigint(20) NOT NULL,
  `user_timezone` varchar(200) NOT NULL,
  `toprated` int(1) NOT NULL DEFAULT '0',
  `level` bigint(1) NOT NULL DEFAULT '1',
  `lang_speaks` text NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`USERID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `members` (`USERID`, `facebook_id`, `google_id`, `unique_code`, `forget`, `email`, `pemail`, `username`, `password`, `contact`, `profession`, `pwd`, `funds`, `afunds`, `withdrawn`, `used`, `user_thumb_image`, `user_profile_image`, `fullname`, `description`, `rating`, `ratingcount`, `profileviews`, `addtime`, `lastlogin`, `verified`, `status`, `profilepicture`, `remember_me_key`, `remember_me_time`, `ip`, `lip`, `aemail`, `country`, `state`, `city`, `address`, `zipcode`, `user_timezone`, `toprated`, `level`, `lang_speaks`, `created_date`) VALUES ('1', '', '', '13t2Fy7tAHQadyj', '', 'sandeep.sikarwar@digimonk.net', '', 'Sandeeep', 'e1fd8c672573af9478b9adeb07c5c6b0', '9713755745', '1', '', '0.00', '0.00', '0.00', '0.00', 'uploads/profile_images/profile_image_1_50x50.png', 'uploads/profile_images/profile_image_1_200x200.png', 'Sandeep Singh Sikarwar', 'I am a web developer in Gwalior. I have 3 years experience. ', '0', '0', '0', '', '', '0', '0', '', NULL, NULL, '', '', '', '101', '21', 'Gwalior', '', '474001', 'Asia/Kolkata', '0', '1', 'English, Hindi', '2018-09-28 19:09:43');
INSERT INTO `members` (`USERID`, `facebook_id`, `google_id`, `unique_code`, `forget`, `email`, `pemail`, `username`, `password`, `contact`, `profession`, `pwd`, `funds`, `afunds`, `withdrawn`, `used`, `user_thumb_image`, `user_profile_image`, `fullname`, `description`, `rating`, `ratingcount`, `profileviews`, `addtime`, `lastlogin`, `verified`, `status`, `profilepicture`, `remember_me_key`, `remember_me_time`, `ip`, `lip`, `aemail`, `country`, `state`, `city`, `address`, `zipcode`, `user_timezone`, `toprated`, `level`, `lang_speaks`, `created_date`) VALUES ('2', '', '', '2wzwnwvxiymUkLt', '', 'deepak.patel@digimonk.net', '', 'deepak', 'e1fd8c672573af9478b9adeb07c5c6b0', '', '0', '', '0.00', '0.00', '0.00', '0.00', 'uploads/profile_images/profile_image_2_50x50.jpg', 'uploads/profile_images/profile_image_2_200x200.jpg', 'Deepak Patel', '', '0', '0', '0', '', '', '0', '0', '', NULL, NULL, '', '', '', '101', '21', '', '', '0', 'Asia/Kolkata', '0', '1', '', '2018-09-29 14:39:30');


#
# TABLE STRUCTURE FOR: one_signal_device_ids
#

DROP TABLE IF EXISTS `one_signal_device_ids`;

CREATE TABLE `one_signal_device_ids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(256) NOT NULL,
  `device` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: page
#

DROP TABLE IF EXISTS `page`;

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(45) NOT NULL,
  `page_content` text NOT NULL,
  `page_status` int(11) NOT NULL,
  `page_create` datetime NOT NULL,
  `page_modfied` datetime NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: payment_gateways
#

DROP TABLE IF EXISTS `payment_gateways`;

CREATE TABLE `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(50) NOT NULL,
  `gateway_type` varchar(20) NOT NULL,
  `api_key` varchar(50) NOT NULL,
  `value` varchar(70) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '(0 Inactive, 1 Active)',
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `payment_gateways` (`id`, `gateway_name`, `gateway_type`, `api_key`, `value`, `status`, `created_dt`) VALUES ('1', 'Stripe', 'sandbox', 'pk_test_Js15CigEZPZH69hjS2hgXjBx', 'sk_test_OVXvseuWuLVp2w0XOWvGKDQJ', '1', '2018-01-11 22:39:57');
INSERT INTO `payment_gateways` (`id`, `gateway_name`, `gateway_type`, `api_key`, `value`, `status`, `created_dt`) VALUES ('2', 'Stripe', 'live', 'pk_live_Fcv2quS4tvCx6BwXhfoQQFTT', 'sk_live_juEOItnRuTNTkHuijyJCdSdt', '1', '2018-01-12 00:15:49');


#
# TABLE STRUCTURE FOR: payments
#

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `USERID` bigint(20) NOT NULL,
  `gigs_id` int(11) NOT NULL,
  `extra_gig_ref` text NOT NULL,
  `currency_type` char(5) NOT NULL,
  `time_zone` varchar(250) NOT NULL,
  `seller_id` mediumint(9) NOT NULL,
  `item_amount` double NOT NULL,
  `currency` varchar(5) NOT NULL DEFAULT 'usd',
  `dollar_amount` double NOT NULL,
  `gig_price_dollar_rate` float NOT NULL,
  `created_at` datetime NOT NULL,
  `paypal_uid` varchar(255) NOT NULL,
  `stripe_charge` text NOT NULL,
  `stripe_refund` text NOT NULL,
  `refund_amount` decimal(10,2) NOT NULL,
  `commision` varchar(255) NOT NULL,
  `paypal_status` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `shipping_status` tinyint(4) NOT NULL DEFAULT '1',
  `pay_method` tinyint(4) NOT NULL DEFAULT '1',
  `buyer_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-default, 1- cancel request',
  `cancel_reason` varchar(500) NOT NULL,
  `canceled_at` datetime NOT NULL,
  `cancel_accept` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-default, 1- accept',
  `seller_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1.New 2.Pending 3.Processing 4.Refunded 5.Decline 6.Completed 7. Complete Request 8. Complete Request Accept ',
  `decline_accept` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-default, 1- accept',
  `payment_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-normal,1-payment request, 2-payment received',
  `update_date` datetime NOT NULL,
  `mail_sent` int(11) NOT NULL DEFAULT '1',
  `payment_returnmethod` tinyint(4) NOT NULL,
  `dispatch_date` datetime NOT NULL,
  `notification_status` tinyint(4) NOT NULL DEFAULT '1',
  `cancel_notification_status` tinyint(4) NOT NULL DEFAULT '0',
  `notification_paycomplete` tinyint(4) NOT NULL DEFAULT '0',
  `admin_notification_status` tinyint(4) NOT NULL DEFAULT '1',
  `payment_super_fast_delivery` int(11) NOT NULL,
  `delivery_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `extra_gig_indian_rupee` float NOT NULL,
  `extra_gig_dollar` float NOT NULL,
  `pay_status` varchar(100) NOT NULL,
  `source` varchar(100) NOT NULL,
  `amplify_verify` text NOT NULL,
  `txn_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: paypal_details
#

DROP TABLE IF EXISTS `paypal_details`;

CREATE TABLE `paypal_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sandbox_email` varchar(50) NOT NULL,
  `sandbox_password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `developement` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: paypal_table
#

DROP TABLE IF EXISTS `paypal_table`;

CREATE TABLE `paypal_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payer_id` varchar(60) DEFAULT NULL,
  `payment_date` varchar(50) DEFAULT NULL,
  `txn_id` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `payer_email` varchar(75) DEFAULT NULL,
  `payer_status` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `memo` tinytext,
  `item_name` varchar(127) DEFAULT NULL,
  `item_number` varchar(127) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `mc_gross` decimal(9,2) DEFAULT NULL,
  `mc_currency` char(3) DEFAULT NULL,
  `address_name` varchar(255) NOT NULL DEFAULT '',
  `address_street` varchar(255) NOT NULL DEFAULT '',
  `address_city` varchar(255) NOT NULL DEFAULT '',
  `address_state` varchar(255) NOT NULL DEFAULT '',
  `address_zip` varchar(255) NOT NULL DEFAULT '',
  `address_country` varchar(255) NOT NULL DEFAULT '',
  `address_status` varchar(255) NOT NULL DEFAULT '',
  `payer_business_name` varchar(255) NOT NULL DEFAULT '',
  `payment_status` varchar(255) NOT NULL DEFAULT '',
  `pending_reason` varchar(255) NOT NULL DEFAULT '',
  `reason_code` varchar(255) NOT NULL DEFAULT '',
  `txn_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `txn_id` (`txn_id`),
  KEY `txn_id_2` (`txn_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: policy_settings
#

DROP TABLE IF EXISTS `policy_settings`;

CREATE TABLE `policy_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policy_name` varchar(100) NOT NULL,
  `policy_terms` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: profession
#

DROP TABLE IF EXISTS `profession`;

CREATE TABLE `profession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profession_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('1', 'Web Designer', '0');
INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('2', 'Digital Marketer ', '0');
INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('3', 'Web Developer ', '0');
INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('4', 'Graphic Designer', '0');
INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('5', 'Resume Maker', '0');
INSERT INTO `profession` (`id`, `profession_name`, `status`) VALUES ('6', 'Content Writer ', '0');


#
# TABLE STRUCTURE FOR: sell_gigs
#

DROP TABLE IF EXISTS `sell_gigs`;

CREATE TABLE `sell_gigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `gig_price` float NOT NULL,
  `total_views` int(11) NOT NULL,
  `currency_type` char(5) NOT NULL,
  `cost_type` tinyint(4) NOT NULL COMMENT '0-static,1-dynamic',
  `delivering_time` varchar(500) NOT NULL,
  `gig_tags` text,
  `category_id` int(11) NOT NULL,
  `gig_details` text NOT NULL,
  `super_fast_charges` float NOT NULL,
  `super_fast_delivery` varchar(500) DEFAULT NULL,
  `super_fast_delivery_desc` varchar(250) NOT NULL,
  `super_fast_delivery_date` varchar(500) NOT NULL,
  `work_option` int(11) NOT NULL,
  `requirements` text NOT NULL,
  `youtube_url` varchar(500) NOT NULL,
  `vimeo_url` varchar(500) NOT NULL,
  `vimeo_video_id` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `time_zone` varchar(100) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notification_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('1', '1', 'i-can-increase-you-website-ranking-on-google', '100', '12', 'USD', '1', '2', 'SEO,Digital Marketing ', '20', '<p>Boost Your Rank.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '120', 'yes', '12 Hours', '1', '0', '<p>I need Work Scope</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:37:35', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('2', '1', 'i-can-make-a-website-in-wordpress', '100', '43', 'USD', '1', '5 ', 'PHP,HTML,CSS', '40', '<p>I will make a dynamic website.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '120', 'yes', 'I can deliver', '3', '0', '<p>I need the work scope. it will help me to complete the task as soon as possible</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:37:07', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('3', '2', 'get-awesome-logo-for-your-compny', '150', '0', 'USD', '1', '5', 'Logo Design', '5', '<p>I create creative logo.&nbsp;&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '200', 'yes', 'I can deliver', '1', '0', '<p>I need referal&nbsp;some images</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:43:28', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('4', '2', 'i-can-get-1k-thousand-like-and-views-on-your-business-page', '200', '0', 'USD', '1', '25', 'Social Media Marketing', '9', '<p>Boost your company page in social networking site . We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '0', '', '', '', '0', '<p>I required your business page credential&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:43:04', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('5', '2', 'i-can-create-banner-for-your-business', '80', '3', 'USD', '1', '2', 'Banner', '16', '<p>I create an awesome and creative&nbsp;banner.We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '90', 'yes', 'I can deliver this ', '1', '0', '<p>Only Reference Content</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:41:23', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('6', '1', 'make-your-images-more-beautiful', '10', '0', 'USD', '1', '3', 'Photoshop', '17', '<p>I make images more beautiful in so cheap rate.&nbsp;&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '0', '', '', '', '0', '<p>Make Your Images very Beautiful&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:36:36', '0000-00-00 00:00:00', '1');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('7', '1', 'get-your-business-card', '55', '0', 'USD', '1', '2', 'Business card', '18', '<p>I make the professional business card. Because we know the business card is the first impression of your business.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '50', 'yes', 'I can deliver', '1', '0', '<p>I required only a few details and&nbsp;referral design if you have.</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:32:45', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('8', '1', 'i-can-write-your-content-for-your-business', '70', '2', 'USD', '1', '2', 'Content Marketing', '21', '<p>I provide the best content according to your business.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '80', 'yes', 'I can deliver', '1', '0', '<p>I need only basic Details about your business</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:31:36', '0000-00-00 00:00:00', '1');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('9', '1', 'i-can-promote-your-video', '25', '0', 'USD', '1', '4', 'Video Marketing', '22', '<p>I create the creative marketing video.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '40', 'yes', 'I can deliver it ', '1', '0', '<p>I want to the limited amount of detail about video&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:30:58', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('10', '1', 'promote-your-business-by-email-markeitng', '30', '0', 'USD', '1', '3', 'Email Marketing,Promote', '23', '<p>I provide spam-free email to promote your business.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '40', 'yes', 'I can deliver it ', '1', '0', '<p>I want to only content.&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:28:42', '0000-00-00 00:00:00', '1');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('11', '2', 'i-make-your-professional-resume', '15', '0', 'USD', '1', '2', 'Resume Maker', '24', '<p>I will give you best resume .&nbsp;&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '20', 'yes', 'I can deliver ', '1', '0', '<p>Only your basic details</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:40:45', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('12', '2', 'i-can-make-blog-and-handle-also', '75', '0', 'USD', '1', '3', 'Blog, Article ', '25', '<p>I give you best blog content&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '85', 'yes', 'I give you ', '2', '0', '<p>I required only few details&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:40:03', '0000-00-00 00:00:00', '1');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('13', '2', 'i-can-provide-best-website-content', '250', '0', 'USD', '1', '5', 'Website,content', '26', '<p>I provide the best content according to&nbsp;your requirement .&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '300', 'yes', 'I can deliver ', '3', '0', '<p>I have needed your website credential. and your website content scope.</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:39:23', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('14', '2', 'get-technical-writing-in-best-price', '120', '1', 'USD', '1', '8', 'Technical writing , writing content', '27', '<p>I provide technical&nbsp;guidance and writing in best price.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '150', 'yes', 'I can deliver it ', '5', '0', '<p>I need basic details of your business.</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:38:54', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('15', '1', 'i-provide-you-best-description-according-to-your-needs', '20', '1', 'USD', '1', '1', 'Product Description,content', '28', '<p>I provide you best product content according to your requirement in best price.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '0', '', '', '', '0', '<p>I need only few details&nbsp;</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:45:09', '0000-00-00 00:00:00', '1');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('16', '1', 'get-whiteboard-animated-explainers', '160', '1', 'USD', '1', '6', 'Whiteboard , animated', '29', '<p>My gig provide you best&nbsp;white board explainers.&nbsp;We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '200', 'yes', 'I can deliver ', '4', '0', '<p>I need a&nbsp;few things.</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:26:22', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('17', '1', 'get-intros-and-outros', '90', '1', 'USD', '1', '10', 'Intro, outro', '30', '<p>I give you intros and outros&nbsp; with best details. We are a creative web design agency known for more than a decade to build the most beautiful &amp; engaging UI designs for distinct businesses.</p>\r\n', '120', 'yes', 'I can deliver it ', '8', '0', '<p>I need few details</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:25:51', '0000-00-00 00:00:00', '0');
INSERT INTO `sell_gigs` (`id`, `user_id`, `title`, `gig_price`, `total_views`, `currency_type`, `cost_type`, `delivering_time`, `gig_tags`, `category_id`, `gig_details`, `super_fast_charges`, `super_fast_delivery`, `super_fast_delivery_desc`, `super_fast_delivery_date`, `work_option`, `requirements`, `youtube_url`, `vimeo_url`, `vimeo_video_id`, `status`, `time_zone`, `country_name`, `created_date`, `update_date`, `notification_status`) VALUES ('18', '2', 'i-provide-creative-animation-logo', '50', '1', 'USD', '1', '5', 'Logo, Animation', '31', '<p>Meta&nbsp;<strong>descriptions</strong>&nbsp;are intended to provide users with a snippet of what they can expect to find by clicking on your&nbsp;<strong>website</strong>. Meta&nbsp;<strong>descriptions</strong>&nbsp;appear beneath a&nbsp;<strong>websites</strong>&nbsp;URL in search engine results&nbsp;</p>\r\n', '70', 'yes', 'I can deliver', '4', '0', '<p>I need details your project</p>\r\n', '', '', '0', '0', 'Asia/Kolkata', '', '2018-09-29 19:52:13', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: seller_extra_gigs
#

DROP TABLE IF EXISTS `seller_extra_gigs`;

CREATE TABLE `seller_extra_gigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gig_id` int(11) NOT NULL,
  `extra_gig_title` varchar(100) NOT NULL,
  `extra_gig_desc` varchar(500) NOT NULL,
  `extra_gig_amount` decimal(10,0) NOT NULL,
  `extra_gig_delivery` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: social_widgets
#

DROP TABLE IF EXISTS `social_widgets`;

CREATE TABLE `social_widgets` (
  `sw_id` int(11) NOT NULL AUTO_INCREMENT,
  `twitter_name` varchar(255) NOT NULL DEFAULT '',
  `twitter_id` varchar(255) NOT NULL DEFAULT '',
  `fb_page_name` varchar(255) NOT NULL DEFAULT '',
  `sw_sts` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sw_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `social_widgets` (`sw_id`, `twitter_name`, `twitter_id`, `fb_page_name`, `sw_sts`) VALUES ('1', '', '', '', '0');


#
# TABLE STRUCTURE FOR: states
#

DROP TABLE IF EXISTS `states`;

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(30) NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1',
  `state_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4121 DEFAULT CHARSET=latin1;

INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1', 'Andaman and Nicobar Islands', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2', 'Andhra Pradesh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3', 'Arunachal Pradesh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4', 'Assam', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('5', 'Bihar', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('6', 'Chandigarh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('7', 'Chhattisgarh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('8', 'Dadra and Nagar Haveli', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('9', 'Daman and Diu', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('10', 'Delhi', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('11', 'Goa', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('12', 'Gujarat', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('13', 'Haryana', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('14', 'Himachal Pradesh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('15', 'Jammu and Kashmir', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('16', 'Jharkhand', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('17', 'Karnataka', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('18', 'Kenmore', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('19', 'Kerala', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('20', 'Lakshadweep', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('21', 'Madhya Pradesh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('22', 'Maharashtra', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('23', 'Manipur', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('24', 'Meghalaya', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('25', 'Mizoram', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('26', 'Nagaland', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('27', 'Narora', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('28', 'Natwar', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('29', 'Odisha', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('30', 'Paschim Medinipur', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('31', 'Pondicherry', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('32', 'Punjab', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('33', 'Rajasthan', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('34', 'Sikkim', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('35', 'Tamil Nadu', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('36', 'Telangana', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('37', 'Tripura', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('38', 'Uttar Pradesh', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('39', 'Uttarakhand', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('40', 'Vaishali', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('41', 'West Bengal', '101', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('42', 'Badakhshan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('43', 'Badgis', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('44', 'Baglan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('45', 'Balkh', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('46', 'Bamiyan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('47', 'Farah', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('48', 'Faryab', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('49', 'Gawr', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('50', 'Gazni', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('51', 'Herat', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('52', 'Hilmand', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('53', 'Jawzjan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('54', 'Kabul', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('55', 'Kapisa', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('56', 'Khawst', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('57', 'Kunar', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('58', 'Lagman', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('59', 'Lawghar', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('60', 'Nangarhar', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('61', 'Nimruz', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('62', 'Nuristan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('63', 'Paktika', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('64', 'Paktiya', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('65', 'Parwan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('66', 'Qandahar', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('67', 'Qunduz', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('68', 'Samangan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('69', 'Sar-e Pul', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('70', 'Takhar', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('71', 'Uruzgan', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('72', 'Wardag', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('73', 'Zabul', '1', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('74', 'Berat', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('75', 'Bulqize', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('76', 'Delvine', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('77', 'Devoll', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('78', 'Dibre', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('79', 'Durres', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('80', 'Elbasan', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('81', 'Fier', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('82', 'Gjirokaster', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('83', 'Gramsh', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('84', 'Has', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('85', 'Kavaje', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('86', 'Kolonje', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('87', 'Korce', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('88', 'Kruje', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('89', 'Kucove', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('90', 'Kukes', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('91', 'Kurbin', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('92', 'Lezhe', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('93', 'Librazhd', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('94', 'Lushnje', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('95', 'Mallakaster', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('96', 'Malsi e Madhe', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('97', 'Mat', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('98', 'Mirdite', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('99', 'Peqin', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('100', 'Permet', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('101', 'Pogradec', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('102', 'Puke', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('103', 'Sarande', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('104', 'Shkoder', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('105', 'Skrapar', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('106', 'Tepelene', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('107', 'Tirane', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('108', 'Tropoje', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('109', 'Vlore', '2', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('110', '\'Ayn Daflah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('111', '\'Ayn Tamushanat', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('112', 'Adrar', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('113', 'Algiers', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('114', 'Annabah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('115', 'Bashshar', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('116', 'Batnah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('117', 'Bijayah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('118', 'Biskrah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('119', 'Blidah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('120', 'Buirah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('121', 'Bumardas', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('122', 'Burj Bu Arririj', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('123', 'Ghalizan', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('124', 'Ghardayah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('125', 'Ilizi', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('126', 'Jijili', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('127', 'Jilfah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('128', 'Khanshalah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('129', 'Masilah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('130', 'Midyah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('131', 'Milah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('132', 'Muaskar', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('133', 'Mustaghanam', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('134', 'Naama', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('135', 'Oran', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('136', 'Ouargla', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('137', 'Qalmah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('138', 'Qustantinah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('139', 'Sakikdah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('140', 'Satif', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('141', 'Sayda\'', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('142', 'Sidi ban-al-\'Abbas', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('143', 'Suq Ahras', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('144', 'Tamanghasat', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('145', 'Tibazah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('146', 'Tibissah', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('147', 'Tilimsan', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('148', 'Tinduf', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('149', 'Tisamsilt', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('150', 'Tiyarat', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('151', 'Tizi Wazu', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('152', 'Umm-al-Bawaghi', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('153', 'Wahran', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('154', 'Warqla', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('155', 'Wilaya d Alger', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('156', 'Wilaya de Bejaia', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('157', 'Wilaya de Constantine', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('158', 'al-Aghwat', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('159', 'al-Bayadh', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('160', 'al-Jaza\'ir', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('161', 'al-Wad', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('162', 'ash-Shalif', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('163', 'at-Tarif', '3', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('164', 'Eastern', '4', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('165', 'Manu\'a', '4', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('166', 'Swains Island', '4', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('167', 'Western', '4', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('168', 'Andorra la Vella', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('169', 'Canillo', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('170', 'Encamp', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('171', 'La Massana', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('172', 'Les Escaldes', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('173', 'Ordino', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('174', 'Sant Julia de Loria', '5', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('175', 'Bengo', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('176', 'Benguela', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('177', 'Bie', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('178', 'Cabinda', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('179', 'Cunene', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('180', 'Huambo', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('181', 'Huila', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('182', 'Kuando-Kubango', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('183', 'Kwanza Norte', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('184', 'Kwanza Sul', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('185', 'Luanda', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('186', 'Lunda Norte', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('187', 'Lunda Sul', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('188', 'Malanje', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('189', 'Moxico', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('190', 'Namibe', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('191', 'Uige', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('192', 'Zaire', '6', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('193', 'Other Provinces', '7', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('194', 'Sector claimed by Argentina/Ch', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('195', 'Sector claimed by Argentina/UK', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('196', 'Sector claimed by Australia', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('197', 'Sector claimed by France', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('198', 'Sector claimed by New Zealand', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('199', 'Sector claimed by Norway', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('200', 'Unclaimed Sector', '8', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('201', 'Barbuda', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('202', 'Saint George', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('203', 'Saint John', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('204', 'Saint Mary', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('205', 'Saint Paul', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('206', 'Saint Peter', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('207', 'Saint Philip', '9', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('208', 'Buenos Aires', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('209', 'Catamarca', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('210', 'Chaco', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('211', 'Chubut', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('212', 'Cordoba', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('213', 'Corrientes', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('214', 'Distrito Federal', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('215', 'Entre Rios', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('216', 'Formosa', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('217', 'Jujuy', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('218', 'La Pampa', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('219', 'La Rioja', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('220', 'Mendoza', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('221', 'Misiones', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('222', 'Neuquen', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('223', 'Rio Negro', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('224', 'Salta', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('225', 'San Juan', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('226', 'San Luis', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('227', 'Santa Cruz', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('228', 'Santa Fe', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('229', 'Santiago del Estero', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('230', 'Tierra del Fuego', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('231', 'Tucuman', '10', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('232', 'Aragatsotn', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('233', 'Ararat', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('234', 'Armavir', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('235', 'Gegharkunik', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('236', 'Kotaik', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('237', 'Lori', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('238', 'Shirak', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('239', 'Stepanakert', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('240', 'Syunik', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('241', 'Tavush', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('242', 'Vayots Dzor', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('243', 'Yerevan', '11', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('244', 'Aruba', '12', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('245', 'Auckland', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('246', 'Australian Capital Territory', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('247', 'Balgowlah', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('248', 'Balmain', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('249', 'Bankstown', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('250', 'Baulkham Hills', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('251', 'Bonnet Bay', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('252', 'Camberwell', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('253', 'Carole Park', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('254', 'Castle Hill', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('255', 'Caulfield', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('256', 'Chatswood', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('257', 'Cheltenham', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('258', 'Cherrybrook', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('259', 'Clayton', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('260', 'Collingwood', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('261', 'Frenchs Forest', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('262', 'Hawthorn', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('263', 'Jannnali', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('264', 'Knoxfield', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('265', 'Melbourne', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('266', 'New South Wales', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('267', 'Northern Territory', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('268', 'Perth', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('269', 'Queensland', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('270', 'South Australia', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('271', 'Tasmania', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('272', 'Templestowe', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('273', 'Victoria', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('274', 'Werribee south', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('275', 'Western Australia', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('276', 'Wheeler', '13', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('277', 'Bundesland Salzburg', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('278', 'Bundesland Steiermark', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('279', 'Bundesland Tirol', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('280', 'Burgenland', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('281', 'Carinthia', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('282', 'Karnten', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('283', 'Liezen', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('284', 'Lower Austria', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('285', 'Niederosterreich', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('286', 'Oberosterreich', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('287', 'Salzburg', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('288', 'Schleswig-Holstein', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('289', 'Steiermark', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('290', 'Styria', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('291', 'Tirol', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('292', 'Upper Austria', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('293', 'Vorarlberg', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('294', 'Wien', '14', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('295', 'Abseron', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('296', 'Baki Sahari', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('297', 'Ganca', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('298', 'Ganja', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('299', 'Kalbacar', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('300', 'Lankaran', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('301', 'Mil-Qarabax', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('302', 'Mugan-Salyan', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('303', 'Nagorni-Qarabax', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('304', 'Naxcivan', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('305', 'Priaraks', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('306', 'Qazax', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('307', 'Saki', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('308', 'Sirvan', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('309', 'Xacmaz', '15', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('310', 'Abaco', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('311', 'Acklins Island', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('312', 'Andros', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('313', 'Berry Islands', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('314', 'Biminis', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('315', 'Cat Island', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('316', 'Crooked Island', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('317', 'Eleuthera', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('318', 'Exuma and Cays', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('319', 'Grand Bahama', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('320', 'Inagua Islands', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('321', 'Long Island', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('322', 'Mayaguana', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('323', 'New Providence', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('324', 'Ragged Island', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('325', 'Rum Cay', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('326', 'San Salvador', '16', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('327', '\'Isa', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('328', 'Badiyah', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('329', 'Hidd', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('330', 'Jidd Hafs', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('331', 'Mahama', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('332', 'Manama', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('333', 'Sitrah', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('334', 'al-Manamah', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('335', 'al-Muharraq', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('336', 'ar-Rifa\'a', '17', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('337', 'Bagar Hat', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('338', 'Bandarban', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('339', 'Barguna', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('340', 'Barisal', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('341', 'Bhola', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('342', 'Bogora', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('343', 'Brahman Bariya', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('344', 'Chandpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('345', 'Chattagam', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('346', 'Chittagong Division', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('347', 'Chuadanga', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('348', 'Dhaka', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('349', 'Dinajpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('350', 'Faridpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('351', 'Feni', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('352', 'Gaybanda', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('353', 'Gazipur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('354', 'Gopalganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('355', 'Habiganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('356', 'Jaipur Hat', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('357', 'Jamalpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('358', 'Jessor', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('359', 'Jhalakati', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('360', 'Jhanaydah', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('361', 'Khagrachhari', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('362', 'Khulna', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('363', 'Kishorganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('364', 'Koks Bazar', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('365', 'Komilla', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('366', 'Kurigram', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('367', 'Kushtiya', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('368', 'Lakshmipur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('369', 'Lalmanir Hat', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('370', 'Madaripur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('371', 'Magura', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('372', 'Maimansingh', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('373', 'Manikganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('374', 'Maulvi Bazar', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('375', 'Meherpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('376', 'Munshiganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('377', 'Naral', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('378', 'Narayanganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('379', 'Narsingdi', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('380', 'Nator', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('381', 'Naugaon', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('382', 'Nawabganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('383', 'Netrakona', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('384', 'Nilphamari', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('385', 'Noakhali', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('386', 'Pabna', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('387', 'Panchagarh', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('388', 'Patuakhali', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('389', 'Pirojpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('390', 'Rajbari', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('391', 'Rajshahi', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('392', 'Rangamati', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('393', 'Rangpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('394', 'Satkhira', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('395', 'Shariatpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('396', 'Sherpur', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('397', 'Silhat', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('398', 'Sirajganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('399', 'Sunamganj', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('400', 'Tangayal', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('401', 'Thakurgaon', '18', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('402', 'Christ Church', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('403', 'Saint Andrew', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('404', 'Saint George', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('405', 'Saint James', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('406', 'Saint John', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('407', 'Saint Joseph', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('408', 'Saint Lucy', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('409', 'Saint Michael', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('410', 'Saint Peter', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('411', 'Saint Philip', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('412', 'Saint Thomas', '19', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('413', 'Brest', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('414', 'Homjel\'', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('415', 'Hrodna', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('416', 'Mahiljow', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('417', 'Mahilyowskaya Voblasts', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('418', 'Minsk', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('419', 'Minskaja Voblasts\'', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('420', 'Petrik', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('421', 'Vicebsk', '20', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('422', 'Antwerpen', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('423', 'Berchem', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('424', 'Brabant', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('425', 'Brabant Wallon', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('426', 'Brussel', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('427', 'East Flanders', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('428', 'Hainaut', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('429', 'Liege', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('430', 'Limburg', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('431', 'Luxembourg', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('432', 'Namur', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('433', 'Ontario', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('434', 'Oost-Vlaanderen', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('435', 'Provincie Brabant', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('436', 'Vlaams-Brabant', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('437', 'Wallonne', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('438', 'West-Vlaanderen', '21', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('439', 'Belize', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('440', 'Cayo', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('441', 'Corozal', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('442', 'Orange Walk', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('443', 'Stann Creek', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('444', 'Toledo', '22', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('445', 'Alibori', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('446', 'Atacora', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('447', 'Atlantique', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('448', 'Borgou', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('449', 'Collines', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('450', 'Couffo', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('451', 'Donga', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('452', 'Littoral', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('453', 'Mono', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('454', 'Oueme', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('455', 'Plateau', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('456', 'Zou', '23', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('457', 'Hamilton', '24', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('458', 'Saint George', '24', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('459', 'Bumthang', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('460', 'Chhukha', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('461', 'Chirang', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('462', 'Daga', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('463', 'Geylegphug', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('464', 'Ha', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('465', 'Lhuntshi', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('466', 'Mongar', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('467', 'Pemagatsel', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('468', 'Punakha', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('469', 'Rinpung', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('470', 'Samchi', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('471', 'Samdrup Jongkhar', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('472', 'Shemgang', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('473', 'Tashigang', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('474', 'Timphu', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('475', 'Tongsa', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('476', 'Wangdiphodrang', '25', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('477', 'Beni', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('478', 'Chuquisaca', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('479', 'Cochabamba', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('480', 'La Paz', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('481', 'Oruro', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('482', 'Pando', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('483', 'Potosi', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('484', 'Santa Cruz', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('485', 'Tarija', '26', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('486', 'Federacija Bosna i Hercegovina', '27', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('487', 'Republika Srpska', '27', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('488', 'Central Bobonong', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('489', 'Central Boteti', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('490', 'Central Mahalapye', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('491', 'Central Serowe-Palapye', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('492', 'Central Tutume', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('493', 'Chobe', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('494', 'Francistown', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('495', 'Gaborone', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('496', 'Ghanzi', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('497', 'Jwaneng', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('498', 'Kgalagadi North', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('499', 'Kgalagadi South', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('500', 'Kgatleng', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('501', 'Kweneng', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('502', 'Lobatse', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('503', 'Ngamiland', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('504', 'Ngwaketse', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('505', 'North East', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('506', 'Okavango', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('507', 'Orapa', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('508', 'Selibe Phikwe', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('509', 'South East', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('510', 'Sowa', '28', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('511', 'Bouvet Island', '29', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('512', 'Acre', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('513', 'Alagoas', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('514', 'Amapa', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('515', 'Amazonas', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('516', 'Bahia', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('517', 'Ceara', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('518', 'Distrito Federal', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('519', 'Espirito Santo', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('520', 'Estado de Sao Paulo', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('521', 'Goias', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('522', 'Maranhao', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('523', 'Mato Grosso', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('524', 'Mato Grosso do Sul', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('525', 'Minas Gerais', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('526', 'Para', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('527', 'Paraiba', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('528', 'Parana', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('529', 'Pernambuco', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('530', 'Piaui', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('531', 'Rio Grande do Norte', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('532', 'Rio Grande do Sul', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('533', 'Rio de Janeiro', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('534', 'Rondonia', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('535', 'Roraima', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('536', 'Santa Catarina', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('537', 'Sao Paulo', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('538', 'Sergipe', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('539', 'Tocantins', '30', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('540', 'British Indian Ocean Territory', '31', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('541', 'Belait', '32', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('542', 'Brunei-Muara', '32', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('543', 'Temburong', '32', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('544', 'Tutong', '32', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('545', 'Blagoevgrad', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('546', 'Burgas', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('547', 'Dobrich', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('548', 'Gabrovo', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('549', 'Haskovo', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('550', 'Jambol', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('551', 'Kardzhali', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('552', 'Kjustendil', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('553', 'Lovech', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('554', 'Montana', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('555', 'Oblast Sofiya-Grad', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('556', 'Pazardzhik', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('557', 'Pernik', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('558', 'Pleven', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('559', 'Plovdiv', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('560', 'Razgrad', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('561', 'Ruse', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('562', 'Shumen', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('563', 'Silistra', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('564', 'Sliven', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('565', 'Smoljan', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('566', 'Sofija grad', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('567', 'Sofijska oblast', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('568', 'Stara Zagora', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('569', 'Targovishte', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('570', 'Varna', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('571', 'Veliko Tarnovo', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('572', 'Vidin', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('573', 'Vraca', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('574', 'Yablaniza', '33', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('575', 'Bale', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('576', 'Bam', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('577', 'Bazega', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('578', 'Bougouriba', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('579', 'Boulgou', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('580', 'Boulkiemde', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('581', 'Comoe', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('582', 'Ganzourgou', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('583', 'Gnagna', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('584', 'Gourma', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('585', 'Houet', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('586', 'Ioba', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('587', 'Kadiogo', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('588', 'Kenedougou', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('589', 'Komandjari', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('590', 'Kompienga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('591', 'Kossi', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('592', 'Kouritenga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('593', 'Kourweogo', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('594', 'Leraba', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('595', 'Mouhoun', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('596', 'Nahouri', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('597', 'Namentenga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('598', 'Noumbiel', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('599', 'Oubritenga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('600', 'Oudalan', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('601', 'Passore', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('602', 'Poni', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('603', 'Sanguie', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('604', 'Sanmatenga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('605', 'Seno', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('606', 'Sissili', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('607', 'Soum', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('608', 'Sourou', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('609', 'Tapoa', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('610', 'Tuy', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('611', 'Yatenga', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('612', 'Zondoma', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('613', 'Zoundweogo', '34', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('614', 'Bubanza', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('615', 'Bujumbura', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('616', 'Bururi', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('617', 'Cankuzo', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('618', 'Cibitoke', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('619', 'Gitega', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('620', 'Karuzi', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('621', 'Kayanza', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('622', 'Kirundo', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('623', 'Makamba', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('624', 'Muramvya', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('625', 'Muyinga', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('626', 'Ngozi', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('627', 'Rutana', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('628', 'Ruyigi', '35', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('629', 'Banteay Mean Chey', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('630', 'Bat Dambang', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('631', 'Kampong Cham', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('632', 'Kampong Chhnang', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('633', 'Kampong Spoeu', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('634', 'Kampong Thum', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('635', 'Kampot', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('636', 'Kandal', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('637', 'Kaoh Kong', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('638', 'Kracheh', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('639', 'Krong Kaeb', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('640', 'Krong Pailin', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('641', 'Krong Preah Sihanouk', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('642', 'Mondol Kiri', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('643', 'Otdar Mean Chey', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('644', 'Phnum Penh', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('645', 'Pousat', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('646', 'Preah Vihear', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('647', 'Prey Veaeng', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('648', 'Rotanak Kiri', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('649', 'Siem Reab', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('650', 'Stueng Traeng', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('651', 'Svay Rieng', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('652', 'Takaev', '36', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('653', 'Adamaoua', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('654', 'Centre', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('655', 'Est', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('656', 'Littoral', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('657', 'Nord', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('658', 'Nord Extreme', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('659', 'Nordouest', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('660', 'Ouest', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('661', 'Sud', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('662', 'Sudouest', '37', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('663', 'Alberta', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('664', 'British Columbia', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('665', 'Manitoba', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('666', 'New Brunswick', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('667', 'Newfoundland and Labrador', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('668', 'Northwest Territories', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('669', 'Nova Scotia', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('670', 'Nunavut', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('671', 'Ontario', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('672', 'Prince Edward Island', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('673', 'Quebec', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('674', 'Saskatchewan', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('675', 'Yukon', '38', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('676', 'Boavista', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('677', 'Brava', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('678', 'Fogo', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('679', 'Maio', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('680', 'Sal', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('681', 'Santo Antao', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('682', 'Sao Nicolau', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('683', 'Sao Tiago', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('684', 'Sao Vicente', '39', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('685', 'Grand Cayman', '40', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('686', 'Bamingui-Bangoran', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('687', 'Bangui', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('688', 'Basse-Kotto', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('689', 'Haut-Mbomou', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('690', 'Haute-Kotto', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('691', 'Kemo', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('692', 'Lobaye', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('693', 'Mambere-Kadei', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('694', 'Mbomou', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('695', 'Nana-Gribizi', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('696', 'Nana-Mambere', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('697', 'Ombella Mpoko', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('698', 'Ouaka', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('699', 'Ouham', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('700', 'Ouham-Pende', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('701', 'Sangha-Mbaere', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('702', 'Vakaga', '41', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('703', 'Batha', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('704', 'Biltine', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('705', 'Bourkou-Ennedi-Tibesti', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('706', 'Chari-Baguirmi', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('707', 'Guera', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('708', 'Kanem', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('709', 'Lac', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('710', 'Logone Occidental', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('711', 'Logone Oriental', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('712', 'Mayo-Kebbi', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('713', 'Moyen-Chari', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('714', 'Ouaddai', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('715', 'Salamat', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('716', 'Tandjile', '42', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('717', 'Aisen', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('718', 'Antofagasta', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('719', 'Araucania', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('720', 'Atacama', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('721', 'Bio Bio', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('722', 'Coquimbo', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('723', 'Libertador General Bernardo O\'', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('724', 'Los Lagos', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('725', 'Magellanes', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('726', 'Maule', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('727', 'Metropolitana', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('728', 'Metropolitana de Santiago', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('729', 'Tarapaca', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('730', 'Valparaiso', '43', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('731', 'Anhui', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('732', 'Anhui Province', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('733', 'Anhui Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('734', 'Aomen', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('735', 'Beijing', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('736', 'Beijing Shi', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('737', 'Chongqing', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('738', 'Fujian', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('739', 'Fujian Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('740', 'Gansu', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('741', 'Guangdong', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('742', 'Guangdong Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('743', 'Guangxi', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('744', 'Guizhou', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('745', 'Hainan', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('746', 'Hebei', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('747', 'Heilongjiang', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('748', 'Henan', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('749', 'Hubei', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('750', 'Hunan', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('751', 'Jiangsu', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('752', 'Jiangsu Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('753', 'Jiangxi', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('754', 'Jilin', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('755', 'Liaoning', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('756', 'Liaoning Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('757', 'Nei Monggol', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('758', 'Ningxia Hui', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('759', 'Qinghai', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('760', 'Shaanxi', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('761', 'Shandong', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('762', 'Shandong Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('763', 'Shanghai', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('764', 'Shanxi', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('765', 'Sichuan', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('766', 'Tianjin', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('767', 'Xianggang', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('768', 'Xinjiang', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('769', 'Xizang', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('770', 'Yunnan', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('771', 'Zhejiang', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('772', 'Zhejiang Sheng', '44', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('773', 'Christmas Island', '45', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('774', 'Cocos (Keeling) Islands', '46', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('775', 'Amazonas', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('776', 'Antioquia', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('777', 'Arauca', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('778', 'Atlantico', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('779', 'Bogota', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('780', 'Bolivar', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('781', 'Boyaca', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('782', 'Caldas', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('783', 'Caqueta', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('784', 'Casanare', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('785', 'Cauca', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('786', 'Cesar', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('787', 'Choco', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('788', 'Cordoba', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('789', 'Cundinamarca', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('790', 'Guainia', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('791', 'Guaviare', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('792', 'Huila', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('793', 'La Guajira', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('794', 'Magdalena', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('795', 'Meta', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('796', 'Narino', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('797', 'Norte de Santander', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('798', 'Putumayo', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('799', 'Quindio', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('800', 'Risaralda', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('801', 'San Andres y Providencia', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('802', 'Santander', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('803', 'Sucre', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('804', 'Tolima', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('805', 'Valle del Cauca', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('806', 'Vaupes', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('807', 'Vichada', '47', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('808', 'Mwali', '48', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('809', 'Njazidja', '48', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('810', 'Nzwani', '48', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('811', 'Bouenza', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('812', 'Brazzaville', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('813', 'Cuvette', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('814', 'Kouilou', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('815', 'Lekoumou', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('816', 'Likouala', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('817', 'Niari', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('818', 'Plateaux', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('819', 'Pool', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('820', 'Sangha', '49', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('821', 'Bandundu', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('822', 'Bas-Congo', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('823', 'Equateur', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('824', 'Haut-Congo', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('825', 'Kasai-Occidental', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('826', 'Kasai-Oriental', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('827', 'Katanga', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('828', 'Kinshasa', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('829', 'Maniema', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('830', 'Nord-Kivu', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('831', 'Sud-Kivu', '50', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('832', 'Aitutaki', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('833', 'Atiu', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('834', 'Mangaia', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('835', 'Manihiki', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('836', 'Mauke', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('837', 'Mitiaro', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('838', 'Nassau', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('839', 'Pukapuka', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('840', 'Rakahanga', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('841', 'Rarotonga', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('842', 'Tongareva', '51', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('843', 'Alajuela', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('844', 'Cartago', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('845', 'Guanacaste', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('846', 'Heredia', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('847', 'Limon', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('848', 'Puntarenas', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('849', 'San Jose', '52', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('850', 'Abidjan', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('851', 'Agneby', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('852', 'Bafing', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('853', 'Denguele', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('854', 'Dix-huit Montagnes', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('855', 'Fromager', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('856', 'Haut-Sassandra', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('857', 'Lacs', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('858', 'Lagunes', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('859', 'Marahoue', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('860', 'Moyen-Cavally', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('861', 'Moyen-Comoe', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('862', 'N\'zi-Comoe', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('863', 'Sassandra', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('864', 'Savanes', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('865', 'Sud-Bandama', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('866', 'Sud-Comoe', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('867', 'Vallee du Bandama', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('868', 'Worodougou', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('869', 'Zanzan', '53', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('870', 'Bjelovar-Bilogora', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('871', 'Dubrovnik-Neretva', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('872', 'Grad Zagreb', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('873', 'Istra', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('874', 'Karlovac', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('875', 'Koprivnica-Krizhevci', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('876', 'Krapina-Zagorje', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('877', 'Lika-Senj', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('878', 'Medhimurje', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('879', 'Medimurska Zupanija', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('880', 'Osijek-Baranja', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('881', 'Osjecko-Baranjska Zupanija', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('882', 'Pozhega-Slavonija', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('883', 'Primorje-Gorski Kotar', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('884', 'Shibenik-Knin', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('885', 'Sisak-Moslavina', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('886', 'Slavonski Brod-Posavina', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('887', 'Split-Dalmacija', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('888', 'Varazhdin', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('889', 'Virovitica-Podravina', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('890', 'Vukovar-Srijem', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('891', 'Zadar', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('892', 'Zagreb', '54', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('893', 'Camaguey', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('894', 'Ciego de Avila', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('895', 'Cienfuegos', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('896', 'Ciudad de la Habana', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('897', 'Granma', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('898', 'Guantanamo', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('899', 'Habana', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('900', 'Holguin', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('901', 'Isla de la Juventud', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('902', 'La Habana', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('903', 'Las Tunas', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('904', 'Matanzas', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('905', 'Pinar del Rio', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('906', 'Sancti Spiritus', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('907', 'Santiago de Cuba', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('908', 'Villa Clara', '55', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('909', 'Government controlled area', '56', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('910', 'Limassol', '56', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('911', 'Nicosia District', '56', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('912', 'Paphos', '56', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('913', 'Turkish controlled area', '56', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('914', 'Central Bohemian', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('915', 'Frycovice', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('916', 'Jihocesky Kraj', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('917', 'Jihochesky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('918', 'Jihomoravsky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('919', 'Karlovarsky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('920', 'Klecany', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('921', 'Kralovehradecky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('922', 'Liberecky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('923', 'Lipov', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('924', 'Moravskoslezsky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('925', 'Olomoucky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('926', 'Olomoucky Kraj', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('927', 'Pardubicky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('928', 'Plzensky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('929', 'Praha', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('930', 'Rajhrad', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('931', 'Smirice', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('932', 'South Moravian', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('933', 'Straz nad Nisou', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('934', 'Stredochesky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('935', 'Unicov', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('936', 'Ustecky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('937', 'Valletta', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('938', 'Velesin', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('939', 'Vysochina', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('940', 'Zlinsky', '57', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('941', 'Arhus', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('942', 'Bornholm', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('943', 'Frederiksborg', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('944', 'Fyn', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('945', 'Hovedstaden', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('946', 'Kobenhavn', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('947', 'Kobenhavns Amt', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('948', 'Kobenhavns Kommune', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('949', 'Nordjylland', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('950', 'Ribe', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('951', 'Ringkobing', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('952', 'Roervig', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('953', 'Roskilde', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('954', 'Roslev', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('955', 'Sjaelland', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('956', 'Soeborg', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('957', 'Sonderjylland', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('958', 'Storstrom', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('959', 'Syddanmark', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('960', 'Toelloese', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('961', 'Vejle', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('962', 'Vestsjalland', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('963', 'Viborg', '58', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('964', '\'Ali Sabih', '59', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('965', 'Dikhil', '59', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('966', 'Jibuti', '59', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('967', 'Tajurah', '59', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('968', 'Ubuk', '59', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('969', 'Saint Andrew', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('970', 'Saint David', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('971', 'Saint George', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('972', 'Saint John', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('973', 'Saint Joseph', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('974', 'Saint Luke', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('975', 'Saint Mark', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('976', 'Saint Patrick', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('977', 'Saint Paul', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('978', 'Saint Peter', '60', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('979', 'Azua', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('980', 'Bahoruco', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('981', 'Barahona', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('982', 'Dajabon', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('983', 'Distrito Nacional', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('984', 'Duarte', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('985', 'El Seybo', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('986', 'Elias Pina', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('987', 'Espaillat', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('988', 'Hato Mayor', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('989', 'Independencia', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('990', 'La Altagracia', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('991', 'La Romana', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('992', 'La Vega', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('993', 'Maria Trinidad Sanchez', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('994', 'Monsenor Nouel', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('995', 'Monte Cristi', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('996', 'Monte Plata', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('997', 'Pedernales', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('998', 'Peravia', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('999', 'Puerto Plata', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1000', 'Salcedo', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1001', 'Samana', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1002', 'San Cristobal', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1003', 'San Juan', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1004', 'San Pedro de Macoris', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1005', 'Sanchez Ramirez', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1006', 'Santiago', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1007', 'Santiago Rodriguez', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1008', 'Valverde', '61', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1009', 'Aileu', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1010', 'Ainaro', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1011', 'Ambeno', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1012', 'Baucau', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1013', 'Bobonaro', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1014', 'Cova Lima', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1015', 'Dili', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1016', 'Ermera', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1017', 'Lautem', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1018', 'Liquica', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1019', 'Manatuto', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1020', 'Manufahi', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1021', 'Viqueque', '62', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1022', 'Azuay', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1023', 'Bolivar', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1024', 'Canar', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1025', 'Carchi', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1026', 'Chimborazo', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1027', 'Cotopaxi', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1028', 'El Oro', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1029', 'Esmeraldas', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1030', 'Galapagos', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1031', 'Guayas', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1032', 'Imbabura', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1033', 'Loja', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1034', 'Los Rios', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1035', 'Manabi', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1036', 'Morona Santiago', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1037', 'Napo', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1038', 'Orellana', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1039', 'Pastaza', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1040', 'Pichincha', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1041', 'Sucumbios', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1042', 'Tungurahua', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1043', 'Zamora Chinchipe', '63', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1044', 'Aswan', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1045', 'Asyut', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1046', 'Bani Suwayf', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1047', 'Bur Sa\'id', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1048', 'Cairo', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1049', 'Dumyat', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1050', 'Kafr-ash-Shaykh', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1051', 'Matruh', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1052', 'Muhafazat ad Daqahliyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1053', 'Muhafazat al Fayyum', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1054', 'Muhafazat al Gharbiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1055', 'Muhafazat al Iskandariyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1056', 'Muhafazat al Qahirah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1057', 'Qina', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1058', 'Sawhaj', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1059', 'Sina al-Janubiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1060', 'Sina ash-Shamaliyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1061', 'ad-Daqahliyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1062', 'al-Bahr-al-Ahmar', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1063', 'al-Buhayrah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1064', 'al-Fayyum', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1065', 'al-Gharbiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1066', 'al-Iskandariyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1067', 'al-Ismailiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1068', 'al-Jizah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1069', 'al-Minufiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1070', 'al-Minya', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1071', 'al-Qahira', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1072', 'al-Qalyubiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1073', 'al-Uqsur', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1074', 'al-Wadi al-Jadid', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1075', 'as-Suways', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1076', 'ash-Sharqiyah', '64', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1077', 'Ahuachapan', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1078', 'Cabanas', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1079', 'Chalatenango', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1080', 'Cuscatlan', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1081', 'La Libertad', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1082', 'La Paz', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1083', 'La Union', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1084', 'Morazan', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1085', 'San Miguel', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1086', 'San Salvador', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1087', 'San Vicente', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1088', 'Santa Ana', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1089', 'Sonsonate', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1090', 'Usulutan', '65', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1091', 'Annobon', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1092', 'Bioko Norte', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1093', 'Bioko Sur', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1094', 'Centro Sur', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1095', 'Kie-Ntem', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1096', 'Litoral', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1097', 'Wele-Nzas', '66', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1098', 'Anseba', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1099', 'Debub', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1100', 'Debub-Keih-Bahri', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1101', 'Gash-Barka', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1102', 'Maekel', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1103', 'Semien-Keih-Bahri', '67', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1104', 'Harju', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1105', 'Hiiu', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1106', 'Ida-Viru', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1107', 'Jarva', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1108', 'Jogeva', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1109', 'Laane', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1110', 'Laane-Viru', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1111', 'Parnu', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1112', 'Polva', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1113', 'Rapla', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1114', 'Saare', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1115', 'Tartu', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1116', 'Valga', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1117', 'Viljandi', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1118', 'Voru', '68', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1119', 'Addis Abeba', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1120', 'Afar', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1121', 'Amhara', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1122', 'Benishangul', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1123', 'Diredawa', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1124', 'Gambella', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1125', 'Harar', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1126', 'Jigjiga', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1127', 'Mekele', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1128', 'Oromia', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1129', 'Somali', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1130', 'Southern', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1131', 'Tigray', '69', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1132', 'Christmas Island', '70', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1133', 'Cocos Islands', '70', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1134', 'Coral Sea Islands', '70', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1135', 'Falkland Islands', '71', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1136', 'South Georgia', '71', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1137', 'Klaksvik', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1138', 'Nor ara Eysturoy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1139', 'Nor oy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1140', 'Sandoy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1141', 'Streymoy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1142', 'Su uroy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1143', 'Sy ra Eysturoy', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1144', 'Torshavn', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1145', 'Vaga', '72', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1146', 'Central', '73', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1147', 'Eastern', '73', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1148', 'Northern', '73', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1149', 'South Pacific', '73', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1150', 'Western', '73', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1151', 'Ahvenanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1152', 'Etela-Karjala', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1153', 'Etela-Pohjanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1154', 'Etela-Savo', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1155', 'Etela-Suomen Laani', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1156', 'Ita-Suomen Laani', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1157', 'Ita-Uusimaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1158', 'Kainuu', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1159', 'Kanta-Hame', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1160', 'Keski-Pohjanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1161', 'Keski-Suomi', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1162', 'Kymenlaakso', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1163', 'Lansi-Suomen Laani', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1164', 'Lappi', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1165', 'Northern Savonia', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1166', 'Ostrobothnia', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1167', 'Oulun Laani', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1168', 'Paijat-Hame', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1169', 'Pirkanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1170', 'Pohjanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1171', 'Pohjois-Karjala', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1172', 'Pohjois-Pohjanmaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1173', 'Pohjois-Savo', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1174', 'Saarijarvi', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1175', 'Satakunta', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1176', 'Southern Savonia', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1177', 'Tavastia Proper', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1178', 'Uleaborgs Lan', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1179', 'Uusimaa', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1180', 'Varsinais-Suomi', '74', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1181', 'Ain', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1182', 'Aisne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1183', 'Albi Le Sequestre', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1184', 'Allier', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1185', 'Alpes-Cote dAzur', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1186', 'Alpes-Maritimes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1187', 'Alpes-de-Haute-Provence', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1188', 'Alsace', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1189', 'Aquitaine', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1190', 'Ardeche', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1191', 'Ardennes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1192', 'Ariege', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1193', 'Aube', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1194', 'Aude', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1195', 'Auvergne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1196', 'Aveyron', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1197', 'Bas-Rhin', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1198', 'Basse-Normandie', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1199', 'Bouches-du-Rhone', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1200', 'Bourgogne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1201', 'Bretagne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1202', 'Brittany', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1203', 'Burgundy', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1204', 'Calvados', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1205', 'Cantal', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1206', 'Cedex', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1207', 'Centre', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1208', 'Charente', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1209', 'Charente-Maritime', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1210', 'Cher', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1211', 'Correze', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1212', 'Corse-du-Sud', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1213', 'Cote-d\'Or', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1214', 'Cotes-d\'Armor', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1215', 'Creuse', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1216', 'Crolles', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1217', 'Deux-Sevres', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1218', 'Dordogne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1219', 'Doubs', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1220', 'Drome', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1221', 'Essonne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1222', 'Eure', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1223', 'Eure-et-Loir', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1224', 'Feucherolles', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1225', 'Finistere', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1226', 'Franche-Comte', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1227', 'Gard', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1228', 'Gers', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1229', 'Gironde', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1230', 'Haut-Rhin', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1231', 'Haute-Corse', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1232', 'Haute-Garonne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1233', 'Haute-Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1234', 'Haute-Marne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1235', 'Haute-Saone', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1236', 'Haute-Savoie', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1237', 'Haute-Vienne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1238', 'Hautes-Alpes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1239', 'Hautes-Pyrenees', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1240', 'Hauts-de-Seine', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1241', 'Herault', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1242', 'Ile-de-France', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1243', 'Ille-et-Vilaine', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1244', 'Indre', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1245', 'Indre-et-Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1246', 'Isere', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1247', 'Jura', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1248', 'Klagenfurt', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1249', 'Landes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1250', 'Languedoc-Roussillon', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1251', 'Larcay', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1252', 'Le Castellet', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1253', 'Le Creusot', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1254', 'Limousin', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1255', 'Loir-et-Cher', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1256', 'Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1257', 'Loire-Atlantique', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1258', 'Loiret', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1259', 'Lorraine', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1260', 'Lot', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1261', 'Lot-et-Garonne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1262', 'Lower Normandy', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1263', 'Lozere', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1264', 'Maine-et-Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1265', 'Manche', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1266', 'Marne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1267', 'Mayenne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1268', 'Meurthe-et-Moselle', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1269', 'Meuse', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1270', 'Midi-Pyrenees', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1271', 'Morbihan', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1272', 'Moselle', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1273', 'Nievre', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1274', 'Nord', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1275', 'Nord-Pas-de-Calais', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1276', 'Oise', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1277', 'Orne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1278', 'Paris', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1279', 'Pas-de-Calais', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1280', 'Pays de la Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1281', 'Pays-de-la-Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1282', 'Picardy', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1283', 'Puy-de-Dome', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1284', 'Pyrenees-Atlantiques', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1285', 'Pyrenees-Orientales', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1286', 'Quelmes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1287', 'Rhone', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1288', 'Rhone-Alpes', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1289', 'Saint Ouen', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1290', 'Saint Viatre', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1291', 'Saone-et-Loire', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1292', 'Sarthe', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1293', 'Savoie', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1294', 'Seine-Maritime', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1295', 'Seine-Saint-Denis', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1296', 'Seine-et-Marne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1297', 'Somme', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1298', 'Sophia Antipolis', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1299', 'Souvans', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1300', 'Tarn', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1301', 'Tarn-et-Garonne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1302', 'Territoire de Belfort', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1303', 'Treignac', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1304', 'Upper Normandy', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1305', 'Val-d\'Oise', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1306', 'Val-de-Marne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1307', 'Var', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1308', 'Vaucluse', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1309', 'Vellise', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1310', 'Vendee', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1311', 'Vienne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1312', 'Vosges', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1313', 'Yonne', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1314', 'Yvelines', '75', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1315', 'Cayenne', '76', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1316', 'Saint-Laurent-du-Maroni', '76', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1317', 'Iles du Vent', '77', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1318', 'Iles sous le Vent', '77', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1319', 'Marquesas', '77', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1320', 'Tuamotu', '77', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1321', 'Tubuai', '77', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1322', 'Amsterdam', '78', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1323', 'Crozet Islands', '78', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1324', 'Kerguelen', '78', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1325', 'Estuaire', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1326', 'Haut-Ogooue', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1327', 'Moyen-Ogooue', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1328', 'Ngounie', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1329', 'Nyanga', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1330', 'Ogooue-Ivindo', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1331', 'Ogooue-Lolo', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1332', 'Ogooue-Maritime', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1333', 'Woleu-Ntem', '79', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1334', 'Banjul', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1335', 'Basse', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1336', 'Brikama', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1337', 'Janjanbureh', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1338', 'Kanifing', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1339', 'Kerewan', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1340', 'Kuntaur', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1341', 'Mansakonko', '80', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1342', 'Abhasia', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1343', 'Ajaria', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1344', 'Guria', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1345', 'Imereti', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1346', 'Kaheti', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1347', 'Kvemo Kartli', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1348', 'Mcheta-Mtianeti', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1349', 'Racha', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1350', 'Samagrelo-Zemo Svaneti', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1351', 'Samche-Zhavaheti', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1352', 'Shida Kartli', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1353', 'Tbilisi', '81', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1354', 'Auvergne', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1355', 'Baden-Wurttemberg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1356', 'Bavaria', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1357', 'Bayern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1358', 'Beilstein Wurtt', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1359', 'Berlin', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1360', 'Brandenburg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1361', 'Bremen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1362', 'Dreisbach', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1363', 'Freistaat Bayern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1364', 'Hamburg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1365', 'Hannover', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1366', 'Heroldstatt', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1367', 'Hessen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1368', 'Kortenberg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1369', 'Laasdorf', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1370', 'Land Baden-Wurttemberg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1371', 'Land Bayern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1372', 'Land Brandenburg', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1373', 'Land Hessen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1374', 'Land Mecklenburg-Vorpommern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1375', 'Land Nordrhein-Westfalen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1376', 'Land Rheinland-Pfalz', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1377', 'Land Sachsen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1378', 'Land Sachsen-Anhalt', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1379', 'Land Thuringen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1380', 'Lower Saxony', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1381', 'Mecklenburg-Vorpommern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1382', 'Mulfingen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1383', 'Munich', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1384', 'Neubeuern', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1385', 'Niedersachsen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1386', 'Noord-Holland', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1387', 'Nordrhein-Westfalen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1388', 'North Rhine-Westphalia', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1389', 'Osterode', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1390', 'Rheinland-Pfalz', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1391', 'Rhineland-Palatinate', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1392', 'Saarland', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1393', 'Sachsen', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1394', 'Sachsen-Anhalt', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1395', 'Saxony', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1396', 'Schleswig-Holstein', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1397', 'Thuringia', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1398', 'Webling', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1399', 'Weinstrabe', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1400', 'schlobborn', '82', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1401', 'Ashanti', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1402', 'Brong-Ahafo', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1403', 'Central', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1404', 'Eastern', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1405', 'Greater Accra', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1406', 'Northern', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1407', 'Upper East', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1408', 'Upper West', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1409', 'Volta', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1410', 'Western', '83', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1411', 'Gibraltar', '84', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1412', 'Acharnes', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1413', 'Ahaia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1414', 'Aitolia kai Akarnania', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1415', 'Argolis', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1416', 'Arkadia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1417', 'Arta', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1418', 'Attica', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1419', 'Attiki', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1420', 'Ayion Oros', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1421', 'Crete', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1422', 'Dodekanisos', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1423', 'Drama', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1424', 'Evia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1425', 'Evritania', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1426', 'Evros', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1427', 'Evvoia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1428', 'Florina', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1429', 'Fokis', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1430', 'Fthiotis', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1431', 'Grevena', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1432', 'Halandri', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1433', 'Halkidiki', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1434', 'Hania', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1435', 'Heraklion', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1436', 'Hios', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1437', 'Ilia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1438', 'Imathia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1439', 'Ioannina', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1440', 'Iraklion', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1441', 'Karditsa', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1442', 'Kastoria', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1443', 'Kavala', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1444', 'Kefallinia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1445', 'Kerkira', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1446', 'Kiklades', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1447', 'Kilkis', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1448', 'Korinthia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1449', 'Kozani', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1450', 'Lakonia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1451', 'Larisa', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1452', 'Lasithi', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1453', 'Lesvos', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1454', 'Levkas', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1455', 'Magnisia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1456', 'Messinia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1457', 'Nomos Attikis', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1458', 'Nomos Zakynthou', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1459', 'Pella', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1460', 'Pieria', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1461', 'Piraios', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1462', 'Preveza', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1463', 'Rethimni', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1464', 'Rodopi', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1465', 'Samos', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1466', 'Serrai', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1467', 'Thesprotia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1468', 'Thessaloniki', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1469', 'Trikala', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1470', 'Voiotia', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1471', 'West Greece', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1472', 'Xanthi', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1473', 'Zakinthos', '85', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1474', 'Aasiaat', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1475', 'Ammassalik', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1476', 'Illoqqortoormiut', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1477', 'Ilulissat', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1478', 'Ivittuut', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1479', 'Kangaatsiaq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1480', 'Maniitsoq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1481', 'Nanortalik', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1482', 'Narsaq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1483', 'Nuuk', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1484', 'Paamiut', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1485', 'Qaanaaq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1486', 'Qaqortoq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1487', 'Qasigiannguit', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1488', 'Qeqertarsuaq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1489', 'Sisimiut', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1490', 'Udenfor kommunal inddeling', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1491', 'Upernavik', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1492', 'Uummannaq', '86', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1493', 'Carriacou-Petite Martinique', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1494', 'Saint Andrew', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1495', 'Saint Davids', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1496', 'Saint George\'s', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1497', 'Saint John', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1498', 'Saint Mark', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1499', 'Saint Patrick', '87', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1500', 'Basse-Terre', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1501', 'Grande-Terre', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1502', 'Iles des Saintes', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1503', 'La Desirade', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1504', 'Marie-Galante', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1505', 'Saint Barthelemy', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1506', 'Saint Martin', '88', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1507', 'Agana Heights', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1508', 'Agat', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1509', 'Barrigada', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1510', 'Chalan-Pago-Ordot', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1511', 'Dededo', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1512', 'Hagatna', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1513', 'Inarajan', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1514', 'Mangilao', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1515', 'Merizo', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1516', 'Mongmong-Toto-Maite', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1517', 'Santa Rita', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1518', 'Sinajana', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1519', 'Talofofo', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1520', 'Tamuning', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1521', 'Yigo', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1522', 'Yona', '89', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1523', 'Alta Verapaz', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1524', 'Baja Verapaz', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1525', 'Chimaltenango', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1526', 'Chiquimula', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1527', 'El Progreso', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1528', 'Escuintla', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1529', 'Guatemala', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1530', 'Huehuetenango', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1531', 'Izabal', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1532', 'Jalapa', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1533', 'Jutiapa', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1534', 'Peten', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1535', 'Quezaltenango', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1536', 'Quiche', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1537', 'Retalhuleu', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1538', 'Sacatepequez', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1539', 'San Marcos', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1540', 'Santa Rosa', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1541', 'Solola', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1542', 'Suchitepequez', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1543', 'Totonicapan', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1544', 'Zacapa', '90', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1545', 'Alderney', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1546', 'Castel', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1547', 'Forest', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1548', 'Saint Andrew', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1549', 'Saint Martin', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1550', 'Saint Peter Port', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1551', 'Saint Pierre du Bois', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1552', 'Saint Sampson', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1553', 'Saint Saviour', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1554', 'Sark', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1555', 'Torteval', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1556', 'Vale', '91', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1557', 'Beyla', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1558', 'Boffa', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1559', 'Boke', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1560', 'Conakry', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1561', 'Coyah', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1562', 'Dabola', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1563', 'Dalaba', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1564', 'Dinguiraye', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1565', 'Faranah', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1566', 'Forecariah', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1567', 'Fria', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1568', 'Gaoual', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1569', 'Gueckedou', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1570', 'Kankan', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1571', 'Kerouane', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1572', 'Kindia', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1573', 'Kissidougou', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1574', 'Koubia', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1575', 'Koundara', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1576', 'Kouroussa', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1577', 'Labe', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1578', 'Lola', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1579', 'Macenta', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1580', 'Mali', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1581', 'Mamou', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1582', 'Mandiana', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1583', 'Nzerekore', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1584', 'Pita', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1585', 'Siguiri', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1586', 'Telimele', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1587', 'Tougue', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1588', 'Yomou', '92', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1589', 'Bafata', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1590', 'Bissau', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1591', 'Bolama', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1592', 'Cacheu', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1593', 'Gabu', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1594', 'Oio', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1595', 'Quinara', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1596', 'Tombali', '93', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1597', 'Barima-Waini', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1598', 'Cuyuni-Mazaruni', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1599', 'Demerara-Mahaica', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1600', 'East Berbice-Corentyne', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1601', 'Essequibo Islands-West Demerar', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1602', 'Mahaica-Berbice', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1603', 'Pomeroon-Supenaam', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1604', 'Potaro-Siparuni', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1605', 'Upper Demerara-Berbice', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1606', 'Upper Takutu-Upper Essequibo', '94', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1607', 'Artibonite', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1608', 'Centre', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1609', 'Grand\'Anse', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1610', 'Nord', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1611', 'Nord-Est', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1612', 'Nord-Ouest', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1613', 'Ouest', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1614', 'Sud', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1615', 'Sud-Est', '95', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1616', 'Heard and McDonald Islands', '96', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1617', 'Atlantida', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1618', 'Choluteca', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1619', 'Colon', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1620', 'Comayagua', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1621', 'Copan', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1622', 'Cortes', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1623', 'Distrito Central', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1624', 'El Paraiso', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1625', 'Francisco Morazan', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1626', 'Gracias a Dios', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1627', 'Intibuca', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1628', 'Islas de la Bahia', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1629', 'La Paz', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1630', 'Lempira', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1631', 'Ocotepeque', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1632', 'Olancho', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1633', 'Santa Barbara', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1634', 'Valle', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1635', 'Yoro', '97', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1636', 'Hong Kong', '98', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1637', 'Bacs-Kiskun', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1638', 'Baranya', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1639', 'Bekes', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1640', 'Borsod-Abauj-Zemplen', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1641', 'Budapest', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1642', 'Csongrad', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1643', 'Fejer', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1644', 'Gyor-Moson-Sopron', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1645', 'Hajdu-Bihar', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1646', 'Heves', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1647', 'Jasz-Nagykun-Szolnok', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1648', 'Komarom-Esztergom', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1649', 'Nograd', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1650', 'Pest', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1651', 'Somogy', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1652', 'Szabolcs-Szatmar-Bereg', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1653', 'Tolna', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1654', 'Vas', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1655', 'Veszprem', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1656', 'Zala', '99', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1657', 'Austurland', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1658', 'Gullbringusysla', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1659', 'Hofu borgarsva i', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1660', 'Nor urland eystra', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1661', 'Nor urland vestra', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1662', 'Su urland', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1663', 'Su urnes', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1664', 'Vestfir ir', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1665', 'Vesturland', '100', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1666', 'Aceh', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1667', 'Bali', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1668', 'Bangka-Belitung', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1669', 'Banten', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1670', 'Bengkulu', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1671', 'Gandaria', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1672', 'Gorontalo', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1673', 'Jakarta', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1674', 'Jambi', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1675', 'Jawa Barat', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1676', 'Jawa Tengah', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1677', 'Jawa Timur', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1678', 'Kalimantan Barat', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1679', 'Kalimantan Selatan', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1680', 'Kalimantan Tengah', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1681', 'Kalimantan Timur', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1682', 'Kendal', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1683', 'Lampung', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1684', 'Maluku', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1685', 'Maluku Utara', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1686', 'Nusa Tenggara Barat', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1687', 'Nusa Tenggara Timur', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1688', 'Papua', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1689', 'Riau', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1690', 'Riau Kepulauan', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1691', 'Solo', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1692', 'Sulawesi Selatan', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1693', 'Sulawesi Tengah', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1694', 'Sulawesi Tenggara', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1695', 'Sulawesi Utara', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1696', 'Sumatera Barat', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1697', 'Sumatera Selatan', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1698', 'Sumatera Utara', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1699', 'Yogyakarta', '102', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1700', 'Ardabil', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1701', 'Azarbayjan-e Bakhtari', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1702', 'Azarbayjan-e Khavari', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1703', 'Bushehr', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1704', 'Chahar Mahal-e Bakhtiari', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1705', 'Esfahan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1706', 'Fars', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1707', 'Gilan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1708', 'Golestan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1709', 'Hamadan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1710', 'Hormozgan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1711', 'Ilam', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1712', 'Kerman', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1713', 'Kermanshah', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1714', 'Khorasan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1715', 'Khuzestan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1716', 'Kohgiluyeh-e Boyerahmad', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1717', 'Kordestan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1718', 'Lorestan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1719', 'Markazi', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1720', 'Mazandaran', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1721', 'Ostan-e Esfahan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1722', 'Qazvin', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1723', 'Qom', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1724', 'Semnan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1725', 'Sistan-e Baluchestan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1726', 'Tehran', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1727', 'Yazd', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1728', 'Zanjan', '103', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1729', 'Babil', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1730', 'Baghdad', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1731', 'Dahuk', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1732', 'Dhi Qar', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1733', 'Diyala', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1734', 'Erbil', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1735', 'Irbil', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1736', 'Karbala', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1737', 'Kurdistan', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1738', 'Maysan', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1739', 'Ninawa', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1740', 'Salah-ad-Din', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1741', 'Wasit', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1742', 'al-Anbar', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1743', 'al-Basrah', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1744', 'al-Muthanna', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1745', 'al-Qadisiyah', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1746', 'an-Najaf', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1747', 'as-Sulaymaniyah', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1748', 'at-Ta\'mim', '104', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1749', 'Armagh', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1750', 'Carlow', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1751', 'Cavan', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1752', 'Clare', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1753', 'Cork', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1754', 'Donegal', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1755', 'Dublin', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1756', 'Galway', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1757', 'Kerry', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1758', 'Kildare', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1759', 'Kilkenny', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1760', 'Laois', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1761', 'Leinster', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1762', 'Leitrim', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1763', 'Limerick', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1764', 'Loch Garman', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1765', 'Longford', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1766', 'Louth', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1767', 'Mayo', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1768', 'Meath', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1769', 'Monaghan', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1770', 'Offaly', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1771', 'Roscommon', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1772', 'Sligo', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1773', 'Tipperary North Riding', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1774', 'Tipperary South Riding', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1775', 'Ulster', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1776', 'Waterford', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1777', 'Westmeath', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1778', 'Wexford', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1779', 'Wicklow', '105', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1780', 'Beit Hanania', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1781', 'Ben Gurion Airport', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1782', 'Bethlehem', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1783', 'Caesarea', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1784', 'Centre', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1785', 'Gaza', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1786', 'Hadaron', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1787', 'Haifa District', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1788', 'Hamerkaz', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1789', 'Hazafon', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1790', 'Hebron', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1791', 'Jaffa', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1792', 'Jerusalem', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1793', 'Khefa', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1794', 'Kiryat Yam', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1795', 'Lower Galilee', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1796', 'Qalqilya', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1797', 'Talme Elazar', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1798', 'Tel Aviv', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1799', 'Tsafon', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1800', 'Umm El Fahem', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1801', 'Yerushalayim', '106', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1802', 'Abruzzi', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1803', 'Abruzzo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1804', 'Agrigento', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1805', 'Alessandria', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1806', 'Ancona', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1807', 'Arezzo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1808', 'Ascoli Piceno', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1809', 'Asti', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1810', 'Avellino', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1811', 'Bari', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1812', 'Basilicata', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1813', 'Belluno', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1814', 'Benevento', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1815', 'Bergamo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1816', 'Biella', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1817', 'Bologna', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1818', 'Bolzano', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1819', 'Brescia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1820', 'Brindisi', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1821', 'Calabria', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1822', 'Campania', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1823', 'Cartoceto', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1824', 'Caserta', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1825', 'Catania', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1826', 'Chieti', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1827', 'Como', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1828', 'Cosenza', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1829', 'Cremona', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1830', 'Cuneo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1831', 'Emilia-Romagna', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1832', 'Ferrara', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1833', 'Firenze', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1834', 'Florence', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1835', 'Forli-Cesena ', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1836', 'Friuli-Venezia Giulia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1837', 'Frosinone', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1838', 'Genoa', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1839', 'Gorizia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1840', 'L\'Aquila', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1841', 'Lazio', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1842', 'Lecce', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1843', 'Lecco', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1844', 'Lecco Province', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1845', 'Liguria', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1846', 'Lodi', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1847', 'Lombardia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1848', 'Lombardy', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1849', 'Macerata', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1850', 'Mantova', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1851', 'Marche', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1852', 'Messina', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1853', 'Milan', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1854', 'Modena', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1855', 'Molise', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1856', 'Molteno', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1857', 'Montenegro', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1858', 'Monza and Brianza', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1859', 'Naples', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1860', 'Novara', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1861', 'Padova', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1862', 'Parma', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1863', 'Pavia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1864', 'Perugia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1865', 'Pesaro-Urbino', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1866', 'Piacenza', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1867', 'Piedmont', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1868', 'Piemonte', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1869', 'Pisa', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1870', 'Pordenone', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1871', 'Potenza', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1872', 'Puglia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1873', 'Reggio Emilia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1874', 'Rimini', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1875', 'Roma', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1876', 'Salerno', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1877', 'Sardegna', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1878', 'Sassari', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1879', 'Savona', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1880', 'Sicilia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1881', 'Siena', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1882', 'Sondrio', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1883', 'South Tyrol', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1884', 'Taranto', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1885', 'Teramo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1886', 'Torino', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1887', 'Toscana', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1888', 'Trapani', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1889', 'Trentino-Alto Adige', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1890', 'Trento', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1891', 'Treviso', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1892', 'Udine', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1893', 'Umbria', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1894', 'Valle d\'Aosta', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1895', 'Varese', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1896', 'Veneto', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1897', 'Venezia', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1898', 'Verbano-Cusio-Ossola', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1899', 'Vercelli', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1900', 'Verona', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1901', 'Vicenza', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1902', 'Viterbo', '107', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1903', 'Buxoro Viloyati', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1904', 'Clarendon', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1905', 'Hanover', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1906', 'Kingston', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1907', 'Manchester', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1908', 'Portland', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1909', 'Saint Andrews', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1910', 'Saint Ann', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1911', 'Saint Catherine', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1912', 'Saint Elizabeth', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1913', 'Saint James', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1914', 'Saint Mary', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1915', 'Saint Thomas', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1916', 'Trelawney', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1917', 'Westmoreland', '108', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1918', 'Aichi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1919', 'Akita', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1920', 'Aomori', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1921', 'Chiba', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1922', 'Ehime', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1923', 'Fukui', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1924', 'Fukuoka', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1925', 'Fukushima', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1926', 'Gifu', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1927', 'Gumma', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1928', 'Hiroshima', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1929', 'Hokkaido', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1930', 'Hyogo', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1931', 'Ibaraki', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1932', 'Ishikawa', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1933', 'Iwate', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1934', 'Kagawa', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1935', 'Kagoshima', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1936', 'Kanagawa', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1937', 'Kanto', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1938', 'Kochi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1939', 'Kumamoto', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1940', 'Kyoto', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1941', 'Mie', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1942', 'Miyagi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1943', 'Miyazaki', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1944', 'Nagano', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1945', 'Nagasaki', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1946', 'Nara', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1947', 'Niigata', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1948', 'Oita', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1949', 'Okayama', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1950', 'Okinawa', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1951', 'Osaka', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1952', 'Saga', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1953', 'Saitama', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1954', 'Shiga', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1955', 'Shimane', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1956', 'Shizuoka', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1957', 'Tochigi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1958', 'Tokushima', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1959', 'Tokyo', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1960', 'Tottori', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1961', 'Toyama', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1962', 'Wakayama', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1963', 'Yamagata', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1964', 'Yamaguchi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1965', 'Yamanashi', '109', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1966', 'Grouville', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1967', 'Saint Brelade', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1968', 'Saint Clement', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1969', 'Saint Helier', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1970', 'Saint John', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1971', 'Saint Lawrence', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1972', 'Saint Martin', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1973', 'Saint Mary', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1974', 'Saint Peter', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1975', 'Saint Saviour', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1976', 'Trinity', '110', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1977', '\'Ajlun', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1978', 'Amman', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1979', 'Irbid', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1980', 'Jarash', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1981', 'Ma\'an', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1982', 'Madaba', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1983', 'al-\'Aqabah', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1984', 'al-Balqa\'', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1985', 'al-Karak', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1986', 'al-Mafraq', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1987', 'at-Tafilah', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1988', 'az-Zarqa\'', '111', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1989', 'Akmecet', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1990', 'Akmola', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1991', 'Aktobe', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1992', 'Almati', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1993', 'Atirau', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1994', 'Batis Kazakstan', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1995', 'Burlinsky Region', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1996', 'Karagandi', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1997', 'Kostanay', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1998', 'Mankistau', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('1999', 'Ontustik Kazakstan', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2000', 'Pavlodar', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2001', 'Sigis Kazakstan', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2002', 'Soltustik Kazakstan', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2003', 'Taraz', '112', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2004', 'Central', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2005', 'Coast', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2006', 'Eastern', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2007', 'Nairobi', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2008', 'North Eastern', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2009', 'Nyanza', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2010', 'Rift Valley', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2011', 'Western', '113', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2012', 'Abaiang', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2013', 'Abemana', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2014', 'Aranuka', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2015', 'Arorae', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2016', 'Banaba', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2017', 'Beru', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2018', 'Butaritari', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2019', 'Kiritimati', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2020', 'Kuria', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2021', 'Maiana', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2022', 'Makin', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2023', 'Marakei', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2024', 'Nikunau', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2025', 'Nonouti', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2026', 'Onotoa', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2027', 'Phoenix Islands', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2028', 'Tabiteuea North', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2029', 'Tabiteuea South', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2030', 'Tabuaeran', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2031', 'Tamana', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2032', 'Tarawa North', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2033', 'Tarawa South', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2034', 'Teraina', '114', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2035', 'Chagangdo', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2036', 'Hamgyeongbukto', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2037', 'Hamgyeongnamdo', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2038', 'Hwanghaebukto', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2039', 'Hwanghaenamdo', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2040', 'Kaeseong', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2041', 'Kangweon', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2042', 'Nampo', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2043', 'Pyeonganbukto', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2044', 'Pyeongannamdo', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2045', 'Pyeongyang', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2046', 'Yanggang', '115', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2047', 'Busan', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2048', 'Cheju', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2049', 'Chollabuk', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2050', 'Chollanam', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2051', 'Chungbuk', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2052', 'Chungcheongbuk', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2053', 'Chungcheongnam', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2054', 'Chungnam', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2055', 'Daegu', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2056', 'Gangwon-do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2057', 'Goyang-si', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2058', 'Gyeonggi-do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2059', 'Gyeongsang ', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2060', 'Gyeongsangnam-do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2061', 'Incheon', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2062', 'Jeju-Si', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2063', 'Jeonbuk', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2064', 'Kangweon', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2065', 'Kwangju', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2066', 'Kyeonggi', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2067', 'Kyeongsangbuk', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2068', 'Kyeongsangnam', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2069', 'Kyonggi-do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2070', 'Kyungbuk-Do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2071', 'Kyunggi-Do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2072', 'Kyunggi-do', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2073', 'Pusan', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2074', 'Seoul', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2075', 'Sudogwon', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2076', 'Taegu', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2077', 'Taejeon', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2078', 'Taejon-gwangyoksi', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2079', 'Ulsan', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2080', 'Wonju', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2081', 'gwangyoksi', '116', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2082', 'Al Asimah', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2083', 'Hawalli', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2084', 'Mishref', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2085', 'Qadesiya', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2086', 'Safat', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2087', 'Salmiya', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2088', 'al-Ahmadi', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2089', 'al-Farwaniyah', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2090', 'al-Jahra', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2091', 'al-Kuwayt', '117', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2092', 'Batken', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2093', 'Bishkek', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2094', 'Chui', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2095', 'Issyk-Kul', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2096', 'Jalal-Abad', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2097', 'Naryn', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2098', 'Osh', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2099', 'Talas', '118', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2100', 'Attopu', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2101', 'Bokeo', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2102', 'Bolikhamsay', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2103', 'Champasak', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2104', 'Houaphanh', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2105', 'Khammouane', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2106', 'Luang Nam Tha', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2107', 'Luang Prabang', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2108', 'Oudomxay', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2109', 'Phongsaly', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2110', 'Saravan', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2111', 'Savannakhet', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2112', 'Sekong', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2113', 'Viangchan Prefecture', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2114', 'Viangchan Province', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2115', 'Xaignabury', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2116', 'Xiang Khuang', '119', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2117', 'Aizkraukles', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2118', 'Aluksnes', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2119', 'Balvu', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2120', 'Bauskas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2121', 'Cesu', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2122', 'Daugavpils', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2123', 'Daugavpils City', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2124', 'Dobeles', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2125', 'Gulbenes', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2126', 'Jekabspils', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2127', 'Jelgava', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2128', 'Jelgavas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2129', 'Jurmala City', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2130', 'Kraslavas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2131', 'Kuldigas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2132', 'Liepaja', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2133', 'Liepajas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2134', 'Limbazhu', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2135', 'Ludzas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2136', 'Madonas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2137', 'Ogres', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2138', 'Preilu', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2139', 'Rezekne', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2140', 'Rezeknes', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2141', 'Riga', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2142', 'Rigas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2143', 'Saldus', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2144', 'Talsu', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2145', 'Tukuma', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2146', 'Valkas', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2147', 'Valmieras', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2148', 'Ventspils', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2149', 'Ventspils City', '120', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2150', 'Beirut', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2151', 'Jabal Lubnan', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2152', 'Mohafazat Liban-Nord', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2153', 'Mohafazat Mont-Liban', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2154', 'Sidon', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2155', 'al-Biqa', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2156', 'al-Janub', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2157', 'an-Nabatiyah', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2158', 'ash-Shamal', '121', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2159', 'Berea', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2160', 'Butha-Buthe', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2161', 'Leribe', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2162', 'Mafeteng', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2163', 'Maseru', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2164', 'Mohale\'s Hoek', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2165', 'Mokhotlong', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2166', 'Qacha\'s Nek', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2167', 'Quthing', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2168', 'Thaba-Tseka', '122', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2169', 'Bomi', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2170', 'Bong', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2171', 'Grand Bassa', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2172', 'Grand Cape Mount', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2173', 'Grand Gedeh', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2174', 'Loffa', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2175', 'Margibi', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2176', 'Maryland and Grand Kru', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2177', 'Montserrado', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2178', 'Nimba', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2179', 'Rivercess', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2180', 'Sinoe', '123', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2181', 'Ajdabiya', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2183', 'Banghazi', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2184', 'Darnah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2185', 'Ghadamis', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2186', 'Gharyan', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2187', 'Misratah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2188', 'Murzuq', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2189', 'Sabha', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2190', 'Sawfajjin', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2191', 'Surt', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2192', 'Tarabulus', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2193', 'Tarhunah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2194', 'Tripolitania', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2195', 'Tubruq', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2196', 'Yafran', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2197', 'Zlitan', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2198', 'al-\'Aziziyah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2199', 'al-Fatih', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2200', 'al-Jabal al Akhdar', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2201', 'al-Jufrah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2202', 'al-Khums', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2203', 'al-Kufrah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2204', 'an-Nuqat al-Khams', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2205', 'ash-Shati\'', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2206', 'az-Zawiyah', '124', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2207', 'Balzers', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2208', 'Eschen', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2209', 'Gamprin', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2210', 'Mauren', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2211', 'Planken', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2212', 'Ruggell', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2213', 'Schaan', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2214', 'Schellenberg', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2215', 'Triesen', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2216', 'Triesenberg', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2217', 'Vaduz', '125', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2218', 'Alytaus', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2219', 'Anyksciai', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2220', 'Kauno', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2221', 'Klaipedos', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2222', 'Marijampoles', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2223', 'Panevezhio', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2224', 'Panevezys', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2225', 'Shiauliu', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2226', 'Taurages', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2227', 'Telshiu', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2228', 'Telsiai', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2229', 'Utenos', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2230', 'Vilniaus', '126', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2231', 'Capellen', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2232', 'Clervaux', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2233', 'Diekirch', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2234', 'Echternach', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2235', 'Esch-sur-Alzette', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2236', 'Grevenmacher', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2237', 'Luxembourg', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2238', 'Mersch', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2239', 'Redange', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2240', 'Remich', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2241', 'Vianden', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2242', 'Wiltz', '127', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2243', 'Macau', '128', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2244', 'Berovo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2245', 'Bitola', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2246', 'Brod', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2247', 'Debar', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2248', 'Delchevo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2249', 'Demir Hisar', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2250', 'Gevgelija', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2251', 'Gostivar', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2252', 'Kavadarci', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2253', 'Kichevo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2254', 'Kochani', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2255', 'Kratovo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2256', 'Kriva Palanka', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2257', 'Krushevo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2258', 'Kumanovo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2259', 'Negotino', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2260', 'Ohrid', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2261', 'Prilep', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2262', 'Probishtip', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2263', 'Radovish', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2264', 'Resen', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2265', 'Shtip', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2266', 'Skopje', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2267', 'Struga', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2268', 'Strumica', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2269', 'Sveti Nikole', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2270', 'Tetovo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2271', 'Valandovo', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2272', 'Veles', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2273', 'Vinica', '129', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2274', 'Antananarivo', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2275', 'Antsiranana', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2276', 'Fianarantsoa', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2277', 'Mahajanga', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2278', 'Toamasina', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2279', 'Toliary', '130', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2280', 'Balaka', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2281', 'Blantyre City', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2282', 'Chikwawa', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2283', 'Chiradzulu', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2284', 'Chitipa', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2285', 'Dedza', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2286', 'Dowa', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2287', 'Karonga', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2288', 'Kasungu', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2289', 'Lilongwe City', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2290', 'Machinga', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2291', 'Mangochi', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2292', 'Mchinji', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2293', 'Mulanje', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2294', 'Mwanza', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2295', 'Mzimba', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2296', 'Mzuzu City', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2297', 'Nkhata Bay', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2298', 'Nkhotakota', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2299', 'Nsanje', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2300', 'Ntcheu', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2301', 'Ntchisi', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2302', 'Phalombe', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2303', 'Rumphi', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2304', 'Salima', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2305', 'Thyolo', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2306', 'Zomba Municipality', '131', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2307', 'Johor', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2308', 'Kedah', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2309', 'Kelantan', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2310', 'Kuala Lumpur', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2311', 'Labuan', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2312', 'Melaka', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2313', 'Negeri Johor', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2314', 'Negeri Sembilan', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2315', 'Pahang', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2316', 'Penang', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2317', 'Perak', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2318', 'Perlis', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2319', 'Pulau Pinang', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2320', 'Sabah', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2321', 'Sarawak', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2322', 'Selangor', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2323', 'Sembilan', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2324', 'Terengganu', '132', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2325', 'Alif Alif', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2326', 'Alif Dhaal', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2327', 'Baa', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2328', 'Dhaal', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2329', 'Faaf', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2330', 'Gaaf Alif', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2331', 'Gaaf Dhaal', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2332', 'Ghaviyani', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2333', 'Haa Alif', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2334', 'Haa Dhaal', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2335', 'Kaaf', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2336', 'Laam', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2337', 'Lhaviyani', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2338', 'Male', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2339', 'Miim', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2340', 'Nuun', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2341', 'Raa', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2342', 'Shaviyani', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2343', 'Siin', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2344', 'Thaa', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2345', 'Vaav', '133', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2346', 'Bamako', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2347', 'Gao', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2348', 'Kayes', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2349', 'Kidal', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2350', 'Koulikoro', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2351', 'Mopti', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2352', 'Segou', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2353', 'Sikasso', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2354', 'Tombouctou', '134', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2355', 'Gozo and Comino', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2356', 'Inner Harbour', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2357', 'Northern', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2358', 'Outer Harbour', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2359', 'South Eastern', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2360', 'Valletta', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2361', 'Western', '135', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2362', 'Castletown', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2363', 'Douglas', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2364', 'Laxey', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2365', 'Onchan', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2366', 'Peel', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2367', 'Port Erin', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2368', 'Port Saint Mary', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2369', 'Ramsey', '136', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2370', 'Ailinlaplap', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2371', 'Ailuk', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2372', 'Arno', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2373', 'Aur', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2374', 'Bikini', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2375', 'Ebon', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2376', 'Enewetak', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2377', 'Jabat', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2378', 'Jaluit', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2379', 'Kili', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2380', 'Kwajalein', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2381', 'Lae', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2382', 'Lib', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2383', 'Likiep', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2384', 'Majuro', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2385', 'Maloelap', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2386', 'Mejit', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2387', 'Mili', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2388', 'Namorik', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2389', 'Namu', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2390', 'Rongelap', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2391', 'Ujae', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2392', 'Utrik', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2393', 'Wotho', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2394', 'Wotje', '137', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2395', 'Fort-de-France', '138', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2396', 'La Trinite', '138', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2397', 'Le Marin', '138', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2398', 'Saint-Pierre', '138', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2399', 'Adrar', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2400', 'Assaba', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2401', 'Brakna', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2402', 'Dhakhlat Nawadibu', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2403', 'Hudh-al-Gharbi', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2404', 'Hudh-ash-Sharqi', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2405', 'Inshiri', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2406', 'Nawakshut', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2407', 'Qidimagha', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2408', 'Qurqul', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2409', 'Taqant', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2410', 'Tiris Zammur', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2411', 'Trarza', '139', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2412', 'Black River', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2413', 'Eau Coulee', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2414', 'Flacq', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2415', 'Floreal', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2416', 'Grand Port', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2417', 'Moka', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2418', 'Pamplempousses', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2419', 'Plaines Wilhelm', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2420', 'Port Louis', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2421', 'Riviere du Rempart', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2422', 'Rodrigues', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2423', 'Rose Hill', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2424', 'Savanne', '140', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2425', 'Mayotte', '141', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2426', 'Pamanzi', '141', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2427', 'Aguascalientes', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2428', 'Baja California', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2429', 'Baja California Sur', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2430', 'Campeche', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2431', 'Chiapas', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2432', 'Chihuahua', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2433', 'Coahuila', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2434', 'Colima', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2435', 'Distrito Federal', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2436', 'Durango', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2437', 'Estado de Mexico', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2438', 'Guanajuato', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2439', 'Guerrero', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2440', 'Hidalgo', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2441', 'Jalisco', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2442', 'Mexico', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2443', 'Michoacan', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2444', 'Morelos', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2445', 'Nayarit', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2446', 'Nuevo Leon', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2447', 'Oaxaca', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2448', 'Puebla', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2449', 'Queretaro', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2450', 'Quintana Roo', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2451', 'San Luis Potosi', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2452', 'Sinaloa', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2453', 'Sonora', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2454', 'Tabasco', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2455', 'Tamaulipas', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2456', 'Tlaxcala', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2457', 'Veracruz', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2458', 'Yucatan', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2459', 'Zacatecas', '142', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2460', 'Chuuk', '143', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2461', 'Kusaie', '143', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2462', 'Pohnpei', '143', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2463', 'Yap', '143', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2464', 'Balti', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2465', 'Cahul', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2466', 'Chisinau', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2467', 'Chisinau Oras', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2468', 'Edinet', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2469', 'Gagauzia', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2470', 'Lapusna', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2471', 'Orhei', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2472', 'Soroca', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2473', 'Taraclia', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2474', 'Tighina', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2475', 'Transnistria', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2476', 'Ungheni', '144', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2477', 'Fontvieille', '145', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2478', 'La Condamine', '145', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2479', 'Monaco-Ville', '145', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2480', 'Monte Carlo', '145', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2481', 'Arhangaj', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2482', 'Bajan-Olgij', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2483', 'Bajanhongor', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2484', 'Bulgan', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2485', 'Darhan-Uul', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2486', 'Dornod', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2487', 'Dornogovi', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2488', 'Dundgovi', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2489', 'Govi-Altaj', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2490', 'Govisumber', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2491', 'Hentij', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2492', 'Hovd', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2493', 'Hovsgol', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2494', 'Omnogovi', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2495', 'Orhon', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2496', 'Ovorhangaj', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2497', 'Selenge', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2498', 'Suhbaatar', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2499', 'Tov', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2500', 'Ulaanbaatar', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2501', 'Uvs', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2502', 'Zavhan', '146', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2503', 'Montserrat', '147', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2504', 'Agadir', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2505', 'Casablanca', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2506', 'Chaouia-Ouardigha', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2507', 'Doukkala-Abda', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2508', 'Fes-Boulemane', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2509', 'Gharb-Chrarda-Beni Hssen', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2510', 'Guelmim', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2511', 'Kenitra', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2512', 'Marrakech-Tensift-Al Haouz', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2513', 'Meknes-Tafilalet', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2514', 'Oriental', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2515', 'Oujda', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2516', 'Province de Tanger', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2517', 'Rabat-Sale-Zammour-Zaer', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2518', 'Sala Al Jadida', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2519', 'Settat', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2520', 'Souss Massa-Draa', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2521', 'Tadla-Azilal', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2522', 'Tangier-Tetouan', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2523', 'Taza-Al Hoceima-Taounate', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2524', 'Wilaya de Casablanca', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2525', 'Wilaya de Rabat-Sale', '148', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2526', 'Cabo Delgado', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2527', 'Gaza', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2528', 'Inhambane', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2529', 'Manica', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2530', 'Maputo', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2531', 'Maputo Provincia', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2532', 'Nampula', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2533', 'Niassa', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2534', 'Sofala', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2535', 'Tete', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2536', 'Zambezia', '149', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2537', 'Ayeyarwady', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2538', 'Bago', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2539', 'Chin', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2540', 'Kachin', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2541', 'Kayah', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2542', 'Kayin', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2543', 'Magway', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2544', 'Mandalay', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2545', 'Mon', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2546', 'Nay Pyi Taw', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2547', 'Rakhine', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2548', 'Sagaing', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2549', 'Shan', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2550', 'Tanintharyi', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2551', 'Yangon', '150', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2552', 'Caprivi', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2553', 'Erongo', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2554', 'Hardap', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2555', 'Karas', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2556', 'Kavango', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2557', 'Khomas', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2558', 'Kunene', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2559', 'Ohangwena', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2560', 'Omaheke', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2561', 'Omusati', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2562', 'Oshana', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2563', 'Oshikoto', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2564', 'Otjozondjupa', '151', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2565', 'Yaren', '152', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2566', 'Bagmati', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2567', 'Bheri', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2568', 'Dhawalagiri', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2569', 'Gandaki', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2570', 'Janakpur', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2571', 'Karnali', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2572', 'Koshi', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2573', 'Lumbini', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2574', 'Mahakali', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2575', 'Mechi', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2576', 'Narayani', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2577', 'Rapti', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2578', 'Sagarmatha', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2579', 'Seti', '153', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2580', 'Bonaire', '154', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2581', 'Curacao', '154', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2582', 'Saba', '154', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2583', 'Sint Eustatius', '154', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2584', 'Sint Maarten', '154', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2585', 'Amsterdam', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2586', 'Benelux', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2587', 'Drenthe', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2588', 'Flevoland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2589', 'Friesland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2590', 'Gelderland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2591', 'Groningen', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2592', 'Limburg', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2593', 'Noord-Brabant', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2594', 'Noord-Holland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2595', 'Overijssel', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2596', 'South Holland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2597', 'Utrecht', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2598', 'Zeeland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2599', 'Zuid-Holland', '155', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2600', 'Iles', '156', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2601', 'Nord', '156', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2602', 'Sud', '156', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2603', 'Area Outside Region', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2604', 'Auckland', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2605', 'Bay of Plenty', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2606', 'Canterbury', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2607', 'Christchurch', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2608', 'Gisborne', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2609', 'Hawke\'s Bay', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2610', 'Manawatu-Wanganui', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2611', 'Marlborough', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2612', 'Nelson', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2613', 'Northland', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2614', 'Otago', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2615', 'Rodney', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2616', 'Southland', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2617', 'Taranaki', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2618', 'Tasman', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2619', 'Waikato', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2620', 'Wellington', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2621', 'West Coast', '157', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2622', 'Atlantico Norte', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2623', 'Atlantico Sur', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2624', 'Boaco', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2625', 'Carazo', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2626', 'Chinandega', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2627', 'Chontales', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2628', 'Esteli', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2629', 'Granada', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2630', 'Jinotega', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2631', 'Leon', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2632', 'Madriz', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2633', 'Managua', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2634', 'Masaya', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2635', 'Matagalpa', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2636', 'Nueva Segovia', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2637', 'Rio San Juan', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2638', 'Rivas', '158', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2639', 'Agadez', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2640', 'Diffa', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2641', 'Dosso', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2642', 'Maradi', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2643', 'Niamey', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2644', 'Tahoua', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2645', 'Tillabery', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2646', 'Zinder', '159', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2647', 'Abia', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2648', 'Abuja Federal Capital Territor', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2649', 'Adamawa', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2650', 'Akwa Ibom', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2651', 'Anambra', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2652', 'Bauchi', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2653', 'Bayelsa', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2654', 'Benue', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2655', 'Borno', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2656', 'Cross River', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2657', 'Delta', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2658', 'Ebonyi', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2659', 'Edo', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2660', 'Ekiti', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2661', 'Enugu', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2662', 'Gombe', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2663', 'Imo', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2664', 'Jigawa', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2665', 'Kaduna', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2666', 'Kano', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2667', 'Katsina', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2668', 'Kebbi', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2669', 'Kogi', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2670', 'Kwara', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2671', 'Lagos', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2672', 'Nassarawa', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2673', 'Niger', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2674', 'Ogun', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2675', 'Ondo', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2676', 'Osun', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2677', 'Oyo', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2678', 'Plateau', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2679', 'Rivers', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2680', 'Sokoto', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2681', 'Taraba', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2682', 'Yobe', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2683', 'Zamfara', '160', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2684', 'Niue', '161', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2685', 'Norfolk Island', '162', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2686', 'Northern Islands', '163', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2687', 'Rota', '163', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2688', 'Saipan', '163', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2689', 'Tinian', '163', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2690', 'Akershus', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2691', 'Aust Agder', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2692', 'Bergen', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2693', 'Buskerud', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2694', 'Finnmark', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2695', 'Hedmark', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2696', 'Hordaland', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2697', 'Moere og Romsdal', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2698', 'Nord Trondelag', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2699', 'Nordland', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2700', 'Oestfold', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2701', 'Oppland', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2702', 'Oslo', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2703', 'Rogaland', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2704', 'Soer Troendelag', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2705', 'Sogn og Fjordane', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2706', 'Stavern', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2707', 'Sykkylven', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2708', 'Telemark', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2709', 'Troms', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2710', 'Vest Agder', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2711', 'Vestfold', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2712', 'ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚', '164', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2713', 'Al Buraimi', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2714', 'Dhufar', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2715', 'Masqat', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2716', 'Musandam', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2717', 'Rusayl', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2718', 'Wadi Kabir', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2719', 'ad-Dakhiliyah', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2720', 'adh-Dhahirah', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2721', 'al-Batinah', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2722', 'ash-Sharqiyah', '165', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2723', 'Baluchistan', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2724', 'Federal Capital Area', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2725', 'Federally administered Tribal ', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2726', 'North-West Frontier', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2727', 'Northern Areas', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2728', 'Punjab', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2729', 'Sind', '166', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2730', 'Aimeliik', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2731', 'Airai', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2732', 'Angaur', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2733', 'Hatobohei', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2734', 'Kayangel', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2735', 'Koror', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2736', 'Melekeok', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2737', 'Ngaraard', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2738', 'Ngardmau', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2739', 'Ngaremlengui', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2740', 'Ngatpang', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2741', 'Ngchesar', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2742', 'Ngerchelong', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2743', 'Ngiwal', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2744', 'Peleliu', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2745', 'Sonsorol', '167', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2746', 'Ariha', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2747', 'Bayt Lahm', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2748', 'Bethlehem', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2749', 'Dayr-al-Balah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2750', 'Ghazzah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2751', 'Ghazzah ash-Shamaliyah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2752', 'Janin', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2753', 'Khan Yunis', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2754', 'Nabulus', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2755', 'Qalqilyah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2756', 'Rafah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2757', 'Ram Allah wal-Birah', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2758', 'Salfit', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2759', 'Tubas', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2760', 'Tulkarm', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2761', 'al-Khalil', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2762', 'al-Quds', '168', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2763', 'Bocas del Toro', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2764', 'Chiriqui', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2765', 'Cocle', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2766', 'Colon', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2767', 'Darien', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2768', 'Embera', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2769', 'Herrera', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2770', 'Kuna Yala', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2771', 'Los Santos', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2772', 'Ngobe Bugle', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2773', 'Panama', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2774', 'Veraguas', '169', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2775', 'East New Britain', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2776', 'East Sepik', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2777', 'Eastern Highlands', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2778', 'Enga', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2779', 'Fly River', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2780', 'Gulf', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2781', 'Madang', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2782', 'Manus', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2783', 'Milne Bay', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2784', 'Morobe', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2785', 'National Capital District', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2786', 'New Ireland', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2787', 'North Solomons', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2788', 'Oro', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2789', 'Sandaun', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2790', 'Simbu', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2791', 'Southern Highlands', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2792', 'West New Britain', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2793', 'Western Highlands', '170', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2794', 'Alto Paraguay', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2795', 'Alto Parana', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2796', 'Amambay', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2797', 'Asuncion', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2798', 'Boqueron', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2799', 'Caaguazu', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2800', 'Caazapa', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2801', 'Canendiyu', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2802', 'Central', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2803', 'Concepcion', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2804', 'Cordillera', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2805', 'Guaira', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2806', 'Itapua', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2807', 'Misiones', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2808', 'Neembucu', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2809', 'Paraguari', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2810', 'Presidente Hayes', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2811', 'San Pedro', '171', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2812', 'Amazonas', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2813', 'Ancash', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2814', 'Apurimac', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2815', 'Arequipa', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2816', 'Ayacucho', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2817', 'Cajamarca', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2818', 'Cusco', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2819', 'Huancavelica', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2820', 'Huanuco', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2821', 'Ica', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2822', 'Junin', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2823', 'La Libertad', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2824', 'Lambayeque', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2825', 'Lima y Callao', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2826', 'Loreto', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2827', 'Madre de Dios', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2828', 'Moquegua', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2829', 'Pasco', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2830', 'Piura', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2831', 'Puno', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2832', 'San Martin', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2833', 'Tacna', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2834', 'Tumbes', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2835', 'Ucayali', '172', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2836', 'Batangas', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2837', 'Bicol', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2838', 'Bulacan', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2839', 'Cagayan', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2840', 'Caraga', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2841', 'Central Luzon', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2842', 'Central Mindanao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2843', 'Central Visayas', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2844', 'Cordillera', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2845', 'Davao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2846', 'Eastern Visayas', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2847', 'Greater Metropolitan Area', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2848', 'Ilocos', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2849', 'Laguna', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2850', 'Luzon', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2851', 'Mactan', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2852', 'Metropolitan Manila Area', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2853', 'Muslim Mindanao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2854', 'Northern Mindanao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2855', 'Southern Mindanao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2856', 'Southern Tagalog', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2857', 'Western Mindanao', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2858', 'Western Visayas', '173', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2859', 'Pitcairn Island', '174', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2860', 'Biale Blota', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2861', 'Dobroszyce', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2862', 'Dolnoslaskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2863', 'Dziekanow Lesny', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2864', 'Hopowo', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2865', 'Kartuzy', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2866', 'Koscian', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2867', 'Krakow', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2868', 'Kujawsko-Pomorskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2869', 'Lodzkie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2870', 'Lubelskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2871', 'Lubuskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2872', 'Malomice', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2873', 'Malopolskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2874', 'Mazowieckie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2875', 'Mirkow', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2876', 'Opolskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2877', 'Ostrowiec', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2878', 'Podkarpackie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2879', 'Podlaskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2880', 'Polska', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2881', 'Pomorskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2882', 'Poznan', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2883', 'Pruszkow', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2884', 'Rymanowska', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2885', 'Rzeszow', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2886', 'Slaskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2887', 'Stare Pole', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2888', 'Swietokrzyskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2889', 'Warminsko-Mazurskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2890', 'Warsaw', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2891', 'Wejherowo', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2892', 'Wielkopolskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2893', 'Wroclaw', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2894', 'Zachodnio-Pomorskie', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2895', 'Zukowo', '175', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2896', 'Abrantes', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2897', 'Acores', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2898', 'Alentejo', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2899', 'Algarve', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2900', 'Braga', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2901', 'Centro', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2902', 'Distrito de Leiria', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2903', 'Distrito de Viana do Castelo', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2904', 'Distrito de Vila Real', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2905', 'Distrito do Porto', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2906', 'Lisboa e Vale do Tejo', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2907', 'Madeira', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2908', 'Norte', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2909', 'Paivas', '176', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2910', 'Arecibo', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2911', 'Bayamon', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2912', 'Carolina', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2913', 'Florida', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2914', 'Guayama', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2915', 'Humacao', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2916', 'Mayaguez-Aguadilla', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2917', 'Ponce', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2918', 'Salinas', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2919', 'San Juan', '177', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2920', 'Doha', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2921', 'Jarian-al-Batnah', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2922', 'Umm Salal', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2923', 'ad-Dawhah', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2924', 'al-Ghuwayriyah', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2925', 'al-Jumayliyah', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2926', 'al-Khawr', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2927', 'al-Wakrah', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2928', 'ar-Rayyan', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2929', 'ash-Shamal', '178', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2930', 'Saint-Benoit', '179', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2931', 'Saint-Denis', '179', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2932', 'Saint-Paul', '179', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2933', 'Saint-Pierre', '179', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2934', 'Alba', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2935', 'Arad', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2936', 'Arges', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2937', 'Bacau', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2938', 'Bihor', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2939', 'Bistrita-Nasaud', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2940', 'Botosani', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2941', 'Braila', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2942', 'Brasov', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2943', 'Bucuresti', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2944', 'Buzau', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2945', 'Calarasi', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2946', 'Caras-Severin', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2947', 'Cluj', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2948', 'Constanta', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2949', 'Covasna', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2950', 'Dambovita', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2951', 'Dolj', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2952', 'Galati', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2953', 'Giurgiu', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2954', 'Gorj', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2955', 'Harghita', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2956', 'Hunedoara', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2957', 'Ialomita', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2958', 'Iasi', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2959', 'Ilfov', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2960', 'Maramures', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2961', 'Mehedinti', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2962', 'Mures', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2963', 'Neamt', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2964', 'Olt', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2965', 'Prahova', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2966', 'Salaj', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2967', 'Satu Mare', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2968', 'Sibiu', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2969', 'Sondelor', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2970', 'Suceava', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2971', 'Teleorman', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2972', 'Timis', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2973', 'Tulcea', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2974', 'Valcea', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2975', 'Vaslui', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2976', 'Vrancea', '180', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2977', 'Adygeja', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2978', 'Aga', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2979', 'Alanija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2980', 'Altaj', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2981', 'Amur', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2982', 'Arhangelsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2983', 'Astrahan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2984', 'Bashkortostan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2985', 'Belgorod', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2986', 'Brjansk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2987', 'Burjatija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2988', 'Chechenija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2989', 'Cheljabinsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2990', 'Chita', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2991', 'Chukotka', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2992', 'Chuvashija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2993', 'Dagestan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2994', 'Evenkija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2995', 'Gorno-Altaj', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2996', 'Habarovsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2997', 'Hakasija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2998', 'Hanty-Mansija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('2999', 'Ingusetija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3000', 'Irkutsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3001', 'Ivanovo', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3002', 'Jamalo-Nenets', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3003', 'Jaroslavl', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3004', 'Jevrej', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3005', 'Kabardino-Balkarija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3006', 'Kaliningrad', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3007', 'Kalmykija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3008', 'Kaluga', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3009', 'Kamchatka', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3010', 'Karachaj-Cherkessija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3011', 'Karelija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3012', 'Kemerovo', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3013', 'Khabarovskiy Kray', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3014', 'Kirov', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3015', 'Komi', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3016', 'Komi-Permjakija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3017', 'Korjakija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3018', 'Kostroma', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3019', 'Krasnodar', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3020', 'Krasnojarsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3021', 'Krasnoyarskiy Kray', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3022', 'Kurgan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3023', 'Kursk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3024', 'Leningrad', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3025', 'Lipeck', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3026', 'Magadan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3027', 'Marij El', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3028', 'Mordovija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3029', 'Moscow', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3030', 'Moskovskaja Oblast', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3031', 'Moskovskaya Oblast', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3032', 'Moskva', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3033', 'Murmansk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3034', 'Nenets', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3035', 'Nizhnij Novgorod', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3036', 'Novgorod', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3037', 'Novokusnezk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3038', 'Novosibirsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3039', 'Omsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3040', 'Orenburg', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3041', 'Orjol', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3042', 'Penza', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3043', 'Perm', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3044', 'Primorje', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3045', 'Pskov', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3046', 'Pskovskaya Oblast', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3047', 'Rjazan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3048', 'Rostov', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3049', 'Saha', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3050', 'Sahalin', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3051', 'Samara', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3052', 'Samarskaya', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3053', 'Sankt-Peterburg', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3054', 'Saratov', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3055', 'Smolensk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3056', 'Stavropol', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3057', 'Sverdlovsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3058', 'Tajmyrija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3059', 'Tambov', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3060', 'Tatarstan', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3061', 'Tjumen', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3062', 'Tomsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3063', 'Tula', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3064', 'Tver', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3065', 'Tyva', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3066', 'Udmurtija', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3067', 'Uljanovsk', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3068', 'Ulyanovskaya Oblast', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3069', 'Ust-Orda', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3070', 'Vladimir', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3071', 'Volgograd', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3072', 'Vologda', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3073', 'Voronezh', '181', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3074', 'Butare', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3075', 'Byumba', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3076', 'Cyangugu', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3077', 'Gikongoro', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3078', 'Gisenyi', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3079', 'Gitarama', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3080', 'Kibungo', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3081', 'Kibuye', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3082', 'Kigali-ngali', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3083', 'Ruhengeri', '182', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3084', 'Ascension', '183', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3085', 'Gough Island', '183', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3086', 'Saint Helena', '183', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3087', 'Tristan da Cunha', '183', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3088', 'Christ Church Nichola Town', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3089', 'Saint Anne Sandy Point', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3090', 'Saint George Basseterre', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3091', 'Saint George Gingerland', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3092', 'Saint James Windward', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3093', 'Saint John Capesterre', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3094', 'Saint John Figtree', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3095', 'Saint Mary Cayon', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3096', 'Saint Paul Capesterre', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3097', 'Saint Paul Charlestown', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3098', 'Saint Peter Basseterre', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3099', 'Saint Thomas Lowland', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3100', 'Saint Thomas Middle Island', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3101', 'Trinity Palmetto Point', '184', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3102', 'Anse-la-Raye', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3103', 'Canaries', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3104', 'Castries', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3105', 'Choiseul', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3106', 'Dennery', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3107', 'Gros Inlet', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3108', 'Laborie', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3109', 'Micoud', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3110', 'Soufriere', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3111', 'Vieux Fort', '185', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3112', 'Miquelon-Langlade', '186', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3113', 'Saint-Pierre', '186', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3114', 'Charlotte', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3115', 'Grenadines', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3116', 'Saint Andrew', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3117', 'Saint David', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3118', 'Saint George', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3119', 'Saint Patrick', '187', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3120', 'A\'ana', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3121', 'Aiga-i-le-Tai', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3122', 'Atua', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3123', 'Fa\'asaleleaga', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3124', 'Gaga\'emauga', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3125', 'Gagaifomauga', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3126', 'Palauli', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3127', 'Satupa\'itea', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3128', 'Tuamasaga', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3129', 'Va\'a-o-Fonoti', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3130', 'Vaisigano', '188', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3131', 'Acquaviva', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3132', 'Borgo Maggiore', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3133', 'Chiesanuova', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3134', 'Domagnano', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3135', 'Faetano', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3136', 'Fiorentino', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3137', 'Montegiardino', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3138', 'San Marino', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3139', 'Serravalle', '189', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3140', 'Agua Grande', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3141', 'Cantagalo', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3142', 'Lemba', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3143', 'Lobata', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3144', 'Me-Zochi', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3145', 'Pague', '190', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3146', 'Al Khobar', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3147', 'Aseer', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3148', 'Ash Sharqiyah', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3149', 'Asir', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3150', 'Central Province', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3151', 'Eastern Province', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3152', 'Ha\'il', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3153', 'Jawf', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3154', 'Jizan', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3155', 'Makkah', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3156', 'Najran', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3157', 'Qasim', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3158', 'Tabuk', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3159', 'Western Province', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3160', 'al-Bahah', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3161', 'al-Hudud-ash-Shamaliyah', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3162', 'al-Madinah', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3163', 'ar-Riyad', '191', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3164', 'Dakar', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3165', 'Diourbel', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3166', 'Fatick', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3167', 'Kaolack', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3168', 'Kolda', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3169', 'Louga', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3170', 'Saint-Louis', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3171', 'Tambacounda', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3172', 'Thies', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3173', 'Ziguinchor', '192', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3174', 'Central Serbia', '193', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3175', 'Kosovo and Metohija', '193', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3176', 'Vojvodina', '193', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3177', 'Anse Boileau', '194', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3178', 'Anse Royale', '194', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3179', 'Cascade', '194', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3180', 'Takamaka', '194', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3181', 'Victoria', '194', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3182', 'Eastern', '195', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3183', 'Northern', '195', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3184', 'Southern', '195', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3185', 'Western', '195', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3186', 'Singapore', '196', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3187', 'Banskobystricky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3188', 'Bratislavsky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3189', 'Kosicky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3190', 'Nitriansky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3191', 'Presovsky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3192', 'Trenciansky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3193', 'Trnavsky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3194', 'Zilinsky', '197', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3195', 'Benedikt', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3196', 'Gorenjska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3197', 'Gorishka', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3198', 'Jugovzhodna Slovenija', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3199', 'Koroshka', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3200', 'Notranjsko-krashka', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3201', 'Obalno-krashka', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3202', 'Obcina Domzale', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3203', 'Obcina Vitanje', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3204', 'Osrednjeslovenska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3205', 'Podravska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3206', 'Pomurska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3207', 'Savinjska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3208', 'Slovenian Littoral', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3209', 'Spodnjeposavska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3210', 'Zasavska', '198', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3211', 'Pitcairn', '199', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3212', 'Central', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3213', 'Choiseul', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3214', 'Guadalcanal', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3215', 'Isabel', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3216', 'Makira and Ulawa', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3217', 'Malaita', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3218', 'Rennell and Bellona', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3219', 'Temotu', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3220', 'Western', '200', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3221', 'Awdal', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3222', 'Bakol', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3223', 'Banadir', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3224', 'Bari', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3225', 'Bay', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3226', 'Galgudug', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3227', 'Gedo', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3228', 'Hiran', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3229', 'Jubbada Hose', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3230', 'Jubbadha Dexe', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3231', 'Mudug', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3232', 'Nugal', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3233', 'Sanag', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3234', 'Shabellaha Dhexe', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3235', 'Shabellaha Hose', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3236', 'Togdher', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3237', 'Woqoyi Galbed', '201', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3238', 'Eastern Cape', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3239', 'Free State', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3240', 'Gauteng', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3241', 'Kempton Park', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3242', 'Kramerville', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3243', 'KwaZulu Natal', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3244', 'Limpopo', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3245', 'Mpumalanga', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3246', 'North West', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3247', 'Northern Cape', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3248', 'Parow', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3249', 'Table View', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3250', 'Umtentweni', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3251', 'Western Cape', '202', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3252', 'South Georgia', '203', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3253', 'Central Equatoria', '204', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3254', 'A Coruna', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3255', 'Alacant', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3256', 'Alava', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3257', 'Albacete', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3258', 'Almeria', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3259', 'Andalucia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3260', 'Asturias', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3261', 'Avila', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3262', 'Badajoz', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3263', 'Balears', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3264', 'Barcelona', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3265', 'Bertamirans', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3266', 'Biscay', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3267', 'Burgos', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3268', 'Caceres', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3269', 'Cadiz', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3270', 'Cantabria', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3271', 'Castello', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3272', 'Catalunya', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3273', 'Ceuta', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3274', 'Ciudad Real', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3275', 'Comunidad Autonoma de Canarias', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3276', 'Comunidad Autonoma de Cataluna', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3277', 'Comunidad Autonoma de Galicia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3278', 'Comunidad Autonoma de las Isla', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3279', 'Comunidad Autonoma del Princip', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3280', 'Comunidad Valenciana', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3281', 'Cordoba', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3282', 'Cuenca', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3283', 'Gipuzkoa', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3284', 'Girona', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3285', 'Granada', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3286', 'Guadalajara', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3287', 'Guipuzcoa', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3288', 'Huelva', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3289', 'Huesca', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3290', 'Jaen', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3291', 'La Rioja', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3292', 'Las Palmas', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3293', 'Leon', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3294', 'Lerida', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3295', 'Lleida', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3296', 'Lugo', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3297', 'Madrid', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3298', 'Malaga', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3299', 'Melilla', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3300', 'Murcia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3301', 'Navarra', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3302', 'Ourense', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3303', 'Pais Vasco', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3304', 'Palencia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3305', 'Pontevedra', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3306', 'Salamanca', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3307', 'Santa Cruz de Tenerife', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3308', 'Segovia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3309', 'Sevilla', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3310', 'Soria', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3311', 'Tarragona', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3312', 'Tenerife', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3313', 'Teruel', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3314', 'Toledo', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3315', 'Valencia', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3316', 'Valladolid', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3317', 'Vizcaya', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3318', 'Zamora', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3319', 'Zaragoza', '205', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3320', 'Amparai', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3321', 'Anuradhapuraya', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3322', 'Badulla', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3323', 'Boralesgamuwa', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3324', 'Colombo', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3325', 'Galla', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3326', 'Gampaha', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3327', 'Hambantota', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3328', 'Kalatura', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3329', 'Kegalla', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3330', 'Kilinochchi', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3331', 'Kurunegala', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3332', 'Madakalpuwa', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3333', 'Maha Nuwara', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3334', 'Malwana', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3335', 'Mannarama', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3336', 'Matale', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3337', 'Matara', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3338', 'Monaragala', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3339', 'Mullaitivu', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3340', 'North Eastern Province', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3341', 'North Western Province', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3342', 'Nuwara Eliya', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3343', 'Polonnaruwa', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3344', 'Puttalama', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3345', 'Ratnapuraya', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3346', 'Southern Province', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3347', 'Tirikunamalaya', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3348', 'Tuscany', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3349', 'Vavuniyawa', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3350', 'Western Province', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3351', 'Yapanaya', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3352', 'kadawatha', '206', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3353', 'A\'ali-an-Nil', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3354', 'Bahr-al-Jabal', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3355', 'Central Equatoria', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3356', 'Gharb Bahr-al-Ghazal', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3357', 'Gharb Darfur', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3358', 'Gharb Kurdufan', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3359', 'Gharb-al-Istiwa\'iyah', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3360', 'Janub Darfur', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3361', 'Janub Kurdufan', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3362', 'Junqali', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3363', 'Kassala', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3364', 'Nahr-an-Nil', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3365', 'Shamal Bahr-al-Ghazal', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3366', 'Shamal Darfur', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3367', 'Shamal Kurdufan', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3368', 'Sharq-al-Istiwa\'iyah', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3369', 'Sinnar', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3370', 'Warab', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3371', 'Wilayat al Khartum', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3372', 'al-Bahr-al-Ahmar', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3373', 'al-Buhayrat', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3374', 'al-Jazirah', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3375', 'al-Khartum', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3376', 'al-Qadarif', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3377', 'al-Wahdah', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3378', 'an-Nil-al-Abyad', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3379', 'an-Nil-al-Azraq', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3380', 'ash-Shamaliyah', '207', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3381', 'Brokopondo', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3382', 'Commewijne', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3383', 'Coronie', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3384', 'Marowijne', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3385', 'Nickerie', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3386', 'Para', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3387', 'Paramaribo', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3388', 'Saramacca', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3389', 'Wanica', '208', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3390', 'Svalbard', '209', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3391', 'Hhohho', '210', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3392', 'Lubombo', '210', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3393', 'Manzini', '210', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3394', 'Shiselweni', '210', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3395', 'Alvsborgs Lan', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3396', 'Angermanland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3397', 'Blekinge', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3398', 'Bohuslan', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3399', 'Dalarna', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3400', 'Gavleborg', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3401', 'Gaza', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3402', 'Gotland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3403', 'Halland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3404', 'Jamtland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3405', 'Jonkoping', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3406', 'Kalmar', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3407', 'Kristianstads', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3408', 'Kronoberg', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3409', 'Norrbotten', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3410', 'Orebro', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3411', 'Ostergotland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3412', 'Saltsjo-Boo', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3413', 'Skane', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3414', 'Smaland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3415', 'Sodermanland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3416', 'Stockholm', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3417', 'Uppsala', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3418', 'Varmland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3419', 'Vasterbotten', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3420', 'Vastergotland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3421', 'Vasternorrland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3422', 'Vastmanland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3423', 'Vastra Gotaland', '211', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3424', 'Aargau', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3425', 'Appenzell Inner-Rhoden', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3426', 'Appenzell-Ausser Rhoden', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3427', 'Basel-Landschaft', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3428', 'Basel-Stadt', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3429', 'Bern', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3430', 'Canton Ticino', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3431', 'Fribourg', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3432', 'Geneve', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3433', 'Glarus', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3434', 'Graubunden', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3435', 'Heerbrugg', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3436', 'Jura', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3437', 'Kanton Aargau', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3438', 'Luzern', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3439', 'Morbio Inferiore', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3440', 'Muhen', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3441', 'Neuchatel', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3442', 'Nidwalden', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3443', 'Obwalden', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3444', 'Sankt Gallen', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3445', 'Schaffhausen', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3446', 'Schwyz', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3447', 'Solothurn', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3448', 'Thurgau', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3449', 'Ticino', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3450', 'Uri', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3451', 'Valais', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3452', 'Vaud', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3453', 'Vauffelin', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3454', 'Zug', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3455', 'Zurich', '212', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3456', 'Aleppo', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3457', 'Dar\'a', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3458', 'Dayr-az-Zawr', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3459', 'Dimashq', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3460', 'Halab', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3461', 'Hamah', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3462', 'Hims', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3463', 'Idlib', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3464', 'Madinat Dimashq', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3465', 'Tartus', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3466', 'al-Hasakah', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3467', 'al-Ladhiqiyah', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3468', 'al-Qunaytirah', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3469', 'ar-Raqqah', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3470', 'as-Suwayda', '213', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3471', 'Changhwa', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3472', 'Chiayi Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3473', 'Chiayi Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3474', 'Eastern Taipei', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3475', 'Hsinchu Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3476', 'Hsinchu Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3477', 'Hualien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3478', 'Ilan', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3479', 'Kaohsiung Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3480', 'Kaohsiung Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3481', 'Keelung Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3482', 'Kinmen', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3483', 'Miaoli', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3484', 'Nantou', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3485', 'Northern Taiwan', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3486', 'Penghu', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3487', 'Pingtung', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3488', 'Taichung', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3489', 'Taichung Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3490', 'Taichung Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3491', 'Tainan Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3492', 'Tainan Shih', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3493', 'Taipei Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3494', 'Taipei Shih / Taipei Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3495', 'Taitung', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3496', 'Taoyuan', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3497', 'Yilan', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3498', 'Yun-Lin Hsien', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3499', 'Yunlin', '214', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3500', 'Dushanbe', '215', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3501', 'Gorno-Badakhshan', '215', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3502', 'Karotegin', '215', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3503', 'Khatlon', '215', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3504', 'Sughd', '215', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3505', 'Arusha', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3506', 'Dar es Salaam', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3507', 'Dodoma', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3508', 'Iringa', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3509', 'Kagera', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3510', 'Kigoma', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3511', 'Kilimanjaro', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3512', 'Lindi', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3513', 'Mara', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3514', 'Mbeya', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3515', 'Morogoro', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3516', 'Mtwara', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3517', 'Mwanza', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3518', 'Pwani', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3519', 'Rukwa', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3520', 'Ruvuma', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3521', 'Shinyanga', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3522', 'Singida', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3523', 'Tabora', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3524', 'Tanga', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3525', 'Zanzibar and Pemba', '216', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3526', 'Amnat Charoen', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3527', 'Ang Thong', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3528', 'Bangkok', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3529', 'Buri Ram', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3530', 'Chachoengsao', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3531', 'Chai Nat', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3532', 'Chaiyaphum', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3533', 'Changwat Chaiyaphum', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3534', 'Chanthaburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3535', 'Chiang Mai', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3536', 'Chiang Rai', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3537', 'Chon Buri', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3538', 'Chumphon', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3539', 'Kalasin', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3540', 'Kamphaeng Phet', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3541', 'Kanchanaburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3542', 'Khon Kaen', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3543', 'Krabi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3544', 'Krung Thep', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3545', 'Lampang', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3546', 'Lamphun', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3547', 'Loei', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3548', 'Lop Buri', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3549', 'Mae Hong Son', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3550', 'Maha Sarakham', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3551', 'Mukdahan', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3552', 'Nakhon Nayok', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3553', 'Nakhon Pathom', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3554', 'Nakhon Phanom', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3555', 'Nakhon Ratchasima', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3556', 'Nakhon Sawan', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3557', 'Nakhon Si Thammarat', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3558', 'Nan', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3559', 'Narathiwat', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3560', 'Nong Bua Lam Phu', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3561', 'Nong Khai', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3562', 'Nonthaburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3563', 'Pathum Thani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3564', 'Pattani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3565', 'Phangnga', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3566', 'Phatthalung', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3567', 'Phayao', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3568', 'Phetchabun', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3569', 'Phetchaburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3570', 'Phichit', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3571', 'Phitsanulok', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3572', 'Phra Nakhon Si Ayutthaya', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3573', 'Phrae', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3574', 'Phuket', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3575', 'Prachin Buri', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3576', 'Prachuap Khiri Khan', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3577', 'Ranong', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3578', 'Ratchaburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3579', 'Rayong', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3580', 'Roi Et', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3581', 'Sa Kaeo', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3582', 'Sakon Nakhon', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3583', 'Samut Prakan', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3584', 'Samut Sakhon', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3585', 'Samut Songkhran', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3586', 'Saraburi', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3587', 'Satun', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3588', 'Si Sa Ket', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3589', 'Sing Buri', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3590', 'Songkhla', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3591', 'Sukhothai', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3592', 'Suphan Buri', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3593', 'Surat Thani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3594', 'Surin', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3595', 'Tak', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3596', 'Trang', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3597', 'Trat', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3598', 'Ubon Ratchathani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3599', 'Udon Thani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3600', 'Uthai Thani', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3601', 'Uttaradit', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3602', 'Yala', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3603', 'Yasothon', '217', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3604', 'Centre', '218', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3605', 'Kara', '218', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3606', 'Maritime', '218', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3607', 'Plateaux', '218', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3608', 'Savanes', '218', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3609', 'Atafu', '219', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3610', 'Fakaofo', '219', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3611', 'Nukunonu', '219', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3612', 'Eua', '220', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3613', 'Ha\'apai', '220', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3614', 'Niuas', '220', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3615', 'Tongatapu', '220', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3616', 'Vava\'u', '220', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3617', 'Arima-Tunapuna-Piarco', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3618', 'Caroni', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3619', 'Chaguanas', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3620', 'Couva-Tabaquite-Talparo', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3621', 'Diego Martin', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3622', 'Glencoe', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3623', 'Penal Debe', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3624', 'Point Fortin', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3625', 'Port of Spain', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3626', 'Princes Town', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3627', 'Saint George', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3628', 'San Fernando', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3629', 'San Juan', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3630', 'Sangre Grande', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3631', 'Siparia', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3632', 'Tobago', '221', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3633', 'Aryanah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3634', 'Bajah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3635', 'Bin \'Arus', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3636', 'Binzart', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3637', 'Gouvernorat de Ariana', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3638', 'Gouvernorat de Nabeul', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3639', 'Gouvernorat de Sousse', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3640', 'Hammamet Yasmine', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3641', 'Jundubah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3642', 'Madaniyin', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3643', 'Manubah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3644', 'Monastir', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3645', 'Nabul', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3646', 'Qabis', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3647', 'Qafsah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3648', 'Qibili', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3649', 'Safaqis', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3650', 'Sfax', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3651', 'Sidi Bu Zayd', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3652', 'Silyanah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3653', 'Susah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3654', 'Tatawin', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3655', 'Tawzar', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3656', 'Tunis', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3657', 'Zaghwan', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3658', 'al-Kaf', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3659', 'al-Mahdiyah', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3660', 'al-Munastir', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3661', 'al-Qasrayn', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3662', 'al-Qayrawan', '222', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3663', 'Adana', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3664', 'Adiyaman', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3665', 'Afyon', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3666', 'Agri', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3667', 'Aksaray', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3668', 'Amasya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3669', 'Ankara', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3670', 'Antalya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3671', 'Ardahan', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3672', 'Artvin', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3673', 'Aydin', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3674', 'Balikesir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3675', 'Bartin', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3676', 'Batman', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3677', 'Bayburt', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3678', 'Bilecik', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3679', 'Bingol', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3680', 'Bitlis', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3681', 'Bolu', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3682', 'Burdur', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3683', 'Bursa', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3684', 'Canakkale', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3685', 'Cankiri', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3686', 'Corum', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3687', 'Denizli', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3688', 'Diyarbakir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3689', 'Duzce', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3690', 'Edirne', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3691', 'Elazig', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3692', 'Erzincan', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3693', 'Erzurum', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3694', 'Eskisehir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3695', 'Gaziantep', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3696', 'Giresun', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3697', 'Gumushane', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3698', 'Hakkari', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3699', 'Hatay', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3700', 'Icel', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3701', 'Igdir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3702', 'Isparta', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3703', 'Istanbul', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3704', 'Izmir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3705', 'Kahramanmaras', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3706', 'Karabuk', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3707', 'Karaman', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3708', 'Kars', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3709', 'Karsiyaka', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3710', 'Kastamonu', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3711', 'Kayseri', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3712', 'Kilis', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3713', 'Kirikkale', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3714', 'Kirklareli', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3715', 'Kirsehir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3716', 'Kocaeli', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3717', 'Konya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3718', 'Kutahya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3719', 'Lefkosa', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3720', 'Malatya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3721', 'Manisa', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3722', 'Mardin', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3723', 'Mugla', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3724', 'Mus', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3725', 'Nevsehir', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3726', 'Nigde', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3727', 'Ordu', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3728', 'Osmaniye', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3729', 'Rize', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3730', 'Sakarya', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3731', 'Samsun', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3732', 'Sanliurfa', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3733', 'Siirt', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3734', 'Sinop', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3735', 'Sirnak', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3736', 'Sivas', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3737', 'Tekirdag', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3738', 'Tokat', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3739', 'Trabzon', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3740', 'Tunceli', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3741', 'Usak', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3742', 'Van', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3743', 'Yalova', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3744', 'Yozgat', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3745', 'Zonguldak', '223', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3746', 'Ahal', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3747', 'Asgabat', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3748', 'Balkan', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3749', 'Dasoguz', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3750', 'Lebap', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3751', 'Mari', '224', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3752', 'Grand Turk', '225', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3753', 'South Caicos and East Caicos', '225', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3754', 'Funafuti', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3755', 'Nanumanga', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3756', 'Nanumea', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3757', 'Niutao', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3758', 'Nui', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3759', 'Nukufetau', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3760', 'Nukulaelae', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3761', 'Vaitupu', '226', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3762', 'Central', '227', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3763', 'Eastern', '227', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3764', 'Northern', '227', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3765', 'Western', '227', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3766', 'Cherkas\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3767', 'Chernihivs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3768', 'Chernivets\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3769', 'Crimea', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3770', 'Dnipropetrovska', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3771', 'Donets\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3772', 'Ivano-Frankivs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3773', 'Kharkiv', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3774', 'Kharkov', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3775', 'Khersonska', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3776', 'Khmel\'nyts\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3777', 'Kirovohrad', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3778', 'Krym', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3779', 'Kyyiv', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3780', 'Kyyivs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3781', 'L\'vivs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3782', 'Luhans\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3783', 'Mykolayivs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3784', 'Odes\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3785', 'Odessa', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3786', 'Poltavs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3787', 'Rivnens\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3788', 'Sevastopol\'', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3789', 'Sums\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3790', 'Ternopil\'s\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3791', 'Volyns\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3792', 'Vynnyts\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3793', 'Zakarpats\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3794', 'Zaporizhia', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3795', 'Zhytomyrs\'ka', '228', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3796', 'Abu Zabi', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3797', 'Ajman', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3798', 'Dubai', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3799', 'Ras al-Khaymah', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3800', 'Sharjah', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3801', 'Sharjha', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3802', 'Umm al Qaywayn', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3803', 'al-Fujayrah', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3804', 'ash-Shariqah', '229', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3805', 'Aberdeen', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3806', 'Aberdeenshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3807', 'Argyll', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3808', 'Armagh', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3809', 'Bedfordshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3810', 'Belfast', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3811', 'Berkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3812', 'Birmingham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3813', 'Brechin', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3814', 'Bridgnorth', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3815', 'Bristol', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3816', 'Buckinghamshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3817', 'Cambridge', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3818', 'Cambridgeshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3819', 'Channel Islands', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3820', 'Cheshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3821', 'Cleveland', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3822', 'Co Fermanagh', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3823', 'Conwy', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3824', 'Cornwall', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3825', 'Coventry', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3826', 'Craven Arms', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3827', 'Cumbria', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3828', 'Denbighshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3829', 'Derby', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3830', 'Derbyshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3831', 'Devon', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3832', 'Dial Code Dungannon', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3833', 'Didcot', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3834', 'Dorset', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3835', 'Dunbartonshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3836', 'Durham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3837', 'East Dunbartonshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3838', 'East Lothian', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3839', 'East Midlands', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3840', 'East Sussex', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3841', 'East Yorkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3842', 'England', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3843', 'Essex', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3844', 'Fermanagh', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3845', 'Fife', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3846', 'Flintshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3847', 'Fulham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3848', 'Gainsborough', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3849', 'Glocestershire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3850', 'Gwent', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3851', 'Hampshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3852', 'Hants', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3853', 'Herefordshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3854', 'Hertfordshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3855', 'Ireland', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3856', 'Isle Of Man', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3857', 'Isle of Wight', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3858', 'Kenford', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3859', 'Kent', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3860', 'Kilmarnock', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3861', 'Lanarkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3862', 'Lancashire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3863', 'Leicestershire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3864', 'Lincolnshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3865', 'Llanymynech', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3866', 'London', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3867', 'Ludlow', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3868', 'Manchester', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3869', 'Mayfair', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3870', 'Merseyside', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3871', 'Mid Glamorgan', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3872', 'Middlesex', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3873', 'Mildenhall', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3874', 'Monmouthshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3875', 'Newton Stewart', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3876', 'Norfolk', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3877', 'North Humberside', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3878', 'North Yorkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3879', 'Northamptonshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3880', 'Northants', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3881', 'Northern Ireland', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3882', 'Northumberland', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3883', 'Nottinghamshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3884', 'Oxford', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3885', 'Powys', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3886', 'Roos-shire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3887', 'SUSSEX', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3888', 'Sark', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3889', 'Scotland', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3890', 'Scottish Borders', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3891', 'Shropshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3892', 'Somerset', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3893', 'South Glamorgan', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3894', 'South Wales', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3895', 'South Yorkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3896', 'Southwell', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3897', 'Staffordshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3898', 'Strabane', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3899', 'Suffolk', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3900', 'Surrey', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3901', 'Sussex', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3902', 'Twickenham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3903', 'Tyne and Wear', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3904', 'Tyrone', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3905', 'Utah', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3906', 'Wales', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3907', 'Warwickshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3908', 'West Lothian', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3909', 'West Midlands', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3910', 'West Sussex', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3911', 'West Yorkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3912', 'Whissendine', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3913', 'Wiltshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3914', 'Wokingham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3915', 'Worcestershire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3916', 'Wrexham', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3917', 'Wurttemberg', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3918', 'Yorkshire', '230', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3919', 'Alabama', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3920', 'Alaska', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3921', 'Arizona', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3922', 'Arkansas', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3923', 'Byram', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3924', 'California', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3925', 'Cokato', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3926', 'Colorado', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3927', 'Connecticut', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3928', 'Delaware', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3929', 'District of Columbia', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3930', 'Florida', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3931', 'Georgia', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3932', 'Hawaii', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3933', 'Idaho', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3934', 'Illinois', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3935', 'Indiana', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3936', 'Iowa', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3937', 'Kansas', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3938', 'Kentucky', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3939', 'Louisiana', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3940', 'Lowa', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3941', 'Maine', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3942', 'Maryland', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3943', 'Massachusetts', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3944', 'Medfield', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3945', 'Michigan', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3946', 'Minnesota', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3947', 'Mississippi', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3948', 'Missouri', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3949', 'Montana', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3950', 'Nebraska', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3951', 'Nevada', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3952', 'New Hampshire', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3953', 'New Jersey', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3954', 'New Jersy', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3955', 'New Mexico', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3956', 'New York', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3957', 'North Carolina', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3958', 'North Dakota', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3959', 'Ohio', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3960', 'Oklahoma', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3961', 'Ontario', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3962', 'Oregon', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3963', 'Pennsylvania', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3964', 'Ramey', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3965', 'Rhode Island', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3966', 'South Carolina', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3967', 'South Dakota', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3968', 'Sublimity', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3969', 'Tennessee', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3970', 'Texas', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3971', 'Trimble', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3972', 'Utah', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3973', 'Vermont', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3974', 'Virginia', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3975', 'Washington', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3976', 'West Virginia', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3977', 'Wisconsin', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3978', 'Wyoming', '231', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3979', 'United States Minor Outlying I', '232', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3980', 'Artigas', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3981', 'Canelones', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3982', 'Cerro Largo', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3983', 'Colonia', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3984', 'Durazno', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3985', 'FLorida', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3986', 'Flores', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3987', 'Lavalleja', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3988', 'Maldonado', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3989', 'Montevideo', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3990', 'Paysandu', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3991', 'Rio Negro', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3992', 'Rivera', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3993', 'Rocha', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3994', 'Salto', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3995', 'San Jose', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3996', 'Soriano', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3997', 'Tacuarembo', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3998', 'Treinta y Tres', '233', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('3999', 'Andijon', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4000', 'Buhoro', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4001', 'Buxoro Viloyati', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4002', 'Cizah', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4003', 'Fargona', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4004', 'Horazm', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4005', 'Kaskadar', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4006', 'Korakalpogiston', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4007', 'Namangan', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4008', 'Navoi', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4009', 'Samarkand', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4010', 'Sirdare', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4011', 'Surhondar', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4012', 'Toskent', '234', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4013', 'Malampa', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4014', 'Penama', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4015', 'Sanma', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4016', 'Shefa', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4017', 'Tafea', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4018', 'Torba', '235', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4019', 'Vatican City State (Holy See)', '236', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4020', 'Amazonas', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4021', 'Anzoategui', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4022', 'Apure', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4023', 'Aragua', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4024', 'Barinas', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4025', 'Bolivar', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4026', 'Carabobo', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4027', 'Cojedes', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4028', 'Delta Amacuro', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4029', 'Distrito Federal', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4030', 'Falcon', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4031', 'Guarico', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4032', 'Lara', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4033', 'Merida', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4034', 'Miranda', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4035', 'Monagas', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4036', 'Nueva Esparta', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4037', 'Portuguesa', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4038', 'Sucre', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4039', 'Tachira', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4040', 'Trujillo', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4041', 'Vargas', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4042', 'Yaracuy', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4043', 'Zulia', '237', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4044', 'Bac Giang', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4045', 'Binh Dinh', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4046', 'Binh Duong', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4047', 'Da Nang', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4048', 'Dong Bang Song Cuu Long', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4049', 'Dong Bang Song Hong', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4050', 'Dong Nai', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4051', 'Dong Nam Bo', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4052', 'Duyen Hai Mien Trung', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4053', 'Hanoi', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4054', 'Hung Yen', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4055', 'Khu Bon Cu', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4056', 'Long An', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4057', 'Mien Nui Va Trung Du', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4058', 'Thai Nguyen', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4059', 'Thanh Pho Ho Chi Minh', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4060', 'Thu Do Ha Noi', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4061', 'Tinh Can Tho', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4062', 'Tinh Da Nang', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4063', 'Tinh Gia Lai', '238', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4064', 'Anegada', '239', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4065', 'Jost van Dyke', '239', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4066', 'Tortola', '239', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4067', 'Saint Croix', '240', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4068', 'Saint John', '240', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4069', 'Saint Thomas', '240', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4070', 'Alo', '241', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4071', 'Singave', '241', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4072', 'Wallis', '241', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4073', 'Bu Jaydur', '242', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4074', 'Wad-adh-Dhahab', '242', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4075', 'al-\'Ayun', '242', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4076', 'as-Samarah', '242', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4077', '\'Adan', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4078', 'Abyan', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4079', 'Dhamar', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4080', 'Hadramaut', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4081', 'Hajjah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4082', 'Hudaydah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4083', 'Ibb', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4084', 'Lahij', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4085', 'Ma\'rib', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4086', 'Madinat San\'a', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4087', 'Sa\'dah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4088', 'Sana', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4089', 'Shabwah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4090', 'Ta\'izz', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4091', 'al-Bayda', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4092', 'al-Hudaydah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4093', 'al-Jawf', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4094', 'al-Mahrah', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4095', 'al-Mahwit', '243', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4096', 'Central Serbia', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4097', 'Kosovo and Metohija', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4098', 'Montenegro', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4099', 'Republic of Serbia', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4100', 'Serbia', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4101', 'Vojvodina', '244', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4102', 'Central', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4103', 'Copperbelt', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4104', 'Eastern', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4105', 'Luapala', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4106', 'Lusaka', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4107', 'North-Western', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4108', 'Northern', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4109', 'Southern', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4110', 'Western', '245', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4111', 'Bulawayo', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4112', 'Harare', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4113', 'Manicaland', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4114', 'Mashonaland Central', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4115', 'Mashonaland East', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4116', 'Mashonaland West', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4117', 'Masvingo', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4118', 'Matabeleland North', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4119', 'Matabeleland South', '246', '1');
INSERT INTO `states` (`state_id`, `state_name`, `country_id`, `state_status`) VALUES ('4120', 'Midlands', '246', '1');


#
# TABLE STRUCTURE FOR: stripe_bank_details
#

DROP TABLE IF EXISTS `stripe_bank_details`;

CREATE TABLE `stripe_bank_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `account_holder_name` varchar(150) NOT NULL,
  `account_number` varchar(150) NOT NULL,
  `account_iban` varchar(100) NOT NULL,
  `bank_name` varchar(150) NOT NULL,
  `bank_address` varchar(256) NOT NULL,
  `sort_code` varchar(50) NOT NULL,
  `routing_number` varchar(50) NOT NULL,
  `account_ifsc` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: super_fast_delivery_option
#

DROP TABLE IF EXISTS `super_fast_delivery_option`;

CREATE TABLE `super_fast_delivery_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `super_fast_delivery_desc` varchar(100) NOT NULL,
  `number_of_days` int(11) NOT NULL,
  `purchased_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delivery_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` int(11) NOT NULL DEFAULT '0',
  `super_fast_charges` float NOT NULL,
  `currency_type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: system_settings
#

DROP TABLE IF EXISTS `system_settings`;

CREATE TABLE `system_settings` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `key` varchar(250) NOT NULL,
  `value` text NOT NULL,
  `system` tinyint(150) NOT NULL DEFAULT '1',
  `groups` varchar(150) NOT NULL,
  `update_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=latin1;

INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('3', 'email_tittle', 'Digimonk Work', '1', 'config', '2018-09-28', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('4', 'email_address', 'sandeep.sikarwar@digimonk.in', '1', 'config', '2018-09-28', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('6', 'default_currency', 'USD', '1', 'config', '2018-09-28', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('93', 'favicon', 'fevicon1.png', '1', '', '0000-00-00', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('97', 'currency_option', 'USD', '1', 'config', '2018-09-28', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('199', 'logo_front', 'uploads/logo/1538219520_Logo1.png', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('226', 'website_name', 'Digimonk Technologies ', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('227', 'base_domain', 'http://work.digimonk.net/', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('228', 'website_slogan', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('229', 'price_option', 'dynamic', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('230', 'gig_price', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('231', 'extra_gig_price', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('232', 'admin_commision', '10', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('233', 'google_analytics_code', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('234', 'meta_title', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('235', 'meta_keywords', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('236', 'meta_description', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('237', 'facebook', 'https://www.facebook.com/DigiMonkOfficial/', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('238', 'twitter', 'https://twitter.com/teamdigimonk', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('239', 'google_plus', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('240', 'linkedIn', 'https://www.linkedin.com/company/pixel-online/', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('241', 'one_signal_subdomain', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('242', 'one_signal_app_id', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('243', 'one_signal_reset_key', '', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('244', 'paypal_option', '1', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('245', 'paypal_allow', '1', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('246', 'stripe_option', '1', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('247', 'stripe_allow', '1', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('248', 'publishable_key', 'pk_test_Js15CigEZPZH69hjS2hgXjBx', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('249', 'secret_key', 'sk_test_OVXvseuWuLVp2w0XOWvGKDQJ', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('250', 'live_publishable_key', 'pk_live_Fcv2quS4tvCx6BwXhfoQQFTT', '1', 'config', '2018-09-29', '1');
INSERT INTO `system_settings` (`id`, `key`, `value`, `system`, `groups`, `update_date`, `status`) VALUES ('251', 'live_secret_key', 'sk_live_juEOItnRuTNTkHuijyJCdSdt', '1', 'config', '2018-09-29', '1');


#
# TABLE STRUCTURE FOR: term
#

DROP TABLE IF EXISTS `term`;

CREATE TABLE `term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `footer_submenu` varchar(222) NOT NULL,
  `page_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: terms
#

DROP TABLE IF EXISTS `terms`;

CREATE TABLE `terms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user_required_extra_gigs
#

DROP TABLE IF EXISTS `user_required_extra_gigs`;

CREATE TABLE `user_required_extra_gigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gig_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `currency_type` char(5) NOT NULL,
  `options` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: version_updates
#

DROP TABLE IF EXISTS `version_updates`;

CREATE TABLE `version_updates` (
  `version_id` int(11) NOT NULL AUTO_INCREMENT,
  `build` int(11) NOT NULL DEFAULT '0',
  `version` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Version Updates Details';

#
# TABLE STRUCTURE FOR: views
#

DROP TABLE IF EXISTS `views`;

CREATE TABLE `views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gig_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `views` (`id`, `user_id`, `gig_id`) VALUES ('1', '2', '2');
INSERT INTO `views` (`id`, `user_id`, `gig_id`) VALUES ('2', '2', '1');
INSERT INTO `views` (`id`, `user_id`, `gig_id`) VALUES ('3', '1', '5');
INSERT INTO `views` (`id`, `user_id`, `gig_id`) VALUES ('4', '2', '8');


